import { useState, useMemo, useRef, useEffect } from 'react';
import { useNavigate, useLocation, useSearchParams } from 'react-router-dom';
import {
  Plus, Search, Pencil, Trash2, Flame, Heart, Shield, Phone, MessageCircle, Upload, Star, Users,
  Calendar, Award, TrendingUp, Filter, Settings, UserPlus, UserCircle2, ChevronDown, ChevronUp, Send, Save, FileText, History, UserCheck, Eye, Download, ExternalLink, X, Clock, ArrowLeft
} from 'lucide-react';
import { useContacts, useCreateContact, useUpdateContact, useDeleteContact, useUpcomingBirthdays } from '@hooks/useContacts';
import { useClaims } from '@hooks/useClaims';
import { deletionRequestsService } from '@api/deletionRequestsService';
import { useLookupStore } from '@store/lookup.store';
import { contactsService, policiesService, claimsService, leadsService, insuranceService, documentsService } from '@api/index';
import { useQueryClient, useQuery, useMutation } from '@tanstack/react-query';
import DataTable, { Column } from '@comps/common/DataTable';
import ActivityTimeline from '@comps/common/ActivityTimeline';
import ImportFormatModal, { ImportFormatColumn } from '@comps/common/ImportFormatModal';
import Modal from '@comps/common/Modal';
import DocumentUploadModal, { DocumentUploadMeta } from '@comps/common/DocumentUploadModal';
import DocumentsTable from '@comps/common/DocumentsTable';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { format, differenceInDays } from 'date-fns';
import clsx from 'clsx';
import { DatePicker } from '@comps/common/DatePicker';
import toast from 'react-hot-toast';

import { useAuthStore } from '@store/auth.store';
import { useTableColumnVisibility } from '@hooks/useTableColumnVisibility';
import { sortData } from '../../utils/sortUtils';
import ContactDetailModal from './ContactDetailModal';
import FamilyMemberModal from './FamilyMemberModal';
import PolicyDetailModal from '../Policies/PolicyDetailModal';
import CreatePolicyModal from '../Policies/CreatePolicyModal';
import Claims, { ClaimDetailView } from '../Claims';
import ClaimDetailModal from '../Claims/ClaimDetailModal';
import * as XLSX from 'xlsx';
import { CountryPhoneInput } from '@comps/common/CountryPhoneInput';
import { DatalistInput } from '@comps/common/DatalistInput';
import INDIA_STATE_DISTRICTS from '@/constants/india-state-districts.json';
import { getActiveDropdownOptions, getModuleCustomDropdowns } from '@/utils/masterDropdowns';
import { isFieldRequired as isFieldRequiredHelper, COMPULSORY_RULES_UPDATED_EVENT } from '@/utils/compulsoryFieldRules';

const DEFAULT_EDUCATION_OPTIONS = [
  'Metric',
  'Intermediate',
  'Graduate',
  'Post Graduate',
  'Up to 9th class passed',
  '10th class passed',
  'Post Graduate (Gen)',
  'Med Graduate',
  'Post Graduate, Eng',
  'Law Graduate / Post Graduate',
  'CA/ICWA/MBA/CFA',
  'Computer degree other',
  'Other',
];

const DEFAULT_OCCUPATION_TYPE_OPTIONS = [
  'Salaried Private',
  'Salaried Gov',
  'Salaried/Service',
  'Business Owner',
  'Business',
  'Industrialist',
  'Self Employed Professional',
  'Agriculture',
  'Student',
  'Retired',
  'Homemaker',
  'Other',
];

const EDUCATION_OPTIONS = getActiveDropdownOptions('Contact', 'Education', DEFAULT_EDUCATION_OPTIONS).map(o => o.value);
const OCCUPATION_TYPE_OPTIONS = getActiveDropdownOptions('Contact', 'Occupation', DEFAULT_OCCUPATION_TYPE_OPTIONS).map(o => o.value);

const INDIAN_STATES_AND_UTS = INDIA_STATE_DISTRICTS
  .map(({ state }) => state)
  .sort((a, b) => a.localeCompare(b));
const INDIAN_DISTRICTS_BY_STATE = Object.fromEntries(
  INDIA_STATE_DISTRICTS.map(({ state, districts }) => [
    state,
    [...districts].sort((a, b) => a.localeCompare(b)),
  ]),
);

const CONTACT_IMPORT_COLUMNS: ImportFormatColumn[] = [
  { name: 'Sr. No.', requirement: 'Optional; row serial number.' },
  { name: 'First Name', requirement: 'Required; contact primary first name.' },
  { name: 'Last Name', requirement: 'Required; contact last name.' },
  { name: 'Customer Contact No.', requirement: 'Required; 10-digit mobile number, must be unique.' },
  { name: 'Alternate Contact No.', requirement: 'Optional; 10-digit alternate mobile number.' },
  { name: 'Customer Email ID', requirement: 'Optional; valid email address.' },
  { name: 'Relation', requirement: 'Optional; relation (e.g. Self, Spouse, Child, Parent, Other).' },
  { name: 'Is Dependent?', requirement: 'Optional; Yes or No.' },
  { name: 'Date of Birth', requirement: 'Optional; format YYYY-MM-DD or DD-MM-YYYY.' },
  { name: 'Pincode', requirement: 'Optional; 6-digit postal pincode.' },
  { name: 'City', requirement: 'Optional; residential city.' },
  { name: 'State', requirement: 'Optional; state name.' },
  { name: 'Education', requirement: 'Optional; education qualification.' },
  { name: 'Occupation', requirement: 'Optional; occupation type.' },
  { name: 'Designation', requirement: 'Optional; job designation / role.' },
  { name: 'Annual Income', requirement: 'Optional; annual income in INR (numeric value only).' },
  { name: 'Declared Medical History', requirement: 'Optional; declared medical conditions (comma or pipe separated).' },
  { name: 'Surgery History', requirement: 'Optional; past surgery details (or None).' },
  { name: 'Current Medicines Prescription', requirement: 'Optional; current medicines / prescriptions (or None).' },
];

const CONTACT_IMPORT_SAMPLE_ROW = [
  '1',
  'Rahul',
  'Sharma',
  '9876543210',
  '9876543211',
  'rahul.sharma@example.com',
  'Self',
  'No',
  '1990-05-15',
  '400001',
  'Mumbai',
  'Maharashtra',
  'Graduate',
  'Salaried Private',
  'Software Engineer',
  '1200000',
  'None',
  'None',
  'None',
];

const getImportCell = (row: Record<string, unknown>, ...headers: string[]) => {
  for (const h of headers) {
    if (row[h] !== undefined && row[h] !== null && String(row[h]).trim() !== '') {
      return String(row[h]).trim();
    }
  }
  const normHeaders = headers.map(h => h.toLowerCase().replace(/[^a-z0-9]/g, ''));
  for (const rowKey of Object.keys(row)) {
    const normRowKey = rowKey.toLowerCase().replace(/[^a-z0-9]/g, '');
    if (normHeaders.includes(normRowKey)) {
      const val = row[rowKey];
      if (val !== undefined && val !== null && String(val).trim() !== '') {
        return String(val).trim();
      }
    }
  }
  return '';
};

const normalizeImportDate = (val: unknown): string | undefined => {
  if (val == null || val === '') return undefined;
  if (val instanceof Date && !isNaN(val.getTime())) {
    const y = val.getFullYear();
    const m = String(val.getMonth() + 1).padStart(2, '0');
    const d = String(val.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  }
  const s = String(val).trim();
  if (!s) return undefined;

  // Number / Excel serial date code (e.g. 32888, 44927)
  if (/^\d{4,5}(\.\d+)?$/.test(s)) {
    const num = Number(s);
    if (num > 1000 && num < 100000) {
      try {
        const parsed = XLSX.SSF.parse_date_code(num);
        if (parsed && parsed.y && parsed.m && parsed.d) {
          const y = parsed.y;
          const m = String(parsed.m).padStart(2, '0');
          const d = String(parsed.d).padStart(2, '0');
          return `${y}-${m}-${d}`;
        }
      } catch {}
    }
  }

  // YYYY-MM-DD, YYYY/MM/DD, YYYY.MM.DD
  const ymdMatch = s.match(/^(\d{4})[-\/\.](\d{1,2})[-\/\.](\d{1,2})/);
  if (ymdMatch) {
    const y = ymdMatch[1];
    const m = ymdMatch[2].padStart(2, '0');
    const d = ymdMatch[3].padStart(2, '0');
    return `${y}-${m}-${d}`;
  }

  // DD-MM-YYYY, MM-DD-YYYY, D/M/YY, DD/MM/YYYY, M/D/YY
  const dmyMatch = s.match(/^(\d{1,2})[-\/\.](\d{1,2})[-\/\.](\d{2,4})/);
  if (dmyMatch) {
    const p1 = parseInt(dmyMatch[1], 10);
    const p2 = parseInt(dmyMatch[2], 10);
    const rawY = dmyMatch[3];
    const y = rawY.length === 2 ? (Number(rawY) > 40 ? 1900 + Number(rawY) : 2000 + Number(rawY)) : Number(rawY);
    let d = p1;
    let m = p2;
    if (p1 <= 12 && p2 > 12) {
      m = p1;
      d = p2;
    }
    const mm = String(m).padStart(2, '0');
    const dd = String(d).padStart(2, '0');
    return `${y}-${mm}-${dd}`;
  }

  const fallback = new Date(s);
  if (!isNaN(fallback.getTime())) {
    const y = fallback.getFullYear();
    const m = String(fallback.getMonth() + 1).padStart(2, '0');
    const d = String(fallback.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  }

  return s;
};

function mapContactImportRow(row: Record<string, unknown>) {
  const contact: Record<string, unknown> = {};
  const importErrors: string[] = [];
  const parseNumber = (value: string, field: string) => {
    if (!value) return undefined;
    const number = Number(value.replace(/,/g, ''));
    if (!Number.isFinite(number)) {
      importErrors.push(`${field} must be a number`);
      return undefined;
    }
    return number;
  };

  const validateDate = (rawVal: unknown, field: string, errors: string[]): string | undefined => {
    if (rawVal == null || rawVal === '') return undefined;
    const normalized = normalizeImportDate(rawVal);
    if (!normalized) return undefined;
    const match = normalized.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (!match) {
      errors.push(`${field} must use YYYY-MM-DD or DD-MM-YYYY`);
      return undefined;
    }
    const date = new Date(`${normalized}T00:00:00Z`);
    if (Number.isNaN(date.getTime()) || date.toISOString().slice(0, 10) !== normalized) {
      errors.push(`${field} is not a valid date`);
      return undefined;
    }
    return normalized;
  };

  // 1. First Name (Required)
  const firstName = getImportCell(row, 'First Name', 'firstName');
  if (firstName) {
    contact.firstName = firstName;
  } else {
    importErrors.push('First Name is required');
  }

  // 2. Last Name
  const lastName = getImportCell(row, 'Last Name', 'lastName');
  contact.lastName = lastName || '-';

  // 3. Customer Contact No. (Required, 10-digit mobile number)
  const phoneRaw = getImportCell(row, 'Customer Contact No.', 'Customer Contact No', 'Phone', 'Contact No', 'phone');
  const phoneDigits = phoneRaw.replace(/\D/g, '');
  if (!phoneDigits) {
    importErrors.push('Customer Contact No. is required');
  } else if (phoneDigits.length === 10) {
    contact.phone = phoneDigits;
  } else if (phoneDigits.length > 10 && phoneDigits.slice(-10).length === 10) {
    contact.phone = phoneDigits.slice(-10);
  } else {
    importErrors.push('Customer Contact No. must contain exactly 10 digits');
  }

  // 4. Alternate Contact No.
  const altPhoneRaw = getImportCell(row, 'Alternate Contact No.', 'Alternate Contact No', 'Alternate Phone', 'alternatePhone');
  if (altPhoneRaw) {
    const altDigits = altPhoneRaw.replace(/\D/g, '');
    if (altDigits.length >= 10 && altDigits.slice(-10).length === 10) {
      contact.alternatePhone = altDigits.slice(-10);
    } else {
      importErrors.push('Alternate Contact No. must contain 10 digits');
    }
  }

  // 5. Customer Email ID
  const email = getImportCell(row, 'Customer Email ID', 'Customer Email', 'Email', 'email');
  if (email) {
    if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      contact.email = email;
    } else {
      importErrors.push('Customer Email ID must be a valid email address');
    }
  }

  // 6. Relation
  const relation = getImportCell(row, 'Relation', 'Relationship', 'relation');
  if (relation) {
    contact.role = relation;
    contact.notes = `Relation: ${relation}`;
  }

  // 7. Is Dependent?
  const isDepRaw = getImportCell(row, 'Is Dependent?', 'Is Dependent', 'isDependent', 'Dependent');
  if (isDepRaw) {
    if (/^(true|false|yes|no|y|n|1|0)$/i.test(isDepRaw)) {
      const isDep = /^(true|yes|y|1)$/i.test(isDepRaw);
      contact.isDependent = isDep;
      if (isDep && contact.phone) {
        contact.dependentNo = String(contact.phone);
      }
    } else {
      importErrors.push('Is Dependent? must be Yes or No');
    }
  }

  // 8. Date of Birth
  const dobRaw = getImportCell(row, 'Date of Birth', 'dateOfBirth', 'DOB');
  if (dobRaw) {
    const parsedDob = validateDate(row['Date of Birth'] ?? dobRaw, 'Date of Birth', importErrors);
    if (parsedDob) contact.dateOfBirth = parsedDob;
  }

  // 9. Education
  const education = getImportCell(row, 'Education', 'education');
  if (education) {
    contact.education = education;
  }

  // 10. Annual Income
  const incomeRaw = getImportCell(row, 'Annual Income', 'annualIncome', 'Income');
  if (incomeRaw) {
    const incomeNum = parseNumber(incomeRaw, 'Annual Income');
    if (incomeNum !== undefined) {
      if (incomeNum < 0) {
        importErrors.push('Annual Income cannot be negative');
      } else {
        contact.annualIncome = incomeNum;
      }
    }
  }

  // 11. Declared Medical History
  const declMedRaw = getImportCell(row, 'Declared Medical History', 'declaredMedicalHistory', 'Medical History');
  if (declMedRaw && !/^(none|nil|na|n\/a|no|-)$/i.test(declMedRaw)) {
    const medItems = declMedRaw.split(/[,|]/).map(s => s.trim()).filter(Boolean);
    if (medItems.length > 0) {
      contact.declaredMedicalHistory = medItems;
      contact.medicalHistory = medItems;
    }
  }

  // 12. Surgery History
  const surgeryRaw = getImportCell(row, 'Surgery History', 'surgeryDetails', 'Surgery Details');
  if (surgeryRaw && !/^(none|nil|na|n\/a|no|-)$/i.test(surgeryRaw)) {
    contact.surgeryDetails = surgeryRaw;
  }

  // 13. Current Medicines Prescription
  const prescRaw = getImportCell(row, 'Current Medicines Prescription', 'prescriptionDetails', 'Prescription Details', 'Current Medicines');
  if (prescRaw && !/^(none|nil|na|n\/a|no|-)$/i.test(prescRaw)) {
    contact.prescriptionDetails = prescRaw;
  }

  // 14. Pincode, City, State -> Address
  const pincode = getImportCell(row, 'Pincode', 'Pin Code', 'pincode');
  const city = getImportCell(row, 'City', 'city');
  const state = getImportCell(row, 'State', 'state');
  const address = (pincode || city || state) ? {
    type: 'HOME',
    line1: 'N/A',
    city: city || 'N/A',
    state: state || 'N/A',
    pincode: pincode || 'N/A',
    country: 'India',
    isPrimary: true,
  } : undefined;
  if (city) contact.city = city;

  // 15. Occupation, Designation -> Occupation
  const occupationType = getImportCell(row, 'Occupation', 'Occupation Type', 'occupation');
  const designation = getImportCell(row, 'Designation', 'designation');
  const occupation = (occupationType || designation) ? {
    type: occupationType || 'Other',
    designation: designation || undefined,
    isPrimary: true,
  } : undefined;

  return { contact, address, occupation, productInterests: [], familyMembers: [], policies: [], claims: [], importErrors };
}

export const contactFormSchema = z.object({
  // System fields mapping
  firstName: z.string().min(1, 'Required'),
  lastName: z.string().min(1, 'Required'),
  phone: z.string().refine(v => {
    const d = (v || '').replace(/\D/g, '');
    return d.length === 10 || (d.length > 10 && d.slice(-10).length === 10);
  }, 'Mobile number must be exactly 10 digits'),
  alternatePhone: z.string().optional().refine(v => {
    if (!v) return true;
    const d = v.replace(/\D/g, '');
    return d.length === 10 || (d.length > 10 && d.slice(-10).length === 10);
  }, 'Alternate phone must be exactly 10 digits').or(z.literal('')),
  email: z.string().email('Invalid email').optional().or(z.literal('')),
  gender: z.enum(['MALE', 'FEMALE', 'OTHER', '']).optional(),
  dateOfBirth: z.string().optional(),
  birthPlace: z.string().optional(),
  panNumber: z.string().optional(),
  aadhaarNumber: z.string().optional(),
  annualIncome: z.coerce.number().min(0).optional().or(z.literal('')),
  notes: z.string().optional(),
  tags: z.string().optional(), // comma-separated, split on submit
  isActive: z.string().optional(),
  city: z.string().optional(),
  source: z.string().optional(),
  assignedEmployeeId: z.string().optional(),
  leadStage: z.string().optional(),
  leadStatus: z.string().optional(),
  leadType: z.string().optional(),
  followUpDate: z.string().optional(),
  occupationType: z.string().optional(),
  state: z.string().optional(),
  district: z.string().optional(),
  address: z.string().optional(),
  pincode: z.string().optional(),
});
const schema = contactFormSchema;
type Form = z.infer<typeof schema>;

interface Contact {
  id: string; firstName: string; lastName: string; phone: string; email?: string;
  alternatePhone?: string; gender?: string; dateOfBirth?: string; birthPlace?: string;
  panNumber?: string; aadhaarNumber?: string; annualIncome?: number;
  notes?: string; tags?: string[]; isActive: boolean;
}

const MEDICAL_CONDITIONS_LIST = [
  'Diabetes Mellitus',
  'High BP / Cholesterol',
  'Heart Disease',
  'Tuberculosis',
  'Asthma',
  'Other Respiratory Infection',
  'Disease of bones/joints',
  'Slip disc',
  'Spinal Disorder',
  'Ligament Injury',
  'Cancer',
  'Gynecological disorder (DUB, Fibroid Uterus, Ovarian cyst)',
  'Undergone Cesarean / Hysterectomy',
  'Disease of Stomach / Intestine',
  'Liver / Gall Bladder / Pancreas',
  'Kidney / Urinary Bladder / Urinary Tract Disease',
  'Disease of Prostate / Fistula / Piles / Genital Disease',
  'Cataract or Other Disease of Eye and ENT',
  'Thyroid',
  'Others'
];

const autoResizeTextarea = (el: HTMLTextAreaElement | null) => {
  if (!el) return;
  el.style.height = 'auto';
  const scrollH = el.scrollHeight;
  const newHeight = Math.max(56, Math.min(scrollH, 360));
  el.style.height = `${newHeight}px`;
  el.style.overflowY = scrollH > 360 ? 'auto' : 'hidden';
};

function MultiSelectBox({
  label,
  selectedValues,
  onChange,
  badgeColor = 'blue',
  placeholder = 'Select Conditions...'
}: {
  label: string;
  selectedValues: string[];
  onChange: (vals: string[]) => void;
  badgeColor?: 'blue' | 'orange';
  placeholder?: string;
}) {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  const filteredOptions = MEDICAL_CONDITIONS_LIST.filter(opt =>
    opt.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const toggleOption = (opt: string) => {
    if (selectedValues.includes(opt)) {
      onChange(selectedValues.filter(o => o !== opt));
    } else {
      onChange([...selectedValues, opt]);
    }
  };

  return (
    <div className="relative">
      <label className="label text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">{label}</label>
      <div
        onClick={() => setIsOpen(!isOpen)}
        className="input min-h-[40px] w-full cursor-pointer flex items-center justify-between gap-2 flex-wrap py-1.5 px-3 bg-white border border-slate-200 rounded-xl hover:border-slate-300 transition-all"
      >
        {selectedValues.length === 0 ? (
          <span className="text-slate-400 text-xs font-normal">{placeholder}</span>
        ) : (
          <div className="flex flex-wrap gap-1">
            {selectedValues.map((val, idx) => (
              <span
                key={idx}
                className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-semibold border ${
                  badgeColor === 'orange'
                    ? 'bg-orange-50 text-orange-700 border-orange-200'
                    : 'bg-blue-50 text-blue-700 border-blue-200'
                }`}
              >
                {val}
                <span
                  onClick={(e) => {
                    e.stopPropagation();
                    onChange(selectedValues.filter(v => v !== val));
                  }}
                  className="hover:text-red-600 font-bold cursor-pointer ml-0.5"
                >
                  ×
                </span>
              </span>
            ))}
          </div>
        )}
        <span className="text-slate-400 text-[10px] ml-auto">▼</span>
      </div>

      {isOpen && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setIsOpen(false)} />
          <div className="absolute z-50 mt-1 w-full bg-white border border-slate-200 rounded-xl shadow-xl p-2.5 max-h-60 overflow-y-auto">
            <input
              type="text"
              className="input w-full text-xs py-1.5 px-2.5 mb-2 border border-slate-200 rounded-lg"
              placeholder="Type to search condition..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              onClick={(e) => e.stopPropagation()}
            />
            <div className="space-y-0.5">
              {filteredOptions.map((opt) => {
                const isChecked = selectedValues.includes(opt);
                return (
                  <label
                    key={opt}
                    className="flex flex-wrap items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-slate-50 cursor-pointer text-xs select-none"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <input
                      type="checkbox"
                      className={`w-3.5 h-3.5 rounded cursor-pointer ${badgeColor === 'orange' ? 'accent-orange-500' : 'accent-blue-600'}`}
                      checked={isChecked}
                      onChange={() => toggleOption(opt)}
                    />
                    <span className={`font-medium ${isChecked ? 'text-slate-900 font-bold' : 'text-slate-600'}`}>
                      {opt}
                    </span>
                  </label>
                );
              })}
            </div>
          </div>
        </>
      )}
    </div>
  );
}

import { canEditModule, canManageModule } from '../../utils/permissions';

export default function Contacts() {
  const user = useAuthStore(s => s.user);
  const canEditContacts = canEditModule(user, 'contacts');
  const canManageContacts = canManageModule(user, 'contacts');
  const navigate = useNavigate();
  const location = useLocation();
  const [searchParams] = useSearchParams();
  const qc = useQueryClient();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const openedPolicyRef = useRef<string | null>(null);
  const openedFamilyRef = useRef<string | null>(null);
  const openedDirectContactRef = useRef<string | null>(null);
  const isDirectPolicyModalRef = useRef(false);
  const [activeTab, setActiveTab] = useState<'contacts' | 'customers' | 'birthdays'>('contacts');
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState(() => searchParams.get('search') || searchParams.get('q') || '');
  const [selectedFilters, setSelectedFilters] = useState<string[]>([]);
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const [importFormatOpen, setImportFormatOpen] = useState(false);
  const [isEmployeePickerOpen, setIsEmployeePickerOpen] = useState(false);
  const [employeePickerSearch, setEmployeePickerSearch] = useState('');

  const { data: compulsoryRulesRes } = useQuery({
    queryKey: ['compulsory-rules'],
    queryFn: () => insuranceService.getCompulsoryRules(),
  });
  const compulsoryRules = useMemo(() => compulsoryRulesRes?.data ?? [], [compulsoryRulesRes]);

  const isFieldRequired = (key: string, defaultRequired: boolean) => {
    return isFieldRequiredHelper(compulsoryRules, 'Contact', key, defaultRequired);
  };

  useEffect(() => {
    const onCompRulesUpdated = () => {
      qc.invalidateQueries({ queryKey: ['compulsory-rules'] });
    };
    window.addEventListener(COMPULSORY_RULES_UPDATED_EVENT, onCompRulesUpdated);
    window.addEventListener('storage', onCompRulesUpdated);
    return () => {
      window.removeEventListener(COMPULSORY_RULES_UPDATED_EVENT, onCompRulesUpdated);
      window.removeEventListener('storage', onCompRulesUpdated);
    };
  }, [qc]);

  useEffect(() => {
    const q = searchParams.get('search') ?? searchParams.get('q');
    if (q !== null && q !== undefined) {
      setSearch(q);
      setPage(1);
    } else if (!searchParams.has('search') && !searchParams.has('q')) {
      setSearch('');
    }
  }, [searchParams]);

  useEffect(() => {
    if (searchParams.get('action') === 'add') {
      openCustomerCreate();
    }
  }, [searchParams]);
  const [editTarget, setEditTarget] = useState<Contact | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Contact | null>(null);
  const [editLeadId, setEditLeadId] = useState<string | null>(null);
  const [editContactId, setEditContactId] = useState<string | null>(null);
  const [loadedContact, setLoadedContact] = useState<any | null>(null);

  // Sorting & Column customisation states
  const [sortKey, setSortKey] = useState('');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc');
  const { isVisible: isColVisibleInSettings, toggleColumn: toggleColInSettings, allColumns: allContactColumnsConfig } = useTableColumnVisibility('contacts');
  const [showColPicker, setShowColPicker] = useState(false);
  const colPickerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (colPickerRef.current && !colPickerRef.current.contains(e.target as Node)) {
        setShowColPicker(false);
      }
    };
    if (showColPicker) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [showColPicker]);
  const [showProductDropdown, setShowProductDropdown] = useState(false);
  const [filterProducts, setFilterProducts] = useState<string[]>([]);
  const [excludeProduct, setExcludeProduct] = useState(false);
  const [selectedDetailId, setSelectedDetailId] = useState<string | null>(null);
  const [detailModalOpen, setDetailModalOpen] = useState(false);
  const [selectedPolicyModalId, setSelectedPolicyModalId] = useState<string | null>(null);
  const [selectedClaimDetail, setSelectedClaimDetail] = useState<any | null>(null);
  const [createPolicyModalOpen, setCreatePolicyModalOpen] = useState(false);
  const [expandedPolicyIds, setExpandedPolicyIds] = useState<Record<string, boolean>>({});
  const [policyToEdit, setPolicyToEdit] = useState<any | null>(null);
  const [familyMemberModalOpen, setFamilyMemberModalOpen] = useState(false);
  const [editingFamilyMemberIdx, setEditingFamilyMemberIdx] = useState<number | null>(null);
  const [selectedFamilyMemberForModal, setSelectedFamilyMemberForModal] = useState<any | null>(null);
  const [contactDocUploadOpen, setContactDocUploadOpen] = useState(false);
  const [docPreviewModal, setDocPreviewModal] = useState<{ open: boolean; title: string; url: string }>({ open: false, title: '', url: '' });
  const { user: authUser } = useAuthStore();
  const isAdminOrSuperadmin = authUser?.role === 'OWNER' || authUser?.role === 'SUPERADMIN' || authUser?.role === 'ADMIN';

  const LEAD_SOURCES = useMemo(() => [
    'Social Media',
    'Our Customer Self',
    'Refered by our customer',
    'Walkin',
    'BNI'
  ], []);




  const [formMedHistory, setFormMedHistory] = useState<string[]>([]);
  const [formRelationships, setFormRelationships] = useState<any[]>([]);

  // 15 Detailed Filter State Variables for Contacts Page
  const [filterFollowUpFrom, setFilterFollowUpFrom] = useState('');
  const [filterFollowUpTo, setFilterFollowUpTo] = useState('');
  const [filterGender, setFilterGender] = useState('ALL');
  const [filterMaritalStatus, setFilterMaritalStatus] = useState('ALL');
  const [filterAgeRange, setFilterAgeRange] = useState('ALL');
  const [filterIncomeRange, setFilterIncomeRange] = useState('ALL');
  const [filterEducation, setFilterEducation] = useState('ALL');
  const [filterOccupation, setFilterOccupation] = useState('ALL');
  const [filterResidency, setFilterResidency] = useState('ALL');
  const [filterState, setFilterState] = useState('');
  const [filterCity, setFilterCity] = useState('');
  const [filterBank, setFilterBank] = useState('');
  const [filterMedicalHistory, setFilterMedicalHistory] = useState<string[]>([]);
  const [filterActiveStatus, setFilterActiveStatus] = useState('ALL');
  const [filterPolicyCombo, setFilterPolicyCombo] = useState('ALL');
  const [filterRole, setFilterRole] = useState('ALL');
  const [filterAssignedAgent, setFilterAssignedAgent] = useState('ALL');

  const resetAllContactsFilters = () => {
    setFilterFollowUpFrom('');
    setFilterFollowUpTo('');
    setFilterGender('ALL');
    setFilterMaritalStatus('ALL');
    setFilterAgeRange('ALL');
    setFilterIncomeRange('ALL');
    setFilterEducation('ALL');
    setFilterOccupation('ALL');
    setFilterResidency('ALL');
    setFilterState('');
    setFilterCity('');
    setFilterBank('');
    setFilterMedicalHistory([]);
    setFilterActiveStatus('ALL');
    setFilterPolicyCombo('ALL');
    setFilterRole('ALL');
    setFilterAssignedAgent('ALL');
    setFilterProducts([]);
    setExcludeProduct(false);
    setDateFrom('');
    setDateTo('');
    setSearch('');
    setSelectedFilters([]);
  };

  const activeContactsFilterCount = useMemo(() => {
    let count = 0;
    if (filterFollowUpFrom || filterFollowUpTo) count++;
    if (filterGender !== 'ALL') count++;
    if (filterMaritalStatus !== 'ALL') count++;
    if (filterAgeRange !== 'ALL') count++;
    if (filterIncomeRange !== 'ALL') count++;
    if (filterEducation !== 'ALL') count++;
    if (filterOccupation !== 'ALL') count++;
    if (filterResidency !== 'ALL') count++;
    if (filterState) count++;
    if (filterCity) count++;
    if (filterBank) count++;
    if (filterMedicalHistory.length > 0) count++;
    if (filterActiveStatus !== 'ALL' || selectedFilters.includes('Active') || selectedFilters.includes('Inactive')) count++;
    if (filterPolicyCombo !== 'ALL') count++;
    if (filterRole !== 'ALL') count++;
    if (filterAssignedAgent !== 'ALL' && filterAssignedAgent !== '') count++;
    if (filterProducts.length > 0) count++;
    if (dateFrom || dateTo) count++;
    return count;
  }, [
    filterFollowUpFrom, filterFollowUpTo, filterGender, filterMaritalStatus, filterAgeRange,
    filterIncomeRange, filterEducation, filterOccupation, filterResidency, filterState,
    filterCity, filterBank, filterMedicalHistory, filterActiveStatus, selectedFilters, filterPolicyCombo,
    filterRole, filterAssignedAgent, filterProducts, dateFrom, dateTo
  ]);

  const exportContactsToExcel = () => {
    const dataToExport = sortedAndFilteredData.map((c: any) => {
      const contactPolicies = policyMap[c.id] ?? c.policies ?? [];
      const policySummary = contactPolicies.map((p: any) => p.plan?.name || p.plan?.category || p.policyNumber).join('; ');
      return {
        'Contact ID': c.contactId || c.id,
        'First Name': c.firstName || c.contact?.firstName || '',
        'Last Name': c.lastName || c.contact?.lastName || '',
        'Phone / WhatsApp': c.phone || c.contact?.phone || '',
        'Email': c.email || c.contact?.email || '',
        'Gender': c.gender || c.contact?.gender || '',
        'Marital Status': c.maritalStatus || c.contact?.maritalStatus || '',
        'Date of Birth': c.dateOfBirth ? new Date(c.dateOfBirth).toLocaleDateString() : '',
        'Annual Income': c.annualIncome || '',
        'Education': c.education || '',
        'Occupation': c.occupationType || c.contact?.occupations?.[0]?.type || '',
        'State': c.state || c.contact?.addresses?.[0]?.state || '',
        'City': c.city || c.contact?.addresses?.[0]?.city || '',
        'Bank Name': c.bankName || c.contact?.bankAccounts?.[0]?.bankName || '',
        'Lead Stage': c.leadStage || '',
        'Lead Status': c.leadStatus || '',
        'Next Follow-up': c.followUpDate ? new Date(c.followUpDate).toLocaleDateString() : '',
        'Policies': policySummary || 'None',
        'Status': c.isActive !== false ? 'Active' : 'Inactive',
      };
    });

    const worksheet = XLSX.utils.json_to_sheet(dataToExport);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Contacts');
    XLSX.writeFile(workbook, `contacts_export_${new Date().toISOString().slice(0, 10)}.xlsx`);
    toast.success('Contacts exported to Excel successfully!');
  };

  const exportContactsToPdf = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      toast.error('Pop-up blocked. Please allow pop-ups to print PDF');
      return;
    }

    const rowsHtml = sortedAndFilteredData.map((c: any) => `
      <tr style="border-bottom: 1px solid #e2e8f0; font-size: 11px;">
        <td style="padding: 8px;">${((c.firstName || '') + ' ' + (c.lastName || '')).trim() || 'N/A'}</td>
        <td style="padding: 8px; font-weight: 600;">${c.phone || 'N/A'}</td>
        <td style="padding: 8px;">${c.email || 'N/A'}</td>
        <td style="padding: 8px;">${c.city || c.contact?.addresses?.[0]?.city || 'N/A'}</td>
        <td style="padding: 8px;">${c.leadStage || 'N/A'}</td>
        <td style="padding: 8px;">${c.leadStatus || 'N/A'}</td>
        <td style="padding: 8px; text-align: center;"><span style="padding: 2px 6px; border-radius: 4px; background: ${c.isActive !== false ? '#def7ec; color: #03543f;' : '#fde8e8; color: #9b1c1c;'} font-size: 10px; font-weight: bold;">${c.isActive !== false ? 'Active' : 'Inactive'}</span></td>
      </tr>
    `).join('');

    printWindow.document.write(`
      <html>
        <head>
          <title>Contacts Export Report</title>
          <style>
            body { font-family: system-ui, -apple-system, sans-serif; color: #1e293b; padding: 24px; }
            table { width: 100%; border-collapse: collapse; margin-top: 20px; }
            th { background: #f8fafc; border-bottom: 2px solid #e2e8f0; padding: 10px 8px; text-align: left; font-size: 11px; font-weight: bold; text-transform: uppercase; color: #64748b; }
            .header { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #3b82f6; padding-bottom: 12px; }
            .title { font-size: 20px; font-weight: 800; color: #1e3a8a; }
            .meta { font-size: 11px; color: #64748b; text-align: right; }
          </style>
        </head>
        <body>
          <div class="header">
            <div>
              <div class="title">INSU-MITRA</div>
              <div style="font-size: 12px; color: #475569; font-weight: 600;">Contacts Export Report</div>
            </div>
            <div class="meta">
              <div>Date: ${new Date().toLocaleString()}</div>
              <div>Record Count: ${sortedAndFilteredData.length}</div>
            </div>
          </div>
          <table>
            <thead>
              <tr>
                <th style="width: 25%;">Name</th>
                <th style="width: 15%;">Phone</th>
                <th style="width: 20%;">Email</th>
                <th style="width: 15%;">City</th>
                <th style="width: 10%;">Stage</th>
                <th style="width: 10%;">Status</th>
                <th style="width: 5%; text-align: center;">Active</th>
              </tr>
            </thead>
            <tbody>
              ${rowsHtml}
            </tbody>
          </table>
          <script>
            window.onload = function() {
              window.print();
              setTimeout(() => { window.close(); }, 500);
            };
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  const [newRelType, setNewRelType] = useState('');
  const [newRelName, setNewRelName] = useState('');
  const [newRelPhone, setNewRelPhone] = useState('');
  const [newRelDob, setNewRelDob] = useState('');
  const [showAddRelForm, setShowAddRelForm] = useState(false);

  // Phone Directory import states
  const [dirImportOpen, setDirImportOpen] = useState(false);
  const [dirText, setDirText] = useState('');

  // Customer modal state
  const [leadModalOpen, setLeadModalOpen] = useState(false);
  const [isViewMode, setIsViewMode] = useState(false);
  const [activeLeadTab, setActiveLeadTab] = useState('Personal');
  const [contactNavHistory, setContactNavHistory] = useState<Array<{
    contactId: string;
    leadId?: string | null;
    activeTab: string;
    isViewMode: boolean;
    contactName?: string;
  }>>([]);
  const [parentNavInfo, setParentNavInfo] = useState<{ parentContactId: string; returnTab?: string } | null>(null);
  const parentNavInfoRef = useRef<{ parentContactId: string; returnTab?: string } | null>(null);

  type PersonalFields = Record<string, any>;

  const [personalFields, setPersonalFields] = useState<PersonalFields>({
    role: 'Contact',
    contactStatus: 'Active',
    isActive: true,
    firstName: '',
    middleName: '',
    lastName: '',
    motherName: '',
    fullName: '',
    gender: '',
    maritalStatus: '',
    dateOfBirth: '',
    birthPlace: '',
    age: '',
    height: '',
    weight: '',
    pan: '',
    panNumber: '',
    declaredMedicalHistory: [] as string[],
    notDeclaredMedicalHistory: [] as string[],
    medicalHistoryDetails: "",
    email: '',
    aadhaarNumber: '',
    whatsappNumber: '',
    sameAsWhatsapp: false,
    callingNumber: '',
    education: '',
    annualIncome: '',
    occupationType: '',
    companyName: '',
    state: '',
    district: '',
    city: '',
    pincode: '',
    streetAddress: '',
    bankName: '',
    bankAccountNumber: '',
    bankIfsc: '',
    bankBranch: '',
    chewTobacco: false,
    smoke: false,
    consumeAlcohol: false,
    surgeryDetails: '',
    prescriptionDetails: '',
    assignedEmployeeId: '',
    assignedEmployeeIds: [] as string[],
  });

  const [leadInfoFields, setLeadInfoFields] = useState({
    profileType: 'Lead Profile', // 'Lead Profile' | 'Client Profile'
    leadStatus: 'OPEN',
    interestedIn: ['Health'], // Health, Term, Mutual Funds, Pooling, Other
    leadSource: 'Walkin',
    assignedEmployeeId: '',
    followUpDate: '',
  });

  const [leadComments, setLeadComments] = useState<string[]>([]);
  const [newComment, setNewComment] = useState('');

  // Product Interest Cards state
  type ProductComment = { text: string; author: string; datetime: string };
  type ProductInterestCard = {
    id: string;
    collapsed: boolean;
    interestedIn: string[];
    otherProduct: string;
    descriptionDetails?: string;
    leadStage: string;
    leadStatus: string;
    dependencyType?: string;
    dependentDetails?: string;
    leadType: string;
    leadSource: string;
    assignedEmployeeId: string;
    followUpDate: string;
    expectedPremium: string;
    comments: ProductComment[];
    newComment: string;
    showAllComments?: boolean;
  };

  function parseLeadNotes(notesText?: string | null) {
    const res = {
      leadStatus: 'INTERESTED',
      leadType: 'FRESH',
      cleanNotes: '',
      dependencyType: 'SELF',
      dependentDetails: '',
      descriptionDetails: '',
    };
    if (!notesText) return res;
    if (notesText.trim().startsWith('{')) {
      try {
        const parsed = JSON.parse(notesText);
        res.leadStatus = parsed.leadStatus || 'INTERESTED';
        res.leadType = parsed.leadType || 'FRESH';
        res.cleanNotes = parsed.cleanNotes || '';
        res.dependencyType = parsed.dependencyType || 'SELF';
        res.dependentDetails = parsed.dependentDetails || '';
        res.descriptionDetails = parsed.descriptionDetails || '';
        return res;
      } catch (e) { }
    }
    const lines = notesText.split('\n');
    const cleanLines: string[] = [];
    lines.forEach(line => {
      if (line.startsWith('Status: ')) {
        res.leadStatus = line.replace('Status: ', '').trim();
      } else if (line.startsWith('Type: ')) {
        res.leadType = line.replace('Type: ', '').trim();
      } else if (line.startsWith('Dependency: ')) {
        res.dependencyType = line.replace('Dependency: ', '').trim();
      } else if (line.startsWith('Dependent Details: ')) {
        res.dependentDetails = line.replace('Dependent Details: ', '').trim();
      } else if (line.startsWith('Description Details: ')) {
        res.descriptionDetails = line.replace('Description Details: ', '').trim();
      } else {
        cleanLines.push(line);
      }
    });
    res.cleanNotes = cleanLines.join('\n').trim();
    return res;
  }

  function serializeLeadNotes(card: ProductInterestCard) {
    return JSON.stringify({
      leadStatus: card.leadStatus,
      leadType: card.leadType,
      dependencyType: card.dependencyType || 'SELF',
      dependentDetails: card.dependencyType === 'DEPENDENT' ? (card.dependentDetails || '') : '',
      descriptionDetails: card.descriptionDetails || '',
      cleanNotes: card.otherProduct ? `Other Product: ${card.otherProduct}` : '',
    });
  }

  const newProductInterestCard = (): ProductInterestCard => ({
    id: 'temp-' + Math.random().toString(36).slice(2),
    collapsed: false,
    interestedIn: [],
    otherProduct: '',
    descriptionDetails: '',
    leadStage: 'TO_CONTACT',
    leadStatus: 'INTERESTED',
    dependencyType: 'SELF',
    dependentDetails: '',
    leadType: 'FRESH',
    leadSource: 'Walkin',
    assignedEmployeeId: '',
    followUpDate: '',
    expectedPremium: '',
    comments: [],
    newComment: '',
    showAllComments: false,
  });

  const [productInterests, setProductInterests] = useState<ProductInterestCard[]>([]);

  const addProductInterest = () =>
    setProductInterests(prev => [...prev, newProductInterestCard()]);

  const removeProductInterest = async (id: string) => {
    const isExisting = id.length === 24 || /^[0-9a-fA-F]{24}$/.test(id);
    if (isExisting) {
      if (!confirm('Are you sure you want to delete this product interest from the server?')) return;
      const toastId = toast.loading('Deleting product interest...');
      try {
        await leadsService.remove(id);
        toast.success('Product interest deleted from server successfully!', { id: toastId });
        qc.invalidateQueries({ queryKey: ['contacts'] });
        qc.invalidateQueries({ queryKey: ['leads'] });
      } catch (err: any) {
        toast.error('Failed to delete product interest from server', { id: toastId });
        return;
      }
    }
    setProductInterests(prev => prev.filter(c => c.id !== id));
  };

  const updateProductInterest = (id: string, field: keyof ProductInterestCard, value: any) =>
    setProductInterests(prev => prev.map(c => c.id === id ? { ...c, [field]: value } : c));

  const toggleProductCollapse = (id: string) =>
    setProductInterests(prev => prev.map(c => c.id === id ? { ...c, collapsed: !c.collapsed } : c));

  const addProductComment = async (id: string) => {
    const card = productInterests.find(c => c.id === id);
    if (!card || !card.newComment.trim()) return;

    const user = useAuthStore.getState().user;
    const author = user ? `${user.firstName || ''} ${user.lastName || ''}`.trim() || user.email || 'User' : 'User';
    const commentText = card.newComment.trim();

    const isExisting = id.length === 24 || /^[0-9a-fA-F]{24}$/.test(id);
    if (isExisting) {
      const toastId = toast.loading('Adding comment...');
      try {
        await leadsService.addConsultation(id, { notes: commentText });
        toast.success('Comment added successfully!', { id: toastId });
        qc.invalidateQueries({ queryKey: ['contacts'] });
        qc.invalidateQueries({ queryKey: ['leads'] });
      } catch (err: any) {
        toast.error('Failed to save comment to server', { id: toastId });
      }
    }

    const comment = {
      text: commentText,
      author,
      datetime: new Date().toLocaleString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }),
    };

    setProductInterests(prev => prev.map(c => {
      if (c.id !== id) return c;
      return { ...c, comments: [...c.comments, comment], newComment: '' };
    }));
  };

  const saveProductInterestCard = async (cardId: string) => {
    if (!editContactId) {
      toast.error('Please save the contact details first');
      return;
    }
    const card = productInterests.find(c => c.id === cardId);
    if (!card) return;

    const isExisting = card.id.length === 24 || /^[0-9a-fA-F]{24}$/.test(card.id);

    // If new card, validate all required fields
    if (!isExisting) {
      if (!card.interestedIn || card.interestedIn.length === 0) {
        toast.error('Please select at least one Product Category (Interested In)');
        return;
      }
      if (card.interestedIn.includes('Other') && !card.otherProduct?.trim()) {
        toast.error('Please specify the Other Product Name');
        return;
      }
      if (card.dependencyType === 'DEPENDENT' && !card.dependentDetails?.trim()) {
        toast.error('Please enter dependent details (Name/Relation)');
        return;
      }
      if (!card.leadSource?.trim()) {
        toast.error('Please select or enter a Lead Source');
        return;
      }
      if (!card.followUpDate?.trim()) {
        toast.error('Please select a Follow-up Date');
        return;
      }
      if (!card.expectedPremium || Number(card.expectedPremium) <= 0) {
        toast.error('Please enter a valid Expected Premium / Budget (> 0)');
        return;
      }
    }

    const product = card.interestedIn[0] || 'Other';
    const toastId = toast.loading(isExisting ? 'Updating product interest status...' : 'Saving product interest...');
    try {
      const interests = [product === 'Other' && card.otherProduct ? card.otherProduct : product];

      let stage = card.leadStage && card.leadStage !== 'OPEN' ? card.leadStage : 'TO_CONTACT';

      const serializedNotes = serializeLeadNotes(card);

      const validEmpId = (id?: string) => (id && /^[0-9a-fA-F]{24}$/.test(id.trim())) ? id.trim() : undefined;
      const body = {
        contactId: editContactId,
        interests,
        stage,
        source: card.leadSource,
        assignedEmployeeId: validEmpId(card.assignedEmployeeId),
        followUpDate: card.followUpDate?.trim() ? new Date(card.followUpDate).toISOString() : undefined,
        premiumBudget: Number(card.expectedPremium) || undefined,
        notes: serializedNotes,
      };

      if (isExisting) {
        await leadsService.update(card.id, body);
        toast.success('Product interest status updated successfully!', { id: toastId });
      } else {
        const res = await leadsService.create(body);
        const savedLead = res.data ?? res;
        setProductInterests(prev => prev.map(c => c.id === cardId ? { ...c, id: savedLead.id } : c));
        toast.success('Product interest created successfully!', { id: toastId });
      }
      qc.invalidateQueries({ queryKey: ['contacts'] });
      qc.invalidateQueries({ queryKey: ['leads'] });
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Failed to save product interest', { id: toastId });
    }
  };

  const [selectedCampaigns, setSelectedCampaigns] = useState<string[]>([]);

  // Family members state
  const [familyMembers, setFamilyMembers] = useState<Array<Record<string, any>>>([]);


  const toSafeIsoString = (val?: string | null): string | undefined => {
    if (!val || !val.trim()) return undefined;
    const trimmed = val.trim();

    // Try native Date
    const d = new Date(trimmed);
    if (!isNaN(d.getTime())) return d.toISOString();

    // Handle DD/MMM/YYYY or DD/MM/YYYY or DD-MM-YYYY
    const MONTHS: Record<string, number> = {
      jan: 0, feb: 1, mar: 2, apr: 3, may: 4, jun: 5,
      jul: 6, aug: 7, sep: 8, oct: 9, nov: 10, dec: 11
    };
    const parts = trimmed.split(/[\/\-\.\s]+/);
    if (parts.length === 3) {
      let day: number, mon: number, year: number;
      if (/^\d{4}$/.test(parts[0])) {
        year = parseInt(parts[0], 10);
        mon = parseInt(parts[1], 10) - 1;
        day = parseInt(parts[2], 10);
      } else {
        day = parseInt(parts[0], 10);
        const mStr = parts[1].toLowerCase();
        if (/^\d+$/.test(mStr)) {
          mon = parseInt(mStr, 10) - 1;
        } else if (MONTHS[mStr.slice(0, 3)] !== undefined) {
          mon = MONTHS[mStr.slice(0, 3)];
        } else {
          return undefined;
        }
        year = parseInt(parts[2], 10);
      }
      const parsed = new Date(year, mon, day);
      if (!isNaN(parsed.getTime())) return parsed.toISOString();
    }

    return undefined;
  };

  const openAddFamilyMemberModal = () => {
    setEditingFamilyMemberIdx(null);
    setSelectedFamilyMemberForModal(null);
    setFamilyMemberModalOpen(true);
  };

  const openEditFamilyMemberModal = (idx: number, memberData?: any) => {
    setEditingFamilyMemberIdx(idx);
    setSelectedFamilyMemberForModal(memberData || familyMembers[idx] || null);
    setFamilyMemberModalOpen(true);
  };

  const handleSaveFamilyMemberFromModal = async (savedMember: Record<string, any>) => {
    const targetIdx = editingFamilyMemberIdx;
    if (targetIdx !== null && targetIdx >= 0) {
      setFamilyMembers(prev => prev.map((m, i) => i === targetIdx ? { ...m, ...savedMember } : m));
    } else {
      setFamilyMembers(prev => [...prev, {
        addedAt: new Date().toISOString(),
        ...savedMember,
      }]);
    }
    setFamilyMemberModalOpen(false);
    setEditingFamilyMemberIdx(null);
    setSelectedFamilyMemberForModal(null);

    // If editing an existing contact, persist immediately to server
    if (editContactId) {
      const fam = savedMember;
      const famFirst = (fam.firstName || '').trim() || (fam.name || '').trim().split(/\s+/)[0] || '';
      const famMiddle = (fam.middleName || '').trim();
      const famLast = (fam.lastName || '').trim() || (fam.name || '').trim().split(/\s+/).slice(1).join(' ') || '';
      const fullFamName = `${famFirst} ${famMiddle} ${famLast}`.replace(/\s+/g, ' ').trim();
      if (!fullFamName) return;

      const rawMainPhone = (personalFields.whatsappNumber || personalFields.callingNumber || loadedContact?.phone || '').replace(/\D/g, '');
      const cleanMainPhone = rawMainPhone.length > 10 ? rawMainPhone.slice(-10) : rawMainPhone;

      const rawFamPhone = (fam.whatsapp || fam.whatsappNumber || fam.phone || fam.contactNo || (fam.isDependent ? cleanMainPhone : '')).replace(/\D/g, '');
      const cleanFamPhone = rawFamPhone.length > 10 ? rawFamPhone.slice(-10) : rawFamPhone;
      let validFamPhone = (cleanFamPhone.length === 10 && !cleanFamPhone.startsWith('00') && cleanFamPhone !== '0000000000')
        ? cleanFamPhone
        : (rawFamPhone.length >= 7 && !rawFamPhone.startsWith('00') && rawFamPhone !== '0000000000' ? rawFamPhone : (rawFamPhone || undefined));

      if (fam.isDependent && (!validFamPhone || validFamPhone.startsWith('00') || validFamPhone === '0000000000')) {
        validFamPhone = cleanMainPhone || undefined;
      }

      const rawFamCall = (fam.callingNumber || fam.alternatePhone || (fam.isDependent ? (validFamPhone || cleanMainPhone) : '')).replace(/\D/g, '');
      const cleanFamCall = rawFamCall.length > 10 ? rawFamCall.slice(-10) : rawFamCall;
      let validFamCall = (cleanFamCall.length === 10 && !cleanFamCall.startsWith('00') && cleanFamCall !== '0000000000')
        ? cleanFamCall
        : (rawFamCall.length >= 7 && !rawFamCall.startsWith('00') && rawFamCall !== '0000000000' ? rawFamCall : (rawFamCall || undefined));
      const relType = fam.relation ? fam.relation.toUpperCase().replace(/\s+/g, '_') : 'OTHER';
      const famIsoDob = toSafeIsoString(fam.dob || fam.dateOfBirth);

      const rawDepNo = (fam.guardianWhatsapp || fam.dependentNo || (fam.isDependent ? (validFamPhone || cleanMainPhone) : '') || '').replace(/\D/g, '');
      const depNo = rawDepNo.length > 10 ? rawDepNo.slice(-10) : rawDepNo;

      const famPayload: any = {
        firstName: famFirst,
        middleName: famMiddle || undefined,
        lastName: famLast,
        phone: validFamPhone || (fam.isDependent ? cleanMainPhone : '') || '',
        alternatePhone: validFamCall || (fam.isDependent ? (validFamPhone || cleanMainPhone) : undefined),
        email: fam.email ? fam.email.trim() : undefined,
        dateOfBirth: famIsoDob,
        gender: fam.gender || undefined,
        birthPlace: fam.birthPlace ? fam.birthPlace.trim() : undefined,
        motherName: fam.motherName ? fam.motherName.trim() : undefined,
        isDependent: !!fam.isDependent,
        dependentNo: depNo || undefined,
        panNumber: fam.pan || fam.panNumber || undefined,
        aadhaarNumber: fam.aadhaarNumber || undefined,
        annualIncome: fam.annualIncome ? Number(fam.annualIncome) : undefined,
        maritalStatus: fam.maritalStatus || '',
        weddingAnniversaryDate: fam.weddingAnniversary || fam.weddingAnniversaryDate || '',
        education: fam.education || '',
        occupation: fam.occupation || fam.occupationType || '',
        height: fam.height || '',
        weight: fam.weight || '',
        chewTobacco: !!fam.chewTobacco,
        smoke: !!fam.smoke,
        consumeAlcohol: !!fam.consumeAlcohol,
        medicalHistory: fam.medicalHistory || [],
        declaredMedicalHistory: fam.declaredMedicalHistory || [],
        notDeclaredMedicalHistory: fam.notDeclaredMedicalHistory || [],
        medicalHistoryDetails: fam.medicalHistoryDetails || '',
        surgeryDetails: fam.surgeryDetails || '',
        prescriptionDetails: fam.prescriptionDetails || '',
        bankName: fam.bankName ? fam.bankName.trim() : '',
        bankAccountNumber: fam.bankAccountNumber ? fam.bankAccountNumber.trim() : '',
        bankIfsc: (fam.bankIfsc || '').trim().toUpperCase(),
        bankBranch: fam.bankBranch ? fam.bankBranch.trim() : '',
        streetAddress: fam.streetAddress || undefined,
        line1: fam.streetAddress || undefined,
        city: fam.city || undefined,
        district: fam.district || undefined,
        state: fam.state || undefined,
        pincode: fam.pincode || undefined,
      };

      try {
        let targetFamContactId = fam.contactId;
        if (targetFamContactId && targetFamContactId !== editContactId) {
          await contactsService.update(targetFamContactId, famPayload);
          const hasFamAddr = Boolean(
            (fam.streetAddress && fam.streetAddress.trim() && fam.streetAddress.trim() !== 'N/A') ||
            (fam.city && fam.city.trim() && fam.city.trim() !== 'N/A') ||
            (fam.state && fam.state.trim() && fam.state.trim() !== 'N/A') ||
            (fam.district && fam.district.trim()) ||
            (fam.pincode && fam.pincode.trim() && fam.pincode.trim() !== 'N/A')
          );
          if (hasFamAddr) {
            await contactsService.addAddress(targetFamContactId, {
              type: 'HOME',
              line1: fam.streetAddress?.trim() || 'N/A',
              city: fam.city?.trim() || 'N/A',
              district: fam.district?.trim() || undefined,
              state: fam.state?.trim() || 'N/A',
              pincode: fam.pincode?.trim() || 'N/A',
              country: 'India',
              isPrimary: true,
            }).catch(err => console.error('Failed to update family member address:', err));
          }
          if (fam.id) {
            await contactsService.updateRelationship(editContactId, fam.id, {
              relatedContactId: targetFamContactId,
              relationshipType: relType,
              relationship: relType,
              ...famPayload,
            });
          } else {
            await contactsService.addRelationship(editContactId, {
              relatedContactId: targetFamContactId,
              relationshipType: relType,
              relationship: relType,
              ...famPayload,
            });
          }
        } else {
          const addRes = await contactsService.addRelationship(editContactId, {
            name: fullFamName,
            relationshipType: relType,
            relationship: relType,
            ...famPayload,
          });
          const relData = addRes?.data?.relationship || addRes?.data || addRes;
          const relatedC = relData?.relatedContact || addRes?.data?.relatedContact;
          if (relatedC?.id) {
            targetFamContactId = relatedC.id;
            setFamilyMembers(prev => prev.map(m => (m === savedMember || m.name === fullFamName) ? { ...m, contactId: relatedC.id } : m));
          }
        }
        toast.success(targetIdx !== null && targetIdx >= 0 ? 'Family member details updated and saved' : 'Family member added and saved');

        // Refresh contact relationships from server
        contactsService.get(editContactId).then(res => {
          const contact = res?.data?.data || res?.data || res;
          if (contact && Array.isArray(contact.relationships)) {
            const rels1 = contact.relationships.map((r: any) => {
              const c = r.relatedContact || r.contact || {};
              const parsedNames = extractNameFields(c);
              const firstAddr = c.addresses?.[0] || {};
              const firstOcc = c.occupations?.find((o: any) => o.isPrimary) || c.occupations?.[0] || {};
              const rawDob = c?.dateOfBirth ? c.dateOfBirth.split('T')[0] : '';
              const computedAge = rawDob ? String(calculateAge(rawDob)) : '';
              const mainContactPhone = (contact?.phone && !contact.phone.startsWith('00') && contact.phone !== '0000000000') ? (contact.phone.replace(/\D/g, '').length > 10 ? contact.phone.replace(/\D/g, '').slice(-10) : contact.phone) : '';
              const isDep = !!(c?.isDependent || r?.isDependent);
              const rawDepPhone = isDep ? (c?.dependentNo || r?.dependentNo || mainContactPhone) : '';
              const depPhone = (rawDepPhone.replace(/\D/g, '').length > 10 && !rawDepPhone.startsWith('00')) ? rawDepPhone.replace(/\D/g, '').slice(-10) : rawDepPhone;
              const rawFamPhone = (c?.phone && !c.phone.startsWith('00') && c.phone !== '0000000000') ? c.phone : (r?.phone && !r.phone.startsWith('00') && r.phone !== '0000000000' ? r.phone : depPhone);
              const famPhone = (rawFamPhone.replace(/\D/g, '').length > 10 && !rawFamPhone.startsWith('00')) ? rawFamPhone.replace(/\D/g, '').slice(-10) : rawFamPhone;
              const rawFamAlt = (c?.alternatePhone && !c.alternatePhone.startsWith('00') && c.alternatePhone !== '0000000000') ? c.alternatePhone : (r?.alternatePhone && !r.alternatePhone.startsWith('00') && r.alternatePhone !== '0000000000' ? r.alternatePhone : (isDep ? famPhone : ''));
              const famAltPhone = (rawFamAlt.replace(/\D/g, '').length > 10 && !rawFamAlt.startsWith('00')) ? rawFamAlt.replace(/\D/g, '').slice(-10) : rawFamAlt;
              return {
                id: r.id,
                contactId: c.id,
                addedAt: r.createdAt || c.createdAt || contact.createdAt || new Date().toISOString(),
                name: `${parsedNames.firstName} ${parsedNames.middleName} ${parsedNames.lastName}`.replace(/\s+/g, ' ').trim(),
                firstName: parsedNames.firstName,
                middleName: parsedNames.middleName,
                lastName: parsedNames.lastName,
                dob: rawDob,
                dateOfBirth: rawDob,
                relation: r.relationshipType || 'OTHER',
                gender: c?.gender || '',
                birthPlace: c?.birthPlace || '',
                isDependent: isDep,
                guardianWhatsapp: c?.dependentNo || (isDep ? depPhone : ''),
                dependentNo: c?.dependentNo || (isDep ? depPhone : ''),
                motherName: c?.motherName || '',
                email: c?.email || '',
                aadhaarNumber: c?.aadhaarNumber || '',
                pan: c?.panNumber || c?.pan || '',
                panNumber: c?.panNumber || c?.pan || '',
                phone: famPhone,
                contactNo: famPhone,
                whatsapp: famPhone,
                whatsappNumber: famPhone,
                callingNumber: famAltPhone,
                alternatePhone: famAltPhone,
                sameAsWhatsapp: !!(famPhone && famAltPhone && famPhone === famAltPhone),
                role: c?.role || 'Contact',
                contactStatus: c?.isActive !== false ? 'Active' : 'Inactive',
                occupation: firstOcc.type || c?.occupation || '',
                occupationType: firstOcc.type || c?.occupation || '',
                companyName: firstOcc.companyName || '',
                annualIncome: c?.annualIncome != null ? String(c.annualIncome) : (firstOcc.annualIncome != null ? String(firstOcc.annualIncome) : ''),
                education: c.education || '',
                maritalStatus: c.maritalStatus || '',
                weddingAnniversary: c.weddingAnniversaryDate || '',
                weddingAnniversaryDate: c.weddingAnniversaryDate || '',
                state: firstAddr.state || '',
                district: firstAddr.district || '',
                city: firstAddr.city || '',
                pincode: firstAddr.pincode || '',
                streetAddress: firstAddr.line1 ? `${firstAddr.line1}${firstAddr.line2 ? ', ' + firstAddr.line2 : ''}` : '',
                bankName: c?.bankName || '',
                bankAccountNumber: c?.bankAccountNumber || '',
                bankIfsc: c?.bankIfsc || '',
                bankBranch: c?.bankBranch || '',
                chewTobacco: !!c?.chewTobacco,
                smoke: !!c?.smoke,
                consumeAlcohol: !!c?.consumeAlcohol,
                height: c.height == null ? '' : String(c.height),
                weight: c.weight == null ? '' : String(c.weight),
                age: computedAge,
                medicalHistory: c.medicalHistory || [],
                declaredMedicalHistory: c.declaredMedicalHistory || [],
                notDeclaredMedicalHistory: c.notDeclaredMedicalHistory || [],
                medicalHistoryDetails: c.medicalHistoryDetails || '',
                surgeryDetails: c.surgeryDetails || '',
                prescriptionDetails: c.prescriptionDetails || ''
              };
            });
            setFamilyMembers(rels1);
          }
        }).catch(() => {});
      } catch (err: any) {
        console.error('Failed to save family member to backend:', err);
        toast.error(`Failed to save family member: ${err?.response?.data?.message || err?.message || 'Error'}`);
      }
    } else {
      toast.success(targetIdx !== null && targetIdx >= 0 ? 'Family member details updated' : 'Family member added');
    }
  };

  const handleDeleteFamilyMember = async (idx: number) => {
    const member = familyMembers[idx];
    setFamilyMembers(prev => prev.filter((_, i) => i !== idx));
    toast.success('Family member removed');

    if (editContactId && member?.id) {
      try {
        await contactsService.removeRelationship(editContactId, member.id);
      } catch (err) {
        console.error('Failed to remove relationship from backend:', err);
      }
    }
  };

  const addFamilyMember = () => {
    openAddFamilyMemberModal();
  };

  const updateFamilyMember = (idx: number, field: string, value: any) =>
    setFamilyMembers(prev => prev.map((m, i) => i === idx ? { ...m, [field]: value } : m));

  const updateFamilyMemberName = (idx: number, firstName: string, middleName: string, lastName: string) =>
    setFamilyMembers(prev => prev.map((m, i) => i === idx ? {
      ...m,
      firstName,
      middleName,
      lastName,
      name: [firstName, middleName, lastName].filter(Boolean).join(' '),
    } : m));

  const [familyCollapsed, setFamilyCollapsed] = useState<Record<number, boolean>>({});
  const toggleFamilyCollapse = (idx: number) => {
    setFamilyCollapsed(prev => ({ ...prev, [idx]: !prev[idx] }));
  };

  const updateFamilyMemberDOB = (idx: number, val: string) => {
    let age = 0;
    if (val) {
      try {
        let birthDate = new Date(val);
        if (isNaN(birthDate.getTime()) && val.includes('/')) {
          const parts = val.split('/');
          if (parts.length === 3) {
            birthDate = new Date(Number(parts[2]), Number(parts[1]) - 1, Number(parts[0]));
          }
        }
        if (!isNaN(birthDate.getTime())) {
          const today = new Date();
          let a = today.getFullYear() - birthDate.getFullYear();
          const monthDiff = today.getMonth() - birthDate.getMonth();
          if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
            a--;
          }
          if (a >= 0) age = a;
        }
      } catch {}
    }
    setFamilyMembers(prev => prev.map((m, i) => i === idx ? {
      ...m,
      dob: val,
      age: age > 0 ? String(age) : m.age
    } : m));
  };

  const toggleMedicalHistory = (idx: number, condition: string) =>
    setFamilyMembers(prev => prev.map((m, i) => {
      if (i !== idx) return m;
      const list = m.medicalHistory || [];
      const has = list.includes(condition);
      return { ...m, medicalHistory: has ? list.filter((c: string) => c !== condition) : [...list, condition] };
    }));

  // Policy state — Portfolio (Health/Life) → Entries
  type PolicyItem = {
    company: string; planName: string; policyNo: string;
    startDate: string; duration: string; endDate: string;
    premium: string;
    // Health
    sumInsured: string; deductible: string;
    // Life
    sumAssured: string; maturityDate: string; paymentTerm: string;
    entryType: 'New' | 'Renewal';
  };
  type PolicyPortfolio = { policyType: 'Health' | 'Life'; entries: PolicyItem[] };
  const [policies, setPolicies] = useState<PolicyPortfolio[]>([]);

  // Personal Info Collapsed Sub-Sections State
  const INITIAL_PERSONAL_COLLAPSED: Record<string, boolean> = {
    personalDetails: false,
    contactDetails: true,
    educationOccupation: true,
    addressDetails: true,
    bankDetails: true,
    lifestyleHabits: true,
    healthHistory: false,
    surgeryDetails: false,
    prescriptionDetails: false,
  };

  const [personalCollapsed, setPersonalCollapsed] = useState<Record<string, boolean>>(INITIAL_PERSONAL_COLLAPSED);
  const togglePersonalCollapse = (key: string) =>
    setPersonalCollapsed(prev => ({ ...prev, [key]: !prev[key] }));

  const newPolicyItem = (): PolicyItem => ({
    company: '', planName: '', policyNo: '',
    startDate: '', duration: '1 Year', endDate: '',
    premium: '', sumInsured: '', deductible: '',
    sumAssured: '', maturityDate: '', paymentTerm: '',
    entryType: 'New'
  });

  const addPolicy = (policyType: 'Health' | 'Life') =>
    setPolicies(prev => [...prev, { policyType, entries: [newPolicyItem()] }]);

  const addPolicyEntry = (pIdx: number) =>
    setPolicies(prev => prev.map((p, i) => i === pIdx ? { ...p, entries: [...p.entries, newPolicyItem()] } : p));

  const removePolicyEntry = (pIdx: number, eIdx: number) =>
    setPolicies(prev => prev.map((p, i) => {
      if (i !== pIdx) return p;
      const entries = p.entries.filter((_, j) => j !== eIdx);
      return entries.length === 0 ? null : { ...p, entries };
    }).filter(Boolean) as PolicyPortfolio[]);

  const updatePolicyItem = (pIdx: number, eIdx: number, field: string, value: string) =>
    setPolicies(prev => prev.map((p, i) => i !== pIdx ? p : {
      ...p,
      entries: p.entries.map((e, j) => j !== eIdx ? e : { ...e, [field]: value })
    }));

  // Fetch employees lookup to map assignee name
  const { employees, plans: dbPlans, loadEmployees } = useLookupStore();

  useEffect(() => {
    loadEmployees();
  }, [loadEmployees]);

  const employeesList = useMemo(() => {
    const raw = (employees as any)?.data || employees;
    return Array.isArray(raw) ? raw : [];
  }, [employees]);
  const normalizeEmployeeUserId = (id?: string) => {
    if (!id) return '';
    const employee = employeesList.find((item: any) =>
      item.id === id || item.userId === id || item.user?.id === id
    );
    return employee?.userId || employee?.user?.id || id;
  };

  const { data: contactsRes, isLoading: contactsLoading, refetch: refetchContacts } = useContacts({
    limit: 2000,
    search: search || undefined,
    sortBy: 'createdAt',
    sortOrder: 'desc',
  });

  const contactsListArray = useMemo(() => {
    if (!contactsRes) return [];
    if (Array.isArray(contactsRes.data)) return contactsRes.data;
    if (Array.isArray(contactsRes.data?.data)) return contactsRes.data.data;
    if (Array.isArray(contactsRes)) return contactsRes;
    return [];
  }, [contactsRes]);

  const { data: birthdayRes, isLoading: birthdayLoading } = useUpcomingBirthdays(30, activeTab === 'birthdays');
  const birthdayList = birthdayRes?.data ?? [];

  // Query plans for Lead creation Policy tab (using empty/mock variables to satisfy compilation)
  const leadPlansList: any[] = [];

  // Fetch policies & claims for customer tab and product filtering enrichment
  const { data: policiesRes } = useQuery({
    queryKey: ['contacts-policies-list'],
    queryFn: () => policiesService.list({ limit: 2000, sortBy: 'createdAt', sortOrder: 'desc' }),
    enabled: true,
    staleTime: 60_000,
  });

  const { data: claimsRes } = useClaims({ page: 1, limit: 500 });

  const CONTACT_DOC_TYPES = useMemo(() => [
    { value: 'IDENTITY_PROOF',          label: 'Aadhaar / PAN / Identity Proof' },
    { value: 'POLICY_BOND',             label: 'Policy Bond / Endorsement' },
    { value: 'CLAIM_FORM',              label: 'Claim Form' },
    { value: 'DISCHARGE_SUMMARY',       label: 'Discharge Summary' },
    { value: 'OT_NOTES_IPD_PAPERS',     label: 'OT Notes / IPD Papers' },
    { value: 'HOSPITAL_BILL',           label: 'Hospital Bill / Breakup Bill' },
    { value: 'PHARMACY_MEDICINES_BILL', label: 'Pharmacy / Medicines Bill' },
    { value: 'INVESTIGATION_LAB_BILL',  label: 'Investigation / Lab Bill' },
    { value: 'BLOOD_ANESTHESIA_BILL',   label: 'Blood / Anesthesia Bill' },
    { value: 'IMPORTANT_LAB_REPORTS',   label: 'Important Lab Reports' },
    { value: 'IMP_BILLS',               label: 'Imp Bills' },
    { value: 'OTHER_IMP_DOCS',          label: 'Other Imp Documents' },
    { value: 'QUERY_LETTER',            label: 'Claim Query Letter' },
    { value: 'REPLY_DOCS',              label: 'Reply Documents' },
    { value: 'SETTLEMENT_LETTER',       label: 'Claim Settlement Letter' },
    { value: 'REJECTION_LETTER',        label: 'Rejection Letter' },
    { value: 'OTHER',                   label: 'Other Document' },
  ], []);

  const { data: contactDocsRes } = useQuery({
    queryKey: ['contact-documents-list', editContactId || loadedContact?.id || loadedContact?.contactId],
    queryFn: () => documentsService.list({ contactId: editContactId || loadedContact?.id || loadedContact?.contactId }),
    enabled: activeLeadTab === 'Documents' && !!(editContactId || loadedContact?.id || loadedContact?.contactId),
    staleTime: 0,
  });

  const contactDocsList = useMemo(() => {
    if (!contactDocsRes) return [];
    if (Array.isArray(contactDocsRes.data)) return contactDocsRes.data;
    if (Array.isArray(contactDocsRes.data?.data)) return contactDocsRes.data.data;
    if (Array.isArray(contactDocsRes)) return contactDocsRes;
    return [];
  }, [contactDocsRes]);

  const claimListArray = useMemo(() => {
    if (!claimsRes) return [];
    if (Array.isArray(claimsRes.data)) return claimsRes.data;
    if (Array.isArray(claimsRes.data?.data)) return claimsRes.data.data;
    if (Array.isArray(claimsRes)) return claimsRes;
    return [];
  }, [claimsRes]);

  const claimMap = useMemo(() => {
    const map: Record<string, any[]> = {};
    claimListArray.forEach((c: any) => {
      const keys = [
        c.contactId,
        c.contact?.id,
        c.contact?.contactId,
        c.policyId,
        c.policy?.id,
        c.contact?.phone,
        c.phone,
      ].filter(Boolean);
      keys.forEach(k => {
        if (!map[k]) map[k] = [];
        if (!map[k].some((existing: any) => existing.id === c.id)) {
          map[k].push(c);
        }
      });
    });
    return map;
  }, [claimListArray]);

  // Extract policy array safely handling direct arrays & paginated response structures
  const policyListArray = useMemo(() => {
    if (!policiesRes) return [];
    if (Array.isArray(policiesRes.data)) return policiesRes.data;
    if (Array.isArray(policiesRes.data?.data)) return policiesRes.data.data;
    if (Array.isArray(policiesRes)) return policiesRes;
    return [];
  }, [policiesRes]);

  // Build contactId → [policies] and contactId → [claims] maps for O(1) lookups
  const policyMap = useMemo(() => {
    const map: Record<string, any[]> = {};
    policyListArray.forEach((p: any) => {
      const keys = [p.contactId, p.contact?.id, p.contact?.contactId].filter(Boolean);
      if (Array.isArray(p.members)) {
        p.members.forEach((m: any) => {
          if (m?.contactId) keys.push(m.contactId);
        });
      }
      keys.forEach(k => {
        if (!map[k]) map[k] = [];
        if (!map[k].some((existing: any) => existing.id === p.id)) {
          map[k].push(p);
        }
      });
    });
    return map;
  }, [policyListArray]);

  // Log Interaction state
  const [interactionModalOpen, setInteractionModalOpen] = useState(false);
  const [interactionTarget, setInteractionTarget] = useState<any | null>(null);

  const [interactionFields, setInteractionFields] = useState({
    interactionType: 'Call',
    leadStage: 'To Contact',
    leadStatus: 'Interested',
    leadType: 'New',
    nextFollowUp: '',
    notes: '',
  });

  const { data: activityRes, isLoading: activityLoading } = useQuery({
    queryKey: ['contact-activity', interactionTarget?.id],
    queryFn: () => contactsService.activity(interactionTarget.id, { page: 1, limit: 100 }),
    enabled: !!interactionTarget?.id,
  });

  const historyContactId = loadedContact?.id || editContactId;
  const {
    data: contactHistoryRes,
    isLoading: contactHistoryLoading,
    isError: contactHistoryError,
  } = useQuery({
    queryKey: ['contact-activity', historyContactId],
    queryFn: () => contactsService.activity(historyContactId!, { page: 1, limit: 100 }),
    enabled: !!historyContactId && activeLeadTab === 'History',
  });

  const logInteractionMutation = useMutation({
    mutationFn: ({ id, body }: { id: string; body: any }) => contactsService.logInteraction(id, body),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['contacts'] });
      qc.invalidateQueries({ queryKey: ['leads'] });
      if (interactionTarget?.id) {
        qc.invalidateQueries({ queryKey: ['contact-activity', interactionTarget.id] });
      }
      toast.success('Interaction logged successfully');
      setInteractionModalOpen(false);
      setInteractionTarget(null);
      setInteractionFields({
        interactionType: 'Call',
        leadStage: 'To Contact',
        leadStatus: 'Interested',
        leadType: 'New',
        nextFollowUp: '',
        notes: '',
      });
    },
    onError: (err: any) => {
      toast.error(err.response?.data?.message || 'Failed to log interaction');
    }
  });

  const openLogInteraction = (contact: any) => {
    setInteractionTarget(contact);
    setInteractionFields({
      interactionType: 'Call',
      leadStage: contact.leadStage || 'To Contact',
      leadStatus: contact.leadStatus || 'Interested',
      leadType: contact.leadType || 'New',
      nextFollowUp: contact.followUpDate ? contact.followUpDate.split('T')[0] : '',
      notes: '',
    });
    setInteractionModalOpen(true);
  };

  const createContact = useCreateContact();
  const updateContact = useUpdateContact();
  const deleteContact = useDeleteContact();

  const deleteRelationshipMutation = useMutation({
    mutationFn: (relId: string) => contactsService.removeRelationship(editTarget?.id!, relId),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['contacts'] });
      toast.success('Relationship removed');
    },
    onError: () => toast.error('Failed to remove relationship'),
  });

  const openCustomerCreate = () => {
    setPersonalFields({
      role: 'Contact',
      contactStatus: 'Active',
      isActive: true,
      isDependent: false,
      dependentNo: '',
      firstName: '',
      middleName: '',
      lastName: '',
      motherName: '',
      gender: '',
      maritalStatus: '',
      dateOfBirth: '',
      birthPlace: '',
      age: '',
      height: '',
      weight: '',
      pan: '',
      panNumber: '',
      declaredMedicalHistory: [],
      notDeclaredMedicalHistory: [],
      medicalHistoryDetails: '',
      email: '',
      aadhaarNumber: '',
      whatsappNumber: '',
      sameAsWhatsapp: false,
      callingNumber: '',
      education: '',
      annualIncome: '',
      occupationType: '',
      companyName: '',
      state: '',
      district: '',
      city: '',
      pincode: '',
      streetAddress: '',
      bankName: '',
      bankAccountNumber: '',
      bankIfsc: '',
      bankBranch: '',
      assignedEmployeeId: '',
      assignedEmployeeIds: [],
    });

    const currentUser = useAuthStore.getState().user;
    const curEmp = employees.find(e => e.userId === currentUser?.id || e.id === currentUser?.id);
    const defaultEmpId = currentUser?.role === 'EMPLOYEE' ? (curEmp?.userId || currentUser?.id || '') : '';

    setPersonalFields(prev => ({
      ...prev,
      assignedEmployeeId: defaultEmpId,
      assignedEmployeeIds: defaultEmpId ? [defaultEmpId] : [],
    }));
    setLeadInfoFields({
      profileType: 'Client Profile',
      leadStatus: 'OPEN',
      interestedIn: [],
      leadSource: 'Walkin',
      assignedEmployeeId: defaultEmpId,
      followUpDate: '',
    });
    setLeadComments([]);
    setNewComment('');
    setProductInterests([]);
    setFamilyMembers([]);
    setPolicies([]);
    setSelectedCampaigns([]);
    setEditContactId(null);
    setContactNavHistory([]);
    setActiveLeadTab('Personal');
    setLeadModalOpen(true);
    setIsViewMode(false);
  };

  const extractNameFields = (primary: any, secondary?: any) => {
    let fn = primary?.firstName || primary?.contact?.firstName || secondary?.firstName || secondary?.contact?.firstName || '';
    let mn = primary?.middleName || primary?.contact?.middleName || secondary?.middleName || secondary?.contact?.middleName || '';
    let ln = primary?.lastName || primary?.contact?.lastName || secondary?.lastName || secondary?.contact?.lastName || '';

    if (!fn) {
      const nameStr = primary?.fullName || primary?.name || primary?.contact?.fullName || primary?.contact?.name ||
                      secondary?.fullName || secondary?.name || secondary?.contact?.fullName || secondary?.contact?.name || '';
      if (nameStr) {
        const parts = nameStr.trim().split(/\s+/);
        fn = parts[0] || '';
        if (parts.length === 2) {
          ln = parts[1] || '';
        } else if (parts.length > 2) {
          mn = parts.slice(1, -1).join(' ');
          ln = parts[parts.length - 1] || '';
        }
      }
    }
    return { firstName: fn, middleName: mn, lastName: ln };
  };

  const openLeadEdit = async (leadOrContact: any, options?: { defaultTab?: string; isView?: boolean }) => {
    const isMongoId = (id: unknown): id is string =>
      typeof id === 'string' && /^[0-9a-fA-F]{24}$/.test(id);
    const contactId = isMongoId(leadOrContact.contactId) ? leadOrContact.contactId : leadOrContact.id;
    if (!contactId) {
      toast.error('Invalid contact selected');
      return;
    }

    setEditContactId(contactId);
    setEditLeadId(isMongoId(leadOrContact.contactId) ? leadOrContact.id : (leadOrContact.productInterests?.[0]?.id || null));

    // Fallback initial values from leadOrContact row
    const fallbackContact = leadOrContact;
    setLoadedContact(fallbackContact);

    const initialNames = extractNameFields(fallbackContact);

    setPersonalFields({
      role: fallbackContact.role || fallbackContact.contact?.role || fallbackContact.user?.role || 'Contact',
      contactStatus: (fallbackContact.isActive !== false && fallbackContact.contact?.isActive !== false) ? 'Active' : 'Inactive',
      isActive: fallbackContact.isActive !== false && fallbackContact.contact?.isActive !== false,
      firstName: initialNames.firstName,
      middleName: initialNames.middleName,
      lastName: initialNames.lastName,
      motherName: fallbackContact.motherName || fallbackContact.contact?.motherName || '',
      gender: fallbackContact.gender || fallbackContact.contact?.gender || '',
      maritalStatus: fallbackContact.maritalStatus || fallbackContact.contact?.maritalStatus || '',
      weddingAnniversaryDate: fallbackContact.weddingAnniversaryDate || '',
      dateOfBirth: fallbackContact.dateOfBirth ? fallbackContact.dateOfBirth.split('T')[0] : (fallbackContact.contact?.dateOfBirth ? fallbackContact.contact.dateOfBirth.split('T')[0] : ''),
      birthPlace: fallbackContact.birthPlace || fallbackContact.contact?.birthPlace || '',
      age: (fallbackContact.dateOfBirth || fallbackContact.contact?.dateOfBirth) ? String(calculateAge(fallbackContact.dateOfBirth || fallbackContact.contact?.dateOfBirth)) : '',
      height: fallbackContact.height ? String(fallbackContact.height) : '',
      weight: fallbackContact.weight ? String(fallbackContact.weight) : '',
      medicalHistory: fallbackContact.medicalHistory || [],
      declaredMedicalHistory: fallbackContact.declaredMedicalHistory || [],
      notDeclaredMedicalHistory: fallbackContact.notDeclaredMedicalHistory || [],
      medicalHistoryDetails: fallbackContact.medicalHistoryDetails || '',
      surgeryDetails: fallbackContact.surgeryDetails || '',
      prescriptionDetails: fallbackContact.prescriptionDetails || '',
      chewTobacco: !!fallbackContact.chewTobacco,
      smoke: !!fallbackContact.smoke,
      consumeAlcohol: !!fallbackContact.consumeAlcohol,
      pan: fallbackContact.panNumber || fallbackContact.pan || '',
      panNumber: fallbackContact.panNumber || fallbackContact.pan || '',
      email: fallbackContact.email || fallbackContact.contact?.email || '',
      whatsappNumber: (() => {
        const p = fallbackContact.phone || fallbackContact.whatsappNumber || fallbackContact.contact?.phone || '';
        return (p && !p.startsWith('00') && p !== '0000000000' && !/^(?:91)?0{7,}$/.test(p.replace(/\D/g, ''))) ? p : '';
      })(),
      sameAsWhatsapp: (fallbackContact.phone || fallbackContact.whatsappNumber || fallbackContact.contact?.phone) === (fallbackContact.alternatePhone || fallbackContact.contact?.alternatePhone),
      callingNumber: (() => {
        const p = fallbackContact.alternatePhone || fallbackContact.contact?.alternatePhone || '';
        return (p && !p.startsWith('00') && p !== '0000000000') ? p : '';
      })(),
      education: fallbackContact.education || fallbackContact.contact?.education || '',
      annualIncome: (fallbackContact.annualIncome || fallbackContact.contact?.annualIncome) ? String(fallbackContact.annualIncome || fallbackContact.contact?.annualIncome) : '',
      occupationType: '',
      companyName: '',
      state: '',
      district: '',
      city: '',
      pincode: '',
      streetAddress: fallbackContact.notes || fallbackContact.contact?.notes || '',
      bankName: fallbackContact.bankName || fallbackContact.contact?.bankName || '',
      bankAccountNumber: fallbackContact.bankAccountNumber || fallbackContact.contact?.bankAccountNumber || '',
      bankIfsc: fallbackContact.bankIfsc || fallbackContact.contact?.bankIfsc || '',
      bankBranch: fallbackContact.bankBranch || fallbackContact.contact?.bankBranch || '',
      assignedEmployeeId: normalizeEmployeeUserId(fallbackContact.assignedEmployeeIds?.[0] || fallbackContact.assignedEmployeeId || ''),
      assignedEmployeeIds: fallbackContact.assignedEmployeeIds?.length
        ? fallbackContact.assignedEmployeeIds.map(normalizeEmployeeUserId)
        : [fallbackContact.assignedEmployeeId].filter(Boolean).map(normalizeEmployeeUserId),
    });

    setPersonalCollapsed(INITIAL_PERSONAL_COLLAPSED);
    setActiveLeadTab(options?.defaultTab || 'Personal');
    if (options?.isView !== undefined) {
      setIsViewMode(options.isView);
    }
    setLeadModalOpen(true);

    const toastId = toast.loading('Loading contact details...');
    try {
      const res = await contactsService.get(contactId);
      const contact = res?.data?.data || res?.data || res;
      if (contact && contact.id) {
        setLoadedContact(contact);

        const primaryAddr = contact.addresses?.find((a: any) => a.isPrimary) || contact.addresses?.[0];
        const primaryOcc = contact.occupations?.find((o: any) => o.isPrimary) || contact.occupations?.[0];

        const updatedNames = extractNameFields(contact, fallbackContact);

        const lead = contact.productInterests?.[0] || (leadOrContact.contactId ? leadOrContact : null);
        const contactAssigneeIds = contact.assignedEmployeeIds?.length
          ? contact.assignedEmployeeIds
          : [contact.assignedEmployeeId || contact.assignedEmployee?.id || lead?.assignedEmployeeId].filter(Boolean);
        const normalizedAssigneeIds = contactAssigneeIds.map(normalizeEmployeeUserId);
        const contactAssigneeId = normalizedAssigneeIds[0] || '';

        setPersonalFields({
          role: contact.role || fallbackContact.role || fallbackContact.contact?.role || fallbackContact.user?.role || 'Contact',
          contactStatus: contact.isActive !== false ? 'Active' : 'Inactive',
          isActive: contact.isActive !== false,
          isDependent: !!(contact.isDependent ?? fallbackContact.isDependent),
          dependentNo: contact.dependentNo || fallbackContact.dependentNo || '',
          firstName: updatedNames.firstName,
          middleName: updatedNames.middleName,
          lastName: updatedNames.lastName,
          motherName: contact.motherName || fallbackContact.motherName || fallbackContact.contact?.motherName || '',
          gender: contact.gender || fallbackContact.gender || fallbackContact.contact?.gender || '',
          maritalStatus: contact.maritalStatus || fallbackContact.maritalStatus || fallbackContact.contact?.maritalStatus || '',
          weddingAnniversaryDate: contact.weddingAnniversaryDate || fallbackContact.weddingAnniversaryDate || '',
          dateOfBirth: contact.dateOfBirth ? contact.dateOfBirth.split('T')[0] : (fallbackContact.dateOfBirth ? fallbackContact.dateOfBirth.split('T')[0] : ''),
          birthPlace: contact.birthPlace || fallbackContact.birthPlace || fallbackContact.contact?.birthPlace || '',
          age: contact.dateOfBirth ? String(calculateAge(contact.dateOfBirth)) : (fallbackContact.dateOfBirth ? String(calculateAge(fallbackContact.dateOfBirth)) : ''),
          height: contact.height ? String(contact.height) : (fallbackContact.height ? String(fallbackContact.height) : ''),
          weight: contact.weight ? String(contact.weight) : (fallbackContact.weight ? String(fallbackContact.weight) : ''),
          pan: contact.panNumber || fallbackContact.panNumber || fallbackContact.pan || '',
          panNumber: contact.panNumber || fallbackContact.panNumber || fallbackContact.pan || '',
          medicalHistory: contact.medicalHistory || fallbackContact.medicalHistory || [],
          declaredMedicalHistory: contact.declaredMedicalHistory || fallbackContact.declaredMedicalHistory || [],
          notDeclaredMedicalHistory: contact.notDeclaredMedicalHistory || fallbackContact.notDeclaredMedicalHistory || [],
          medicalHistoryDetails: contact.medicalHistoryDetails || fallbackContact.medicalHistoryDetails || '',
          surgeryDetails: contact.surgeryDetails || fallbackContact.surgeryDetails || '',
          prescriptionDetails: contact.prescriptionDetails || fallbackContact.prescriptionDetails || '',
          chewTobacco: !!(contact.chewTobacco ?? fallbackContact.chewTobacco),
          smoke: !!(contact.smoke ?? fallbackContact.smoke),
          consumeAlcohol: !!(contact.consumeAlcohol ?? fallbackContact.consumeAlcohol),
          email: contact.email || fallbackContact.email || fallbackContact.contact?.email || '',
          aadhaarNumber: contact.aadhaarNumber || fallbackContact.aadhaarNumber || fallbackContact.contact?.aadhaarNumber || '',
          whatsappNumber: (() => {
            const p = contact.phone || fallbackContact.phone || fallbackContact.contact?.phone || '';
            return (p && !p.startsWith('00') && p !== '0000000000' && !/^(?:91)?0{7,}$/.test(p.replace(/\D/g, ''))) ? p : '';
          })(),
          sameAsWhatsapp: (contact.phone || fallbackContact.phone) === (contact.alternatePhone || fallbackContact.alternatePhone),
          callingNumber: (() => {
            const p = contact.alternatePhone || fallbackContact.alternatePhone || '';
            return (p && !p.startsWith('00') && p !== '0000000000') ? p : '';
          })(),
          education: contact.education || fallbackContact.education || '',
          annualIncome: contact.annualIncome ? String(contact.annualIncome) : (fallbackContact.annualIncome ? String(fallbackContact.annualIncome) : ''),
          occupationType: primaryOcc?.type || '',
          companyName: primaryOcc?.companyName || '',
          state: primaryAddr?.state || '',
          district: primaryAddr?.district || '',
          city: primaryAddr?.city || '',
          pincode: primaryAddr?.pincode || '',
          streetAddress: primaryAddr?.line1 || contact.notes || fallbackContact.notes || '',
          bankName: contact.bankName || fallbackContact.bankName || '',
          bankAccountNumber: contact.bankAccountNumber || fallbackContact.bankAccountNumber || '',
          bankIfsc: contact.bankIfsc || fallbackContact.bankIfsc || '',
          bankBranch: contact.bankBranch || fallbackContact.bankBranch || '',
          assignedEmployeeId: contactAssigneeId,
          assignedEmployeeIds: normalizedAssigneeIds,
        });

        setLeadInfoFields({
          profileType: activeTab === 'customers' ? 'Client Profile' : 'Lead Profile',
          leadStatus: lead?.stage || 'OPEN',
          interestedIn: lead?.interests || ['Health'],
          leadSource: lead?.source || 'Walk-in',
          assignedEmployeeId: contactAssigneeId,
          followUpDate: lead?.followUpDate ? lead.followUpDate.split('T')[0] : '',
        });

        const comments = lead?.notes ? lead.notes.split('\n') : [];
        setLeadComments(comments);
        setNewComment('');

        const campaignsList = [
          'Health Awareness', 'New Year Offer', 'Pension Plan',
          'Monsoon Safety', 'Term Insurance Promo', 'Family Health Package'
        ];
        const campaigns = contact.tags?.filter((t: string) => campaignsList.includes(t)) || [];
        setSelectedCampaigns(campaigns);

        const rels1 = (contact.relationships || []).map((r: any) => {
          const c = r.relatedContact || r.contact || {};
          const parsedNames = extractNameFields(c);
          const firstAddr = c.addresses?.[0] || {};
          const firstOcc = c.occupations?.find((o: any) => o.isPrimary) || c.occupations?.[0] || {};
          const rawDob = c?.dateOfBirth ? c.dateOfBirth.split('T')[0] : '';
          const computedAge = rawDob ? String(calculateAge(rawDob)) : '';
          return {
            id: r.id,
            contactId: c.id,
            addedAt: r.createdAt || c.createdAt || contact.createdAt || new Date().toISOString(),
            name: `${parsedNames.firstName} ${parsedNames.middleName} ${parsedNames.lastName}`.replace(/\s+/g, ' ').trim(),
            firstName: parsedNames.firstName,
            middleName: parsedNames.middleName,
            lastName: parsedNames.lastName,
            dob: rawDob,
            dateOfBirth: rawDob,
            relation: r.relationshipType || 'OTHER',
            gender: c?.gender || '',
            birthPlace: c?.birthPlace || '',
            isDependent: !!(c?.isDependent || r?.isDependent),
            guardianWhatsapp: (() => {
              const raw = c?.dependentNo || (c?.isDependent || r?.isDependent ? ((c?.phone && !c.phone.startsWith('00') && c.phone !== '0000000000') ? c.phone : (contact?.phone || '')) : '');
              const d = (raw || '').replace(/\D/g, '');
              return (d.length > 10 && !d.startsWith('00')) ? d.slice(-10) : (raw || '');
            })(),
            dependentNo: (() => {
              const raw = c?.dependentNo || (c?.isDependent || r?.isDependent ? ((c?.phone && !c.phone.startsWith('00') && c.phone !== '0000000000') ? c.phone : (contact?.phone || '')) : '');
              const d = (raw || '').replace(/\D/g, '');
              return (d.length > 10 && !d.startsWith('00')) ? d.slice(-10) : (raw || '');
            })(),
            motherName: c?.motherName || '',
            email: c?.email || '',
            aadhaarNumber: c?.aadhaarNumber || '',
            pan: c?.panNumber || c?.pan || '',
            panNumber: c?.panNumber || c?.pan || '',
            phone: (() => {
              const raw = (c?.phone && !c.phone.startsWith('00') && c.phone !== '0000000000') ? c.phone : (r?.phone && !r.phone.startsWith('00') && r.phone !== '0000000000' ? r.phone : ((c?.isDependent || r?.isDependent) ? (c?.dependentNo || contact?.phone || '') : ''));
              const d = (raw || '').replace(/\D/g, '');
              return (d.length > 10 && !d.startsWith('00')) ? d.slice(-10) : (raw || '');
            })(),
            contactNo: (() => {
              const raw = (c?.phone && !c.phone.startsWith('00') && c.phone !== '0000000000') ? c.phone : (r?.phone && !r.phone.startsWith('00') && r.phone !== '0000000000' ? r.phone : ((c?.isDependent || r?.isDependent) ? (c?.dependentNo || contact?.phone || '') : ''));
              const d = (raw || '').replace(/\D/g, '');
              return (d.length > 10 && !d.startsWith('00')) ? d.slice(-10) : (raw || '');
            })(),
            whatsapp: (() => {
              const raw = (c?.phone && !c.phone.startsWith('00') && c.phone !== '0000000000') ? c.phone : (r?.phone && !r.phone.startsWith('00') && r.phone !== '0000000000' ? r.phone : ((c?.isDependent || r?.isDependent) ? (c?.dependentNo || contact?.phone || '') : ''));
              const d = (raw || '').replace(/\D/g, '');
              return (d.length > 10 && !d.startsWith('00')) ? d.slice(-10) : (raw || '');
            })(),
            whatsappNumber: (() => {
              const raw = (c?.phone && !c.phone.startsWith('00') && c.phone !== '0000000000') ? c.phone : (r?.phone && !r.phone.startsWith('00') && r.phone !== '0000000000' ? r.phone : ((c?.isDependent || r?.isDependent) ? (c?.dependentNo || contact?.phone || '') : ''));
              const d = (raw || '').replace(/\D/g, '');
              return (d.length > 10 && !d.startsWith('00')) ? d.slice(-10) : (raw || '');
            })(),
            callingNumber: (() => {
              const raw = (c?.alternatePhone && !c.alternatePhone.startsWith('00') && c.alternatePhone !== '0000000000') ? c.alternatePhone : (r?.alternatePhone && !r.alternatePhone.startsWith('00') && r.alternatePhone !== '0000000000' ? r.alternatePhone : ((c?.isDependent || r?.isDependent) ? (c?.dependentNo || contact?.phone || '') : ''));
              const d = (raw || '').replace(/\D/g, '');
              return (d.length > 10 && !d.startsWith('00')) ? d.slice(-10) : (raw || '');
            })(),
            alternatePhone: (() => {
              const raw = (c?.alternatePhone && !c.alternatePhone.startsWith('00') && c.alternatePhone !== '0000000000') ? c.alternatePhone : (r?.alternatePhone && !r.alternatePhone.startsWith('00') && r.alternatePhone !== '0000000000' ? r.alternatePhone : ((c?.isDependent || r?.isDependent) ? (c?.dependentNo || contact?.phone || '') : ''));
              const d = (raw || '').replace(/\D/g, '');
              return (d.length > 10 && !d.startsWith('00')) ? d.slice(-10) : (raw || '');
            })(),
            sameAsWhatsapp: !!(c?.phone && c?.alternatePhone && c.phone === c.alternatePhone),
            role: c?.role || 'Contact',
            contactStatus: c?.isActive !== false ? 'Active' : 'Inactive',
            occupation: firstOcc.type || c?.occupation || '',
            occupationType: firstOcc.type || c?.occupation || '',
            companyName: firstOcc.companyName || '',
            annualIncome: c?.annualIncome != null ? String(c.annualIncome) : (firstOcc.annualIncome != null ? String(firstOcc.annualIncome) : ''),
            education: c.education || '',
            maritalStatus: c.maritalStatus || '',
            weddingAnniversary: c.weddingAnniversaryDate || '',
            weddingAnniversaryDate: c.weddingAnniversaryDate || '',
            state: firstAddr.state || '',
            district: firstAddr.district || '',
            city: firstAddr.city || '',
            pincode: firstAddr.pincode || '',
            streetAddress: firstAddr.line1 ? `${firstAddr.line1}${firstAddr.line2 ? ', ' + firstAddr.line2 : ''}` : '',
            bankName: c?.bankName || '',
            bankAccountNumber: c?.bankAccountNumber || '',
            bankIfsc: c?.bankIfsc || '',
            bankBranch: c?.bankBranch || '',
            chewTobacco: !!c?.chewTobacco,
            smoke: !!c?.smoke,
            consumeAlcohol: !!c?.consumeAlcohol,
            height: c.height == null ? '' : String(c.height),
            weight: c.weight == null ? '' : String(c.weight),
            age: computedAge,
            medicalHistory: c.medicalHistory || [],
            declaredMedicalHistory: c.declaredMedicalHistory || [],
            notDeclaredMedicalHistory: c.notDeclaredMedicalHistory || [],
            medicalHistoryDetails: c.medicalHistoryDetails || '',
            surgeryDetails: c.surgeryDetails || '',
            prescriptionDetails: c.prescriptionDetails || ''
          };
        });
        setFamilyMembers(rels1);

        const healthEntries: any[] = [];
        const lifeEntries: any[] = [];
        (contact.policies || []).forEach((p: any) => {
          const entry = {
            company: p.plan?.company?.name || 'Other',
            planName: p.plan?.name || 'Other',
            policyNo: p.policyNumber,
            startDate: p.startDate ? p.startDate.split('T')[0] : '',
            duration: '1 Year',
            endDate: p.endDate ? p.endDate.split('T')[0] : '',
            premium: String(p.premiumAmount),
            sumInsured: String(p.sumAssured),
            deductible: '',
            sumAssured: String(p.sumAssured),
            maturityDate: p.maturityDate ? p.maturityDate.split('T')[0] : '',
            paymentTerm: '',
            entryType: p.status === 'ACTIVE' ? 'New' : 'Renewal'
          };
          if (p.plan?.category === 'HEALTH') {
            healthEntries.push(entry);
          } else {
            lifeEntries.push(entry);
          }
        });

        const parsedPolicies: any[] = [];
        if (healthEntries.length > 0) parsedPolicies.push({ policyType: 'Health', entries: healthEntries });
        if (lifeEntries.length > 0) parsedPolicies.push({ policyType: 'Life', entries: lifeEntries });
        setPolicies(parsedPolicies);

        const backendInterests = contact.productInterests || [];
        const mappedInterests: ProductInterestCard[] = backendInterests.map((lead: any) => {
          const extra = parseLeadNotes(lead.notes);
          const comments = (lead.consultations || []).map((c: any) => ({
            text: c.notes || '',
            author: c.author || 'System',
            datetime: c.createdAt ? new Date(c.createdAt).toLocaleString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : '',
          }));

          const parseBackendInterests = (list: string[] = []): { interestedIn: string[]; otherProduct: string } => {
            const STANDARD_PRODUCTS = ['Health', 'Life', 'Term', 'Accident Policy', 'Motor', 'Mutual Funds', 'Porting'];
            const interestedIn: string[] = [];
            const otherParts: string[] = [];
            for (const raw of list) {
              if (!raw || !raw.trim()) continue;
              const trimmed = raw.trim();
              const lower = trimmed.toLowerCase();
              if (lower.includes('health')) {
                if (!interestedIn.includes('Health')) interestedIn.push('Health');
              } else if (lower.includes('life') && !lower.includes('term')) {
                if (!interestedIn.includes('Life')) interestedIn.push('Life');
              } else if (lower.includes('term')) {
                if (!interestedIn.includes('Term')) interestedIn.push('Term');
              } else if (lower.includes('accident')) {
                if (!interestedIn.includes('Accident Policy')) interestedIn.push('Accident Policy');
              } else if (lower.includes('motor') || lower.includes('car') || lower.includes('vehicle') || lower.includes('bike')) {
                if (!interestedIn.includes('Motor')) interestedIn.push('Motor');
              } else if (lower.includes('mutual') || lower.includes('fund')) {
                if (!interestedIn.includes('Mutual Funds')) interestedIn.push('Mutual Funds');
              } else if (lower.includes('port')) {
                if (!interestedIn.includes('Porting')) interestedIn.push('Porting');
              } else if (STANDARD_PRODUCTS.includes(trimmed)) {
                if (!interestedIn.includes(trimmed)) interestedIn.push(trimmed);
              } else {
                otherParts.push(trimmed);
              }
            }
            if (otherParts.length > 0 && !interestedIn.includes('Other')) {
              interestedIn.push('Other');
            }
            if (interestedIn.length === 0) {
              interestedIn.push('Health');
            }
            return { interestedIn, otherProduct: otherParts.join(', ') };
          };

          const { interestedIn, otherProduct } = parseBackendInterests(lead.interests || []);

          const expectedPremium = lead.premiumBudget ? String(lead.premiumBudget) : '';
          let leadStage = 'TO_CONTACT';
          if (lead.stage === 'OPEN') leadStage = 'TO_CONTACT';
          else if (lead.stage === 'PAYMENT_DONE') leadStage = 'PROCESS_COMPLETED';
          else leadStage = lead.stage;

          return {
            id: lead.id,
            collapsed: true,
            interestedIn,
            otherProduct,
            descriptionDetails: extra.descriptionDetails || '',
            leadStage,
            leadStatus: extra.leadStatus,
            dependencyType: extra.dependencyType || 'SELF',
            dependentDetails: extra.dependentDetails || '',
            leadType: extra.leadType,
            leadSource: lead.source || 'Walk-in',
            assignedEmployeeId: lead.assignedEmployeeId || '',
            followUpDate: lead.followUpDate ? lead.followUpDate.split('T')[0] : '',
            expectedPremium,
            comments,
            newComment: '',
          };
        });

        setProductInterests(mappedInterests);
      }
      toast.dismiss(toastId);
    } catch (err) {
      toast.dismiss(toastId);
    }
  };

  const openPolicyInNewTab = (contactId: string, policyId?: string) => {
    const url = new URL('/contacts', window.location.origin);
    url.searchParams.set('openPolicyContact', contactId);
    if (policyId) {
      url.searchParams.set('openPolicyId', policyId);
    } else {
      url.searchParams.set('openNewPolicy', '1');
    }
    window.open(url.toString(), '_blank', 'noopener,noreferrer');
  };

  const openFamilyMemberInNewTab = (contactId: string, memberIdx?: number | null, options?: { parentContactId?: string; returnTab?: string }) => {
    const url = new URL('/contacts', window.location.origin);
    url.searchParams.set('openFamilyContact', contactId);
    if (memberIdx !== null && memberIdx !== undefined && memberIdx >= 0) {
      url.searchParams.set('openFamilyMemberIdx', String(memberIdx));
    } else {
      url.searchParams.set('openNewFamilyMember', '1');
    }
    const parentId = options?.parentContactId || contactId || editContactId || loadedContact?.id;
    if (parentId) {
      url.searchParams.set('parentContactId', parentId);
      url.searchParams.set('returnTab', options?.returnTab || activeLeadTab || 'Family');
    }
    window.open(url.toString(), '_blank');
  };

  const openContactInNewTab = (contactId: string, options?: { parentContactId?: string; returnTab?: string; isView?: boolean }) => {
    const url = new URL('/contacts', window.location.origin);
    url.searchParams.set('openContactId', contactId);
    const parentId = options?.parentContactId || editContactId || loadedContact?.id;
    if (parentId) {
      url.searchParams.set('parentContactId', parentId);
      url.searchParams.set('returnTab', options?.returnTab || activeLeadTab || 'Family');
    }
    url.searchParams.set('viewMode', options?.isView === false ? '0' : '1');
    window.open(url.toString(), '_blank');
  };

  // Handle URL query parameters to open Policy Modal in a new tab
  useEffect(() => {
    const policyId = searchParams.get('openPolicyId');
    const openNewPolicy = searchParams.get('openNewPolicy') === '1' || searchParams.get('openNewPolicy') === 'true';
    const contactId = searchParams.get('openPolicyContact');
    if (!contactId || (!policyId && !openNewPolicy)) return;

    const requestKey = `${contactId}:${policyId || 'new'}`;
    if (openedPolicyRef.current === requestKey) return;
    openedPolicyRef.current = requestKey;

    const loadPolicyModal = async () => {
      try {
        if (policyId) {
          const [contactRes, policyRes] = await Promise.all([
            contactsService.get(contactId),
            policiesService.get(policyId),
          ]);
          const contact = contactRes?.data?.data || contactRes?.data || contactRes;
          const policy = policyRes?.data?.data || policyRes?.data || policyRes;
          if (!contact?.id || !policy?.id) {
            throw new Error('Contact or policy details were not found');
          }

          await openLeadEdit(contact, { defaultTab: 'Policy' });
          setPolicyToEdit(policy);
          setActiveLeadTab('Policy');
          setCreatePolicyModalOpen(true);
        } else {
          const contactRes = await contactsService.get(contactId);
          const contact = contactRes?.data?.data || contactRes?.data || contactRes;
          if (!contact?.id) {
            throw new Error('Contact details were not found');
          }

          await openLeadEdit(contact, { defaultTab: 'Policy' });
          setPolicyToEdit(null);
          setActiveLeadTab('Policy');
          setCreatePolicyModalOpen(true);
        }
        navigate('/contacts', { replace: true });
      } catch (error: any) {
        openedPolicyRef.current = null;
        toast.error(error.response?.data?.message || error.message || 'Failed to open policy details');
      }
    };

    void loadPolicyModal();
  }, [navigate, searchParams]);

  // Handle URL query parameters to open Family Member Modal in a new tab
  useEffect(() => {
    const contactId = searchParams.get('openFamilyContact');
    const memberIdxStr = searchParams.get('openFamilyMemberIdx');
    const isNewFamily = searchParams.get('openNewFamilyMember') === '1' || searchParams.get('openNewFamilyMember') === 'true';

    if (!contactId || (memberIdxStr === null && !isNewFamily)) return;

    const requestKey = `${contactId}:family:${memberIdxStr ?? 'new'}`;
    if (openedFamilyRef.current === requestKey) return;
    openedFamilyRef.current = requestKey;

    const loadFamilyModal = async () => {
      try {
        const contactRes = await contactsService.get(contactId);
        const contact = contactRes?.data?.data || contactRes?.data || contactRes;
        if (!contact?.id) {
          throw new Error('Contact details were not found');
        }

        await openLeadEdit(contact, { defaultTab: 'Family' });

        if (isNewFamily || memberIdxStr === null) {
          openAddFamilyMemberModal();
        } else {
          const idx = parseInt(memberIdxStr, 10);
          const validIdx = Number.isFinite(idx) && idx >= 0 ? idx : 0;
          const rels = (contact.relationships || []).map((r: any) => {
            const c = r.relatedContact || r.contact || {};
            const parsedNames = extractNameFields(c);
            const firstAddr = c.addresses?.[0] || {};
            const firstOcc = c.occupations?.find((o: any) => o.isPrimary) || c.occupations?.[0] || {};
            const rawDob = c?.dateOfBirth ? c.dateOfBirth.split('T')[0] : '';
            const computedAge = rawDob ? String(calculateAge(rawDob)) : '';
            return {
              id: r.id,
              contactId: c.id,
              addedAt: r.createdAt || c.createdAt || contact.createdAt || new Date().toISOString(),
              name: `${parsedNames.firstName} ${parsedNames.middleName} ${parsedNames.lastName}`.replace(/\s+/g, ' ').trim(),
              firstName: parsedNames.firstName,
              middleName: parsedNames.middleName,
              lastName: parsedNames.lastName,
              relation: (r.relationshipType || 'OTHER').toUpperCase(),
              dob: rawDob,
              age: computedAge,
              gender: c.gender || '',
              phone: (c.phone && !c.phone.startsWith('00') && c.phone !== '0000000000') ? c.phone : '',
              whatsapp: (c.whatsappNumber || c.phone || ''),
              email: c.email || '',
              isDependent: !!(c.isDependent ?? r.isDependent),
              motherName: c.motherName || '',
              bankName: c.bankName || '',
              bankAccountNumber: c.bankAccountNumber || '',
              bankIfsc: c.bankIfsc || '',
              bankBranch: c.bankBranch || '',
              pan: c.panNumber || c.pan || '',
              panNumber: c.panNumber || c.pan || '',
              aadhaarNumber: c.aadhaarNumber || '',
              birthPlace: c.birthPlace || '',
              education: c.education || '',
              maritalStatus: c.maritalStatus || '',
              weddingAnniversary: c.weddingAnniversaryDate || '',
              weddingAnniversaryDate: c.weddingAnniversaryDate || '',
              height: c.height == null ? '' : String(c.height),
              weight: c.weight == null ? '' : String(c.weight),
              chewTobacco: !!c.chewTobacco,
              smoke: !!c.smoke,
              consumeAlcohol: !!c.consumeAlcohol,
              occupation: firstOcc.title || firstOcc.type || '',
              occupationType: firstOcc.type || '',
              companyName: firstOcc.companyName || '',
              annualIncome: c.annualIncome ? String(c.annualIncome) : '',
              city: firstAddr.city || '',
              state: firstAddr.state || '',
              district: firstAddr.district || '',
              pincode: firstAddr.pincode || '',
              streetAddress: firstAddr.line1 || '',
              medicalHistory: c.medicalHistory || [],
              declaredMedicalHistory: c.declaredMedicalHistory || [],
              notDeclaredMedicalHistory: c.notDeclaredMedicalHistory || [],
              medicalHistoryDetails: c.medicalHistoryDetails || '',
              surgeryDetails: c.surgeryDetails || '',
              prescriptionDetails: c.prescriptionDetails || '',
            };
          });
          const targetMember = rels[validIdx] || null;
          setEditingFamilyMemberIdx(validIdx);
          setSelectedFamilyMemberForModal(targetMember);
          setFamilyMemberModalOpen(true);
        }
        navigate('/contacts', { replace: true });
      } catch (error: any) {
        openedFamilyRef.current = null;
        toast.error(error.response?.data?.message || error.message || 'Failed to open family member details');
      }
    };

    void loadFamilyModal();
  }, [navigate, searchParams]);

  // Handle URL query parameters to open Contact Modal directly
  useEffect(() => {
    const directContactId = searchParams.get('openContactId');
    if (!directContactId) return;

    const requestKey = `contact:${directContactId}`;
    if (openedDirectContactRef.current === requestKey) return;
    openedDirectContactRef.current = requestKey;

    const parentContactId = searchParams.get('parentContactId');
    const returnTab = searchParams.get('returnTab');
    const viewModeParam = searchParams.get('viewMode');
    const shouldBeView = viewModeParam === null ? true : (viewModeParam === '1' || viewModeParam === 'true');

    if (parentContactId) {
      const pInfo = {
        parentContactId,
        returnTab: returnTab || 'Family',
      };
      setParentNavInfo(pInfo);
      parentNavInfoRef.current = pInfo;
    }

    const loadDirectContact = async () => {
      try {
        const contactRes = await contactsService.get(directContactId);
        const contact = contactRes?.data?.data || contactRes?.data || contactRes;
        if (!contact?.id) {
          throw new Error('Contact details were not found');
        }

        await openLeadEdit(contact, { isView: shouldBeView });
        setIsViewMode(shouldBeView);
        openedDirectContactRef.current = null;
        const sp = new URLSearchParams(searchParams);
        sp.delete('openContactId');
        sp.delete('viewMode');
        sp.delete('parentContactId');
        sp.delete('returnTab');
        const qs = sp.toString();
        navigate(qs ? ('/contacts?' + qs) : '/contacts', { replace: true });
      } catch (error: any) {
        openedDirectContactRef.current = null;
        toast.error(error.response?.data?.message || error.message || 'Failed to open contact');
      }
    };

    void loadDirectContact();
  }, [navigate, searchParams]);

  // Handle open-contact-modal custom event from Header search or other components
  useEffect(() => {
    const handleOpenContactModal = (e: any) => {
      const contactId = e.detail?.contactId;
      const isView = e.detail?.isView !== false;
      if (!contactId) return;
      contactsService.get(contactId).then(res => {
        const contact = res?.data?.data || res?.data || res;
        if (contact?.id) {
          openLeadEdit(contact, { isView });
          setIsViewMode(isView);
        }
      }).catch(err => {
        console.error('Failed to open contact modal from event:', err);
      });
    };
    window.addEventListener('open-contact-modal', handleOpenContactModal);
    return () => window.removeEventListener('open-contact-modal', handleOpenContactModal);
  }, []);

  // Ctrl + Enter shortcut: open Policy or Family Member modal in new tab
  useEffect(() => {
    const handleCtrlEnter = (event: KeyboardEvent) => {
      if (event.key !== 'Enter' || (!event.ctrlKey && !event.metaKey)) return;

      // If currently inside FamilyMemberModal
      if (familyMemberModalOpen) {
        event.preventDefault();
        event.stopPropagation();
        const contactId = editContactId || loadedContact?.id;
        const currentMember = editingFamilyMemberIdx !== null && editingFamilyMemberIdx !== undefined
          ? familyMembers[editingFamilyMemberIdx]
          : selectedFamilyMemberForModal;
        if (currentMember?.contactId) {
          openContactInNewTab(currentMember.contactId, {
            parentContactId: contactId,
            returnTab: 'Family',
          });
        } else if (contactId) {
          openFamilyMemberInNewTab(contactId, editingFamilyMemberIdx);
        }
        return;
      }

      // If currently inside CreatePolicyModal
      if (createPolicyModalOpen) {
        event.preventDefault();
        event.stopPropagation();
        const contactId = editContactId || loadedContact?.id;
        if (contactId) {
          openPolicyInNewTab(contactId, policyToEdit?.id);
        }
        return;
      }

      // If inside lead/contact modal
      if (leadModalOpen) {
        const contactId = editContactId || loadedContact?.id;
        if (!contactId) return;

        if (activeLeadTab === 'Policy') {
          event.preventDefault();
          event.stopPropagation();
          const contactPolicies = [
            ...(loadedContact?.policies || []),
            ...(loadedContact?.id ? policyMap[loadedContact.id] || [] : []),
            ...(loadedContact?.contactId ? policyMap[loadedContact.contactId] || [] : []),
            ...(policyMap[contactId] || []),
          ];
          const activePolicy = contactPolicies.find((policy: any) => {
            const status = (policy.status || 'ACTIVE').toUpperCase();
            return !['EXPIRED', 'LAPSED', 'CANCELLED', 'INACTIVE'].includes(status)
              && (!policy.endDate || new Date(policy.endDate) >= new Date());
          }) || contactPolicies[0];

          if (activePolicy?.id) {
            openPolicyInNewTab(contactId, activePolicy.id);
          } else {
            openPolicyInNewTab(contactId);
          }
          return;
        }

        if (activeLeadTab === 'Family') {
          event.preventDefault();
          event.stopPropagation();
          if (familyMembers.length > 0) {
            const firstMember = familyMembers[0];
            if (firstMember?.contactId) {
              openContactInNewTab(firstMember.contactId, {
                parentContactId: contactId,
                returnTab: 'Family',
              });
            } else {
              openFamilyMemberInNewTab(contactId, 0);
            }
          } else {
            openFamilyMemberInNewTab(contactId);
          }
          return;
        }
      }
    };

    window.addEventListener('keydown', handleCtrlEnter);
    return () => window.removeEventListener('keydown', handleCtrlEnter);
  }, [
    activeLeadTab,
    createPolicyModalOpen,
    editContactId,
    editingFamilyMemberIdx,
    familyMemberModalOpen,
    familyMembers,
    leadModalOpen,
    loadedContact,
    policyMap,
    policyToEdit,
  ]);

  const openLeadView = (leadOrContact: any) => {
    setContactNavHistory([]);
    setIsViewMode(true);
    openLeadEdit(leadOrContact);
  };

  const openEdit = openLeadEdit;

  const navigateToContact = (target: any) => {
    if (editContactId) {
      setContactNavHistory(prev => [
        ...prev,
        {
          contactId: editContactId,
          leadId: editLeadId,
          activeTab: activeLeadTab || 'Family',
          isViewMode: isViewMode,
          contactName: loadedContact ? [loadedContact.firstName, loadedContact.middleName, loadedContact.lastName].filter(Boolean).join(' ').trim() : undefined,
        }
      ]);
    }
    openLeadEdit(target, { isView: true });
    setIsViewMode(true);
  };

  const closeLeadModal = () => {
    if (docPreviewModal.open || contactDocUploadOpen || createPolicyModalOpen || familyMemberModalOpen) {
      return;
    }
    openedDirectContactRef.current = null;
    setContactNavHistory([]);
    setParentNavInfo(null);
    parentNavInfoRef.current = null;
    setLeadModalOpen(false);
    setLoadedContact(null);
    setIsViewMode(false);
  };

  const handleCancelLeadModal = async () => {
    if (docPreviewModal.open || contactDocUploadOpen || createPolicyModalOpen || familyMemberModalOpen) {
      return;
    }

    if (contactNavHistory.length > 0) {
      const prev = contactNavHistory[contactNavHistory.length - 1];
      setContactNavHistory(h => h.slice(0, -1));

      await openLeadEdit(
        { id: prev.contactId, leadId: prev.leadId },
        { defaultTab: prev.activeTab || 'Family', isView: prev.isViewMode }
      );
      return;
    }

    const pNav = parentNavInfo || parentNavInfoRef.current;
    if (pNav?.parentContactId) {
      setParentNavInfo(null);
      parentNavInfoRef.current = null;

      try {
        if (window.opener && !window.opener.closed) {
          try {
            window.opener.focus();
          } catch (_) {}
          window.close();
          return;
        } else {
          window.close();
        }
      } catch (_) {}

      // If window.close() didn't close this tab (e.g. script-close restricted), navigate back to the parent contact on the Family tab
      try {
        const parentRes = await contactsService.get(pNav.parentContactId);
        const parentContact = parentRes?.data?.data || parentRes?.data || parentRes;
        if (parentContact?.id) {
          await openLeadEdit(parentContact, { defaultTab: pNav.returnTab || 'Family' });
          return;
        }
      } catch (err) {
        console.error('Failed to return to parent contact:', err);
      }
    }

    closeLeadModal();
  };

  const calculateAge = (dob: any): number => {
    if (!dob) return 0;
    try {
      let birthDate: Date;
      if (dob instanceof Date) {
        birthDate = dob;
      } else {
        const s = String(dob).trim();
        if (/^\d{2}\/\d{2}\/\d{4}$/.test(s)) {
          const [d, m, y] = s.split('/').map(Number);
          birthDate = new Date(y, m - 1, d);
        } else if (/^\d{4}-\d{2}-\d{2}/.test(s)) {
          const [y, m, d] = s.slice(0, 10).split('-').map(Number);
          birthDate = new Date(y, m - 1, d);
        } else {
          birthDate = new Date(s);
        }
      }
      if (isNaN(birthDate.getTime())) return 0;
      const today = new Date();
      let age = today.getFullYear() - birthDate.getFullYear();
      const monthDiff = today.getMonth() - birthDate.getMonth();
      if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
        age--;
      }
      return age >= 0 ? age : 0;
    } catch {
      return 0;
    }
  };

  const handleDOBChange = (val: string) => {
    const age = calculateAge(val);
    setPersonalFields(p => ({ ...p, dateOfBirth: val, age: String(age) }));
  };


  const handleLeadSubmit = async (e: React.FormEvent, shouldClose: boolean) => {
    e.preventDefault();
    const firstName = (personalFields?.firstName || '').trim();
    const lastName = (personalFields?.lastName || '').trim();
    const whatsappNumber = (personalFields?.whatsappNumber || '').trim();

    const isDep = !!personalFields?.isDependent;
    const guardianNo = (personalFields?.dependentNo || '').trim();

    if (isFieldRequired('firstName', true) && !firstName) {
      toast.error('First Name is required');
      setActiveLeadTab('Personal');
      return;
    }
    if (isFieldRequired('lastName', true) && !lastName) {
      toast.error('Last Name is required');
      setActiveLeadTab('Personal');
      return;
    }

    if (isDep) {
      if (guardianNo) {
        const KNOWN_CODES = ['971','966','974','968','965','973','880','977','234','254','353','91','44','49','33','81','86','94','60','62','63','66','84','27','55','52','39','34','31','41','46','47','45','64','65','61','1','7'];
        const rawGDigits = guardianNo.replace(/\D/g, '');
        const matchedGCode = [...KNOWN_CODES].sort((a, b) => b.length - a.length).find(c => rawGDigits.startsWith(c));
        const localGDigits = matchedGCode ? rawGDigits.slice(matchedGCode.length) : rawGDigits;
        if (!/^\d{10}$/.test(localGDigits) && !/^\d{10}$/.test(rawGDigits)) {
          toast.error('Guardian WhatsApp Number must be exactly 10 digits');
          return;
        }
      }
    } else {
      if (isFieldRequired('phone', true) && !whatsappNumber) {
        toast.error('WhatsApp Number is required');
        setActiveLeadTab('Personal');
        return;
      }
      if (whatsappNumber) {
        // Strip country code prefix, then validate exactly 10 local digits
        const KNOWN_CODES = ['971','966','974','968','965','973','880','977','234','254','353','91','44','49','33','81','86','94','60','62','63','66','84','27','55','52','39','34','31','41','46','47','45','64','65','61','1','7'];
        const rawWaDigits = whatsappNumber.replace(/\D/g, '');
        const sortedCodes = [...KNOWN_CODES].sort((a, b) => b.length - a.length);
        const matchedCode = sortedCodes.find(c => rawWaDigits.startsWith(c));
        const localDigits = matchedCode ? rawWaDigits.slice(matchedCode.length) : rawWaDigits;
        if (!/^\d{10}$/.test(localDigits) && !/^\d{10}$/.test(rawWaDigits)) {
          toast.error('WhatsApp Number must be exactly 10 digits');
          return;
        }
      }
    }

    if (personalFields?.callingNumber?.trim()) {
      const KNOWN_CODES = ['971','966','974','968','965','973','880','977','234','254','353','91','44','49','33','81','86','94','60','62','63','66','84','27','55','52','39','34','31','41','46','47','45','64','65','61','1','7'];
      const rawCallDigits = personalFields.callingNumber.trim().replace(/\D/g, '');
      const matchedCallCode = [...KNOWN_CODES].sort((a, b) => b.length - a.length).find(c => rawCallDigits.startsWith(c));
      const callLocalDigits = matchedCallCode ? rawCallDigits.slice(matchedCallCode.length) : rawCallDigits;
      if (!/^\d{10}$/.test(callLocalDigits) && !/^\d{10}$/.test(rawCallDigits)) {
        toast.error('Calling Number must be exactly 10 digits');
        return;
      }
    }

    const rawPhoneDigits = whatsappNumber ? whatsappNumber.replace(/\D/g, '') : '';
    const cleanPhone = rawPhoneDigits ? (rawPhoneDigits.length > 10 ? rawPhoneDigits.slice(-10) : rawPhoneDigits) : `00${Date.now().toString().slice(-8)}`;

    const cleanAadhaar = (personalFields?.aadhaarNumber || '').replace(/\D/g, '');
    if (isFieldRequired('aadhaarNumber', false) && !cleanAadhaar) {
      toast.error('Aadhaar Number is required');
      setActiveLeadTab('Personal');
      return;
    }
    if (cleanAadhaar && cleanAadhaar.length !== 12) {
      toast.error('Aadhaar Number must be exactly 12 digits');
      return;
    }

    if (isFieldRequired('occupationType', false) && !personalFields?.occupationType?.trim()) {
      toast.error('Occupation Type is required');
      setActiveLeadTab('Personal');
      return;
    }

    if (isFieldRequired('state', false) && !personalFields?.state?.trim()) {
      toast.error('State is required');
      setActiveLeadTab('Personal');
      return;
    }

    if (isFieldRequired('district', false) && !personalFields?.district?.trim()) {
      toast.error('District is required');
      setActiveLeadTab('Personal');
      return;
    }

    if (isFieldRequired('city', false) && !personalFields?.city?.trim()) {
      toast.error('City is required');
      setActiveLeadTab('Personal');
      return;
    }

    if (isFieldRequired('address', false) && !personalFields?.streetAddress?.trim()) {
      toast.error('Street Address is required');
      setActiveLeadTab('Personal');
      return;
    }

    if (isFieldRequired('pincode', false) && !personalFields?.pincode?.trim()) {
      toast.error('Pincode is required');
      setActiveLeadTab('Personal');
      return;
    }

    const contactFieldsToCheck = [
      { key: 'alternatePhone', label: 'Alternate Phone', value: personalFields.callingNumber, defaultRequired: false },
      { key: 'email', label: 'Email Address', value: personalFields.email, defaultRequired: false },
      { key: 'gender', label: 'Gender', value: personalFields.gender, defaultRequired: false },
      { key: 'dateOfBirth', label: 'Date of Birth', value: personalFields.dateOfBirth, defaultRequired: false },
      { key: 'birthPlace', label: 'Birth Place', value: personalFields.birthPlace, defaultRequired: false },
      { key: 'panNumber', label: 'PAN Number', value: personalFields.panNumber || personalFields.pan, defaultRequired: false },
      { key: 'annualIncome', label: 'Annual Income', value: personalFields.annualIncome, defaultRequired: false },
      { key: 'notes', label: 'Notes', value: personalFields.notes, defaultRequired: false },
      { key: 'source', label: 'Source', value: personalFields.source, defaultRequired: false },
      { key: 'assignedEmployeeId', label: 'Assigned Employee', value: leadInfoFields.assignedEmployeeId, defaultRequired: false },
      { key: 'leadStage', label: 'Lead Stage', value: (leadInfoFields as any)?.leadStage, defaultRequired: false },
      { key: 'leadStatus', label: 'Lead Status', value: leadInfoFields.leadStatus, defaultRequired: false },
      { key: 'leadType', label: 'Lead Type', value: (leadInfoFields as any)?.leadType, defaultRequired: false },
      { key: 'followUpDate', label: 'Follow-up Date', value: leadInfoFields.followUpDate, defaultRequired: false },
    ];

    for (const f of contactFieldsToCheck) {
      if (isFieldRequired(f.key, f.defaultRequired) && (!f.value || String(f.value).trim() === '')) {
        toast.error(f.label + ' is required');
        setActiveLeadTab('Personal');
        return;
      }
    }

    // Validate product interest cards only if product interest is explicitly/exclusively selected or has content
    for (let i = 0; i < productInterests.length; i++) {
      const card = productInterests[i];
      const isExisting = card.id.length === 24 || /^[0-9a-fA-F]{24}$/.test(card.id);
      if (!isExisting) {
        const hasSelectedInterests = Array.isArray(card.interestedIn) && card.interestedIn.length > 0;
        const hasContent = hasSelectedInterests ||
          Boolean(card.otherProduct?.trim()) ||
          Boolean(card.expectedPremium && Number(card.expectedPremium) > 0) ||
          Boolean(card.followUpDate?.trim()) ||
          Boolean(card.descriptionDetails?.trim());

        // Completely unselected / untouched card — ignore so contact creation is not blocked
        if (!hasContent) {
          continue;
        }

        // If card was initiated with content or details, require an exclusively selected product category
        if (!hasSelectedInterests) {
          toast.error(`Product Interest #${i + 1}: Please select a Product Category`);
          setActiveLeadTab('Product Interest');
          return;
        }
        if (card.interestedIn.includes('Other') && !card.otherProduct?.trim()) {
          toast.error(`Product Interest #${i + 1}: Please specify the Other Product Name`);
          setActiveLeadTab('Product Interest');
          return;
        }

        if (!card.leadSource?.trim()) {
          toast.error(`Product Interest #${i + 1}: Please select or enter a Lead Source`);
          setActiveLeadTab('Product Interest');
          return;
        }
        if (!card.followUpDate?.trim()) {
          toast.error(`Product Interest #${i + 1}: Please select a Follow-up Date`);
          setActiveLeadTab('Product Interest');
          return;
        }
        if (!card.expectedPremium || Number(card.expectedPremium) <= 0) {
          toast.error(`Product Interest #${i + 1}: Please enter a valid Expected Premium / Budget (> 0)`);
          setActiveLeadTab('Product Interest');
          return;
        }
      }
    }

    // Validate family members relation
    for (let i = 0; i < familyMembers.length; i++) {
      const member = familyMembers[i];
      const hasContent = 
        (member.firstName || '').trim() || 
        (member.lastName || '').trim() || 
        (member.dob || '').trim() || 
        (member.whatsapp || '').trim() || 
        (member.callingNumber || '').trim();
      
      if (hasContent && !member.relation?.trim()) {
        toast.error(`Family Member #${i + 1}: Relation is required`);
        setActiveLeadTab('Family');
        return;
      }
    }

    const toastId = toast.loading(editContactId ? 'Updating contact...' : 'Creating contact...');
    try {
      const mergedTags = [...selectedCampaigns];
      const isCustomerTarget = activeTab === 'customers' || leadInfoFields.profileType === 'Client Profile' || leadInfoFields.profileType === 'Customer Profile';
      if (isCustomerTarget) {
        if (!mergedTags.includes('customer')) {
          mergedTags.push('customer');
        }
      } else {
        if (!mergedTags.includes('contact')) {
          mergedTags.push('contact');
        }
        const custIdx = mergedTags.indexOf('customer');
        if (custIdx !== -1) {
          mergedTags.splice(custIdx, 1);
        }
      }

      const rawAltDigits = personalFields.callingNumber ? personalFields.callingNumber.replace(/\D/g, '') : '';
      const cleanAltPhone = rawAltDigits.length > 10 ? rawAltDigits.slice(-10) : rawAltDigits;

      let contactId = editContactId;
      const validEmpId = (id?: string) => (id && typeof id === 'string' && id.trim()) ? id.trim() : undefined;
      const interestEmpId = productInterests.find(c => validEmpId(c.assignedEmployeeId))?.assignedEmployeeId;
      const selectedEmpIds = Array.isArray(personalFields.assignedEmployeeIds)
        ? personalFields.assignedEmployeeIds.map(validEmpId).filter((id): id is string => Boolean(id))
        : [validEmpId(personalFields.assignedEmployeeId)].filter((id): id is string => Boolean(id));
      const chosenEmpIds = selectedEmpIds.length > 0
        ? Array.from(new Set(selectedEmpIds))
        : (personalFields.assignedEmployeeIds !== undefined
            ? []
            : [validEmpId(interestEmpId) || validEmpId(leadInfoFields.assignedEmployeeId)].filter((id): id is string => Boolean(id)));
      const chosenEmpId = chosenEmpIds[0];

      if (editContactId) {
        const isPlaceholderPhone = (p?: string | null) => {
          if (!p) return true;
          const digits = String(p).replace(/\D/g, '');
          if (!digits || /^0+$/.test(digits) || digits.startsWith('00') || /^(?:91)?0{7,}$/.test(digits)) return true;
          return false;
        };
        const updateBody: any = {
          firstName,
          lastName,
          motherName: personalFields.motherName?.trim() || null,
          isDependent: !!personalFields.isDependent,
          dependentNo: personalFields.isDependent ? personalFields.dependentNo : undefined,
          role: personalFields.role || 'Contact',
          isActive: personalFields.contactStatus ? personalFields.contactStatus === 'Active' : (personalFields.isActive !== false),
          assignedEmployeeId: chosenEmpId || null,
          assignedEmployeeIds: chosenEmpIds,
        };
        if (!isPlaceholderPhone(cleanPhone)) {
          updateBody.phone = cleanPhone;
        } else if (loadedContact?.phone && !isPlaceholderPhone(loadedContact.phone)) {
          updateBody.phone = loadedContact.phone;
        }
        if (personalFields.middleName?.trim()) updateBody.middleName = personalFields.middleName.trim();
        if (cleanAltPhone) updateBody.alternatePhone = cleanAltPhone;
        if (personalFields.email?.trim()) updateBody.email = personalFields.email.trim();
        if (personalFields.gender) updateBody.gender = personalFields.gender;
        if (personalFields.maritalStatus) updateBody.maritalStatus = personalFields.maritalStatus;
        updateBody.weddingAnniversaryDate = personalFields.weddingAnniversaryDate || null;
        if (personalFields.dateOfBirth?.trim()) updateBody.dateOfBirth = toSafeIsoString(personalFields.dateOfBirth);
        if (personalFields.birthPlace?.trim()) updateBody.birthPlace = personalFields.birthPlace.trim();
        updateBody.height = personalFields.height ? String(personalFields.height) : null;
        updateBody.weight = personalFields.weight ? String(personalFields.weight) : null;
        updateBody.medicalHistory = personalFields.medicalHistory || [];
        updateBody.declaredMedicalHistory = personalFields.declaredMedicalHistory || [];
        updateBody.notDeclaredMedicalHistory = personalFields.notDeclaredMedicalHistory || [];
        updateBody.medicalHistoryDetails = personalFields.medicalHistoryDetails || '';
        updateBody.surgeryDetails = personalFields.surgeryDetails || '';
        updateBody.prescriptionDetails = personalFields.prescriptionDetails || '';
        updateBody.chewTobacco = !!personalFields.chewTobacco;
        updateBody.smoke = !!personalFields.smoke;
        updateBody.consumeAlcohol = !!personalFields.consumeAlcohol;
        updateBody.panNumber = (personalFields.panNumber || personalFields.pan) ? String(personalFields.panNumber || personalFields.pan).trim() : null;
        if (cleanAadhaar) updateBody.aadhaarNumber = cleanAadhaar;
        if (personalFields.education) updateBody.education = personalFields.education;
        if (personalFields.annualIncome) updateBody.annualIncome = Number(personalFields.annualIncome);
        if (mergedTags && mergedTags.length > 0) updateBody.tags = mergedTags;
        if (personalFields.streetAddress?.trim()) updateBody.notes = personalFields.streetAddress.trim();
        if (personalFields.bankName !== undefined) updateBody.bankName = personalFields.bankName?.trim() || null;
        if (personalFields.bankAccountNumber !== undefined) updateBody.bankAccountNumber = personalFields.bankAccountNumber?.trim() || null;
        if (personalFields.bankIfsc !== undefined) updateBody.bankIfsc = personalFields.bankIfsc?.trim()?.toUpperCase() || null;
        if (personalFields.bankBranch !== undefined) updateBody.bankBranch = personalFields.bankBranch?.trim() || null;

        await contactsService.update(editContactId, updateBody);

        // Update Address only if changed
        if (loadedContact) {
          const oldAddresses = loadedContact.addresses || [];
          const primaryAddr = oldAddresses.find((a: any) => a.isPrimary) || oldAddresses[0];
          const hasEnteredAddress = Boolean(
            (personalFields.streetAddress && personalFields.streetAddress.trim() !== '' && personalFields.streetAddress.trim() !== 'N/A') ||
            (personalFields.city && personalFields.city.trim() !== '' && personalFields.city.trim() !== 'N/A') ||
            (personalFields.district && personalFields.district.trim() !== '') ||
            (personalFields.state && personalFields.state.trim() !== '' && personalFields.state.trim() !== 'N/A') ||
            (personalFields.pincode && personalFields.pincode.trim() !== '' && personalFields.pincode.trim() !== 'N/A')
          );
          const hasAddressChanged = primaryAddr
            ? (
                (personalFields.streetAddress?.trim() || 'N/A') !== (primaryAddr.line1?.trim() || 'N/A') ||
                (personalFields.city?.trim() || 'N/A') !== (primaryAddr.city?.trim() || 'N/A') ||
                (personalFields.district?.trim() || '') !== (primaryAddr.district?.trim() || '') ||
                (personalFields.state?.trim() || 'N/A') !== (primaryAddr.state?.trim() || 'N/A') ||
                (personalFields.pincode?.trim() || 'N/A') !== (primaryAddr.pincode?.trim() || 'N/A')
              )
            : hasEnteredAddress;

          if (hasAddressChanged) {
            if (hasEnteredAddress) {
              await contactsService.addAddress(editContactId, {
                type: 'HOME',
                line1: personalFields.streetAddress?.trim() || 'N/A',
                city: personalFields.city?.trim() || 'N/A',
                district: personalFields.district?.trim() || undefined,
                state: personalFields.state?.trim() || 'N/A',
                pincode: personalFields.pincode?.trim() || 'N/A',
                country: 'India',
                isPrimary: true,
              }).catch(err => console.error('Failed to update address:', err));
            } else if (oldAddresses.length > 0) {
              for (const addr of oldAddresses) {
                await contactsService.removeAddress(editContactId, addr.id).catch(err => console.error('Failed to remove old address:', err));
              }
            }
          }
        }

        // Update Occupation only if changed
        if (loadedContact) {
          const oldOccs = loadedContact.occupations || [];
          const primaryOcc = oldOccs.find((o: any) => o.isPrimary) || oldOccs[0];
          const currOccType = personalFields.occupationType || 'SALARIED';
          const currCompany = personalFields.companyName || '';
          const hasOccChanged = !primaryOcc ||
            currOccType !== primaryOcc.type ||
            currCompany !== (primaryOcc.companyName || '');

          if (hasOccChanged) {
            for (const occ of oldOccs) {
              await contactsService.removeOccupation(editContactId, occ.id).catch(err => console.error('Failed to remove old occupation:', err));
            }
            if (personalFields.occupationType || personalFields.companyName || personalFields.annualIncome) {
              await contactsService.addOccupation(editContactId, {
                type: personalFields.occupationType || 'SALARIED',
                companyName: personalFields.companyName || undefined,
                isPrimary: true,
              }).catch(err => console.error('Failed to add new occupation:', err));
            }
          }
        }
      } else {
        const contactBody: any = {
          firstName,
          lastName,
          motherName: personalFields.motherName?.trim() || undefined,
          phone: cleanPhone,
          isDependent: !!personalFields.isDependent,
          dependentNo: personalFields.isDependent ? personalFields.dependentNo : undefined,
          role: personalFields.role || 'Contact',
          isActive: personalFields.contactStatus ? personalFields.contactStatus === 'Active' : (personalFields.isActive !== false),
        };
        if (personalFields.middleName?.trim()) contactBody.middleName = personalFields.middleName.trim();
        if (cleanAltPhone) contactBody.alternatePhone = cleanAltPhone;
        if (personalFields.email?.trim()) contactBody.email = personalFields.email.trim();
        if (personalFields.gender) contactBody.gender = personalFields.gender;
        if (personalFields.maritalStatus) contactBody.maritalStatus = personalFields.maritalStatus;
        contactBody.weddingAnniversaryDate = personalFields.weddingAnniversaryDate || null;
        if (personalFields.dateOfBirth?.trim()) contactBody.dateOfBirth = toSafeIsoString(personalFields.dateOfBirth);
        if (personalFields.birthPlace?.trim()) contactBody.birthPlace = personalFields.birthPlace.trim();
        contactBody.height = personalFields.height ? String(personalFields.height) : null;
        contactBody.weight = personalFields.weight ? String(personalFields.weight) : null;
        contactBody.medicalHistory = personalFields.medicalHistory || [];
        contactBody.declaredMedicalHistory = personalFields.declaredMedicalHistory || [];
        contactBody.notDeclaredMedicalHistory = personalFields.notDeclaredMedicalHistory || [];
        contactBody.medicalHistoryDetails = personalFields.medicalHistoryDetails || '';
        contactBody.surgeryDetails = personalFields.surgeryDetails || '';
        contactBody.prescriptionDetails = personalFields.prescriptionDetails || '';
        contactBody.chewTobacco = !!personalFields.chewTobacco;
        contactBody.smoke = !!personalFields.smoke;
        contactBody.consumeAlcohol = !!personalFields.consumeAlcohol;
        if (personalFields.panNumber || personalFields.pan) contactBody.panNumber = personalFields.panNumber || personalFields.pan;
        if (cleanAadhaar) contactBody.aadhaarNumber = cleanAadhaar;
        if (personalFields.education) contactBody.education = personalFields.education;
        if (personalFields.annualIncome) contactBody.annualIncome = Number(personalFields.annualIncome);
        if (mergedTags && mergedTags.length > 0) contactBody.tags = mergedTags;
        if (personalFields.streetAddress?.trim()) contactBody.notes = personalFields.streetAddress.trim();
        if (personalFields.bankName?.trim()) contactBody.bankName = personalFields.bankName.trim();
        if (personalFields.bankAccountNumber?.trim()) contactBody.bankAccountNumber = personalFields.bankAccountNumber.trim();
        if (personalFields.bankIfsc?.trim()) contactBody.bankIfsc = personalFields.bankIfsc.trim().toUpperCase();
        if (personalFields.bankBranch?.trim()) contactBody.bankBranch = personalFields.bankBranch.trim();
        if (chosenEmpIds.length > 0) {
          contactBody.assignedEmployeeId = chosenEmpId;
          contactBody.assignedEmployeeIds = chosenEmpIds;
        }

        const contactRes = await contactsService.createFull({
          contact: contactBody,
          address: (personalFields.state || personalFields.district || personalFields.city || personalFields.pincode || personalFields.streetAddress) ? {
            type: 'HOME',
            line1: personalFields.streetAddress || 'N/A',
            city: personalFields.city || 'N/A',
            district: personalFields.district || undefined,
            state: personalFields.state || 'N/A',
            pincode: personalFields.pincode || 'N/A',
            country: 'India',
            isPrimary: true,
          } : undefined,
          occupation: (personalFields.occupationType || personalFields.companyName || personalFields.annualIncome) ? {
            type: personalFields.occupationType || 'SALARIED',
            companyName: personalFields.companyName || undefined,
            isPrimary: true,
          } : undefined,
        });
        const createdContactObj = contactRes?.data?.contact || contactRes?.data?.data || contactRes?.data || contactRes;
        contactId = createdContactObj?.id || createdContactObj?._id;
        if (contactId) {
          setEditContactId(contactId);
          if (createdContactObj && typeof createdContactObj === 'object') {
            setLoadedContact(createdContactObj);
          }
        }
      }

      const subResourcePromises: Promise<any>[] = [];
      const createdPolicies: any[] = [];

      const currentUser = useAuthStore.getState().user;
      const curEmpId = currentUser?.id;

      // Save Family Members only when creating a new contact (when editing, family members are saved individually via the Family modal)
      if (!editContactId && contactId) {
        for (let i = 0; i < familyMembers.length; i++) {
        const fam = familyMembers[i];
        const famFirst = (fam.firstName || '').trim() || (fam.name || '').trim().split(/\s+/)[0] || '';
        const famMiddle = (fam.middleName || '').trim();
        const famLast = (fam.lastName || '').trim() || (fam.name || '').trim().split(/\s+/).slice(1).join(' ') || '';
        const fullFamName = `${famFirst} ${famMiddle} ${famLast}`.replace(/\s+/g, ' ').trim();
        if (!fullFamName) continue;

        const rawFamPhone = (fam.whatsapp || fam.whatsappNumber || fam.phone || fam.contactNo || '').replace(/\D/g, '');
        const cleanFamPhone = rawFamPhone.length > 10 ? rawFamPhone.slice(-10) : rawFamPhone;
        const validFamPhone = (cleanFamPhone.length === 10 && !cleanFamPhone.startsWith('00') && cleanFamPhone !== '0000000000')
          ? cleanFamPhone
          : (rawFamPhone.length >= 7 && !rawFamPhone.startsWith('00') && rawFamPhone !== '0000000000' ? rawFamPhone : (rawFamPhone || undefined));

        const rawFamCall = (fam.callingNumber || fam.alternatePhone || '').replace(/\D/g, '');
        const cleanFamCall = rawFamCall.length > 10 ? rawFamCall.slice(-10) : rawFamCall;
        const validFamCall = (cleanFamCall.length === 10 && !cleanFamCall.startsWith('00') && cleanFamCall !== '0000000000')
          ? cleanFamCall
          : (rawFamCall.length >= 7 && !rawFamCall.startsWith('00') && rawFamCall !== '0000000000' ? rawFamCall : (rawFamCall || undefined));
        const relType = fam.relation ? fam.relation.toUpperCase().replace(/\s+/g, '_') : 'OTHER';
        const famIsoDob = toSafeIsoString(fam.dob || fam.dateOfBirth);

        const saveFamilyFlow = async () => {
          try {
            let targetFamContactId = fam.contactId;
            const famPayload: any = {
              firstName: famFirst,
              middleName: famMiddle || undefined,
              lastName: famLast,
              phone: validFamPhone || '',
              alternatePhone: validFamCall || undefined,
              email: fam.email ? fam.email.trim() : undefined,
              dateOfBirth: famIsoDob,
              gender: fam.gender || undefined,
              birthPlace: fam.birthPlace ? fam.birthPlace.trim() : undefined,
              motherName: fam.motherName ? fam.motherName.trim() : undefined,
              isDependent: !!fam.isDependent,
              dependentNo: fam.guardianWhatsapp || fam.dependentNo || undefined,
              panNumber: fam.pan || fam.panNumber || undefined,
              aadhaarNumber: fam.aadhaarNumber || undefined,
              annualIncome: fam.annualIncome ? Number(fam.annualIncome) : undefined,
              maritalStatus: fam.maritalStatus || '',
              weddingAnniversaryDate: fam.weddingAnniversary || fam.weddingAnniversaryDate || '',
              education: fam.education || '',
              occupation: fam.occupation || fam.occupationType || '',
              height: fam.height || '',
              weight: fam.weight || '',
              chewTobacco: !!fam.chewTobacco,
              smoke: !!fam.smoke,
              consumeAlcohol: !!fam.consumeAlcohol,
              medicalHistory: fam.medicalHistory || [],
              declaredMedicalHistory: fam.declaredMedicalHistory || [],
              notDeclaredMedicalHistory: fam.notDeclaredMedicalHistory || [],
              medicalHistoryDetails: fam.medicalHistoryDetails || '',
              surgeryDetails: fam.surgeryDetails || '',
              prescriptionDetails: fam.prescriptionDetails || '',
              bankName: fam.bankName ? fam.bankName.trim() : '',
              bankAccountNumber: fam.bankAccountNumber ? fam.bankAccountNumber.trim() : '',
              bankIfsc: (fam.bankIfsc || '').trim().toUpperCase(),
              bankBranch: fam.bankBranch ? fam.bankBranch.trim() : '',
              streetAddress: fam.streetAddress || undefined,
              line1: fam.streetAddress || undefined,
              city: fam.city || undefined,
              district: fam.district || undefined,
              state: fam.state || undefined,
              pincode: fam.pincode || undefined,
            };

            if (targetFamContactId && targetFamContactId !== contactId) {
              await contactsService.update(targetFamContactId, famPayload);
              const hasFamAddr = Boolean(
                (fam.streetAddress && fam.streetAddress.trim() && fam.streetAddress.trim() !== 'N/A') ||
                (fam.city && fam.city.trim() && fam.city.trim() !== 'N/A') ||
                (fam.state && fam.state.trim() && fam.state.trim() !== 'N/A') ||
                (fam.district && fam.district.trim()) ||
                (fam.pincode && fam.pincode.trim() && fam.pincode.trim() !== 'N/A')
              );
              if (hasFamAddr) {
                await contactsService.addAddress(targetFamContactId, {
                  type: 'HOME',
                  line1: fam.streetAddress?.trim() || 'N/A',
                  city: fam.city?.trim() || 'N/A',
                  district: fam.district?.trim() || undefined,
                  state: fam.state?.trim() || 'N/A',
                  pincode: fam.pincode?.trim() || 'N/A',
                  country: 'India',
                  isPrimary: true,
                }).catch(err => console.error('Failed to update family member address:', err));
              }
              let relationshipResponse: any;
              if (fam.id) {
                relationshipResponse = await contactsService.updateRelationship(contactId!, fam.id, {
                  relatedContactId: targetFamContactId,
                  relationshipType: relType,
                  relationship: relType,
                  ...famPayload,
                });
              } else {
                relationshipResponse = await contactsService.addRelationship(contactId!, {
                  relatedContactId: targetFamContactId,
                  relationshipType: relType,
                  relationship: relType,
                  ...famPayload,
                });
              }
              const savedRelationship = relationshipResponse?.data?.relationship || relationshipResponse?.data || relationshipResponse;
              const savedContact = savedRelationship?.relatedContact || relationshipResponse?.data?.relatedContact;
              setFamilyMembers(prev => prev.map((member, index) => index === i ? {
                ...member,
                id: savedRelationship?.id || member.id,
                contactId: savedContact?.id || targetFamContactId,
                relation: savedRelationship?.relationshipType || relType,
              } : member));
            } else {
              const relationshipResponse = await contactsService.addRelationship(contactId!, {
                name: fullFamName,
                relationshipType: relType,
                relationship: relType,
                ...famPayload,
              });
              const savedRelationship = relationshipResponse?.data?.relationship || relationshipResponse?.data || relationshipResponse;
              const savedContact = savedRelationship?.relatedContact || relationshipResponse?.data?.relatedContact;
              setFamilyMembers(prev => prev.map((member, index) => index === i ? {
                ...member,
                id: savedRelationship?.id || member.id,
                contactId: savedContact?.id || member.contactId,
                relation: savedRelationship?.relationshipType || relType,
              } : member));
            }
          } catch (famErr: any) {
            console.error('Failed to save family member:', famErr);
            toast.error(`Failed to save family member "${fullFamName}": ${famErr.response?.data?.message || famErr.message || 'Error'}`);
          }
        };
        subResourcePromises.push(saveFamilyFlow());
      }
    }

      // Save Policies if any (only when creating a new contact)
      if (!editContactId) {
        const dbPlans = useLookupStore.getState().plans || [];
        for (const portfolio of policies) {
          const isHealth = portfolio.policyType === 'Health';
          const category = isHealth ? 'HEALTH' : 'LIFE';
          const matchedPlan = dbPlans.find((p: any) => p.category === category) || dbPlans[0];

          for (const entry of portfolio.entries) {
            if (!entry.policyNo.trim()) continue;
            subResourcePromises.push(
              policiesService.create({
                policyNumber: entry.policyNo,
                contactId: contactId!,
                planId: matchedPlan?.id || '6a3d0584d431b55e6b6e74fe', // fallback ID if plans empty
                sumAssured: Number(entry.sumAssured || entry.sumInsured || 100000),
                premiumAmount: Number(entry.premium || 1000),
                paymentFrequency: 'YEARLY',
                startDate: entry.startDate?.trim() ? new Date(entry.startDate).toISOString() : new Date().toISOString(),
                endDate: entry.endDate?.trim() ? new Date(entry.endDate).toISOString() : new Date(Date.now() + 365 * 86400000).toISOString(),
              }).then((res: any) => {
                const savedPolicy = res?.data ?? res;
                if (savedPolicy) createdPolicies.push(savedPolicy);
                return res;
              }).catch(polErr => console.error('Failed to save policy:', polErr))
            );
          }
        }
      }

      // Save Product Interests (Leads) — only if exclusively selected
      for (const card of productInterests) {
        const rawInterests = (card.interestedIn || [])
          .map((p: string) => (p === 'Other' && card.otherProduct ? card.otherProduct.trim() : p.trim()))
          .filter(Boolean);

        // If product interest was not exclusively selected, do not reflect in Leads
        if (rawInterests.length === 0) {
          continue;
        }

        const interests = rawInterests;

        let stage = card.leadStage && card.leadStage !== 'OPEN' ? card.leadStage : 'TO_CONTACT';

        const serializedNotes = serializeLeadNotes(card);

        const validEmpId = (id?: string) => (id && /^[0-9a-fA-F]{24}$/.test(id.trim())) ? id.trim() : undefined;
        const body = {
          contactId: contactId!,
          interests,
          stage,
          source: card.leadSource || 'Walk-in',
          assignedEmployeeId: validEmpId(card.assignedEmployeeId) || (currentUser?.role === 'EMPLOYEE' ? validEmpId(curEmpId) : undefined),
          followUpDate: card.followUpDate?.trim() ? new Date(card.followUpDate).toISOString() : undefined,
          premiumBudget: Number(card.expectedPremium) || undefined,
          notes: serializedNotes,
        };

        const isExisting = card.id.length === 24 || /^[0-9a-fA-F]{24}$/.test(card.id);
        const saveLeadFlow = async () => {
          try {
            if (isExisting) {
              await leadsService.update(card.id, body);
            } else {
              const res = await leadsService.create(body);
              const savedLead = res.data ?? res;
              for (const cmt of card.comments) {
                await leadsService.addConsultation(savedLead.id, { notes: cmt.text });
              }
            }
          } catch (leadErr: any) {
            console.error('Failed to save product interest:', leadErr);
            toast.error(`Failed to save Product Interest (${interests.join(', ')}): ${leadErr.response?.data?.message || 'Error occurred'}`);
          }
        };
        subResourcePromises.push(saveLeadFlow());
      }

      // Await all sub-resource updates concurrently
      await Promise.all(subResourcePromises);

      if (createdPolicies.length > 0) {
        setLoadedContact((prev: any) => prev ? {
          ...prev,
          policies: [...(prev.policies || []), ...createdPolicies],
        } : prev);
      }

      const targetLabel = activeTab === 'customers' ? 'Customer' : 'Contact';
      toast.success(
        editContactId
          ? `${targetLabel} updated successfully!`
          : (shouldClose ? `${targetLabel} created successfully!` : 'Draft saved successfully!'),
        { id: toastId }
      );
      if (editContactId) {
        qc.setQueriesData({ queryKey: ['contacts'] }, (old: any) => {
          if (!old) return old;
          const updateList = (list: any[]) =>
            list.map(item =>
              item.id === editContactId || item._id === editContactId || item.contactId === editContactId
                ? {
                    ...item,
                    assignedEmployeeId: chosenEmpId || null,
                    assignedEmployeeIds: chosenEmpIds,
                  }
                : item
            );
          if (Array.isArray(old)) return updateList(old);
          if (Array.isArray(old.data)) return { ...old, data: updateList(old.data) };
          if (Array.isArray(old.data?.data)) return { ...old, data: { ...old.data, data: updateList(old.data.data) } };
          return old;
        });
      }
      qc.invalidateQueries({ queryKey: ['contacts'] });
      qc.refetchQueries({ queryKey: ['contacts'] });
      setPage(1);
      refetchContacts();
      qc.invalidateQueries({ queryKey: ['leads'] });
      qc.invalidateQueries({ queryKey: ['policies'] });
      qc.invalidateQueries({ queryKey: ['contacts-policies-list'] });
      qc.invalidateQueries({ queryKey: ['leads-policies-list'] });
      qc.invalidateQueries({ queryKey: ['claims'] });
      qc.invalidateQueries({ queryKey: ['contact-activity'] });
      if (editContactId) {
        qc.invalidateQueries({ queryKey: ['contact-activity', editContactId] });
        qc.refetchQueries({ queryKey: ['contact-activity', editContactId] });
      }
      if (historyContactId && historyContactId !== editContactId) {
        qc.invalidateQueries({ queryKey: ['contact-activity', historyContactId] });
        qc.refetchQueries({ queryKey: ['contact-activity', historyContactId] });
      }
      if (editContactId) {
        contactsService.get(editContactId).then(res => {
          const c = res?.data?.data || res?.data || res;
          if (c && typeof c === 'object') setLoadedContact(c);
        }).catch(() => {});
      }

      if (shouldClose) {
        setLeadModalOpen(false);
      }
    } catch (err: any) {
      const errMsg = Array.isArray(err.response?.data?.errors)
        ? err.response.data.errors.join(' | ')
        : (err.response?.data?.message || err.message || 'Failed to save customer');
      toast.error(errMsg, { id: toastId });
    }
  };

  const activeSchema = useMemo(() => {
    return z.object({
      firstName: isFieldRequired('firstName', true) ? z.string().min(1, 'Required') : z.string().optional().or(z.literal('')),
      lastName: isFieldRequired('lastName', true) ? z.string().min(1, 'Required') : z.string().optional().or(z.literal('')),
      phone: isFieldRequired('phone', true)
        ? z.string().refine(v => {
            const d = (v || '').replace(/\D/g, '');
            return d.length === 10 || (d.length > 10 && d.slice(-10).length === 10);
          }, 'Mobile number must be exactly 10 digits')
        : z.string().optional().refine(v => {
            if (!v) return true;
            const d = v.replace(/\D/g, '');
            return d.length === 10 || (d.length > 10 && d.slice(-10).length === 10);
          }, 'Mobile number must be exactly 10 digits').or(z.literal('')),
      alternatePhone: isFieldRequired('alternatePhone', false)
        ? z.string().refine(v => {
            const d = (v || '').replace(/\D/g, '');
            return d.length === 10 || (d.length > 10 && d.slice(-10).length === 10);
          }, 'Alternate phone must be exactly 10 digits')
        : z.string().optional().refine(v => {
            if (!v) return true;
            const d = v.replace(/\D/g, '');
            return d.length === 10 || (d.length > 10 && d.slice(-10).length === 10);
          }, 'Alternate phone must be exactly 10 digits').or(z.literal('')),
      email: isFieldRequired('email', false) ? z.string().email('Invalid email') : z.string().email('Invalid email').optional().or(z.literal('')),
      gender: isFieldRequired('gender', false) ? z.enum(['MALE', 'FEMALE', 'OTHER']).refine(val => !!val, { message: 'Required' }) : z.enum(['MALE', 'FEMALE', 'OTHER', '']).optional(),
      dateOfBirth: isFieldRequired('dateOfBirth', false) ? z.string().min(1, 'Required') : z.string().optional().or(z.literal('')),
      birthPlace: isFieldRequired('birthPlace', false) ? z.string().min(1, 'Required') : z.string().optional().or(z.literal('')),
      panNumber: isFieldRequired('panNumber', false) ? z.string().min(1, 'Required') : z.string().optional().or(z.literal('')),
      aadhaarNumber: isFieldRequired('aadhaarNumber', false) ? z.string().min(1, 'Required') : z.string().optional().or(z.literal('')),
      annualIncome: isFieldRequired('annualIncome', false) ? z.coerce.number().min(0) : z.coerce.number().min(0).optional().or(z.literal('')),
      notes: isFieldRequired('notes', false) ? z.string().min(1, 'Required') : z.string().optional().or(z.literal('')),
      tags: isFieldRequired('tags', false) ? z.string().min(1, 'Required') : z.string().optional().or(z.literal('')),
      isActive: z.string().optional(),
      city: isFieldRequired('city', false) ? z.string().min(1, 'Required') : z.string().optional().or(z.literal('')),
      source: isFieldRequired('source', false) ? z.string().min(1, 'Required') : z.string().optional().or(z.literal('')),
      assignedEmployeeId: isFieldRequired('assignedEmployeeId', false) ? z.string().min(1, 'Required') : z.string().optional().or(z.literal('')),
      leadStage: isFieldRequired('leadStage', false) ? z.string().min(1, 'Required') : z.string().optional().or(z.literal('')),
      leadStatus: isFieldRequired('leadStatus', false) ? z.string().min(1, 'Required') : z.string().optional().or(z.literal('')),
      leadType: isFieldRequired('leadType', false) ? z.string().min(1, 'Required') : z.string().optional().or(z.literal('')),
      followUpDate: isFieldRequired('followUpDate', false) ? z.string().min(1, 'Required') : z.string().optional().or(z.literal('')),
    });
  }, [compulsoryRules]);

  const { register, handleSubmit, reset, setValue, formState: { errors } } = useForm<Form>({ resolver: zodResolver(activeSchema) });

  const getEmployeeName = (id?: string | null, assignedEmpObj?: any, contactItem?: any) => {
    const formatEmployee = (employee?: any, employeeId?: string | null) => {
      if (employee) {
        const profile = employee.employeeProfile;
        const name = profile
          ? `${profile.firstName || ''} ${profile.lastName || ''}`.trim()
          : (employee.name || employee.email || '');
        if (name) return name;
      }

      if (!employeeId) return '';
      const matchedEmployee = employeesList.find((item: any) =>
        item.id === employeeId || item.userId === employeeId || item.user?.id === employeeId
      );
      return matchedEmployee
        ? `${matchedEmployee.firstName ?? matchedEmployee.user?.firstName ?? ''} ${matchedEmployee.lastName ?? matchedEmployee.user?.lastName ?? ''}`.trim()
          || matchedEmployee.name
          || matchedEmployee.email
          || ''
        : '';
    };

    // 1. Direct assigned employee of contact (Primary)
    const directEmployee = formatEmployee(
      assignedEmpObj || (id === contactItem?.assignedEmployeeId ? contactItem?.assignedEmployee : undefined),
      id || contactItem?.assignedEmployeeId,
    );
    if (directEmployee) return directEmployee;

    if (!id) {
      // 2. Product interest assignee fallback
      const productInterest = contactItem?.productInterests?.find((item: any) =>
        item.assignedEmployee || item.assignedEmployeeId
      );
      const productInterestEmployee = formatEmployee(
        productInterest?.assignedEmployee,
        productInterest?.assignedEmployeeId,
      );
      if (productInterestEmployee) return productInterestEmployee;

      // 3. Policy assignee fallback
      const policy = contactItem?.policies?.find((item: any) => item.assignedEmployee || item.assignedEmployeeId);
      const policyEmployee = formatEmployee(policy?.assignedEmployee, policy?.assignedEmployeeId);
      if (policyEmployee) return policyEmployee;
    }

    return 'Unassigned';
  };

  const getAssignedEmployeeIds = (contactItem: any): string[] => {
    const list = [
      ...(Array.isArray(contactItem?.assignedEmployeeIds) ? contactItem.assignedEmployeeIds : []),
      ...(contactItem?.assignedEmployeeId ? [contactItem.assignedEmployeeId] : []),
    ].filter(Boolean);
    return Array.from(new Set(list));
  };

  const handlePickContact = async (contact: any) => {
    const currentUserId = user?.id;
    if (!currentUserId) {
      toast.error('User session not found');
      return;
    }
    const toastId = toast.loading('Assigning contact to you...');
    try {
      await contactsService.update(contact.id, { assignedEmployeeId: currentUserId });
      toast.success('Contact picked successfully!', { id: toastId });
      qc.invalidateQueries({ queryKey: ['contacts'] });
      qc.refetchQueries({ queryKey: ['contacts'] });
      refetchContacts();
      qc.invalidateQueries({ queryKey: ['leads'] });
      qc.invalidateQueries({ queryKey: ['policies'] });
    } catch (err: any) {
      toast.error(err.response?.data?.message ?? 'Failed to pick contact', { id: toastId });
    }
  };

  const openCreate = () => {
    setPersonalFields({
      role: 'Contact',
      contactStatus: 'Active',
      isActive: true,
      fullName: '',
      motherName: '',
      gender: '',
      maritalStatus: '',
      dateOfBirth: '',
      birthPlace: '',
      declaredMedicalHistory: [],
      notDeclaredMedicalHistory: [],
      medicalHistoryDetails: '',
      email: '',
      aadhaarNumber: '',
      whatsappNumber: '',
      sameAsWhatsapp: false,
      callingNumber: '',
      education: '',
      annualIncome: '',
      occupationType: '',
      companyName: '',
      state: '',
      district: '',
      city: '',
      pincode: '',
      streetAddress: '',
      bankName: '',
      bankAccountNumber: '',
      bankIfsc: '',
      bankBranch: '',
      assignedEmployeeId: '',
      assignedEmployeeIds: [],
    });

    const currentUser = useAuthStore.getState().user;
    const curEmp = employees.find(e => e.userId === currentUser?.id || e.id === currentUser?.id);
    const defaultEmpId = currentUser?.role === 'EMPLOYEE' ? (curEmp?.userId || currentUser?.id || '') : '';

    setPersonalFields(prev => ({
      ...prev,
      assignedEmployeeId: defaultEmpId,
      assignedEmployeeIds: defaultEmpId ? [defaultEmpId] : [],
    }));
    setLeadInfoFields({
      profileType: 'Contact Profile',
      leadStatus: 'OPEN',
      interestedIn: [],
      leadSource: 'Walkin',
      assignedEmployeeId: defaultEmpId,
      followUpDate: '',
    });
    setLeadComments([]);
    setNewComment('');
    setProductInterests([]);
    setFamilyMembers([]);
    setPolicies([]);
    setSelectedCampaigns([]);
    setEditContactId(null);
    setPersonalCollapsed(INITIAL_PERSONAL_COLLAPSED);
    setActiveLeadTab('Personal');
    setLeadModalOpen(true);
  };



  useEffect(() => {
    const state = location.state as any;
    if (state?.reopenContactId) {
      openLeadEdit({ contactId: state.reopenContactId }).then(() => {
        setActiveLeadTab(state.reopenTab || 'Policy');
      });
    }
  }, [location.state]);

  const confirmDelete = async () => {
    if (!deleteTarget) return;
    const isAdmin = authUser?.role === 'OWNER' || authUser?.role === 'SUPERADMIN';
    if (isAdmin) {
      await deleteContact.mutateAsync(deleteTarget.id);
    } else {
      const toastId = toast.loading('Submitting delete request to admin...');
      try {
        await deletionRequestsService.requestDeletion('Contact', deleteTarget.id, `Employee requested deletion of contact`);
        toast.success('Deletion request submitted to admin successfully!', { id: toastId });
      } catch (err: any) {
        toast.error(err.response?.data?.message || 'Failed to submit request', { id: toastId });
      }
    }
    setDeleteTarget(null);
  };

  // Local filtering on paginated records based on quick filters
  const filteredData = useMemo(() => {
    const list = activeTab === 'birthdays'
      ? (birthdayRes?.data ?? [])
      : contactsListArray;

    return list.filter((item: any) => {
      // Employee role data isolation safeguard: only show contacts assigned to this employee.
      if (user?.role === 'EMPLOYEE') {
        const currentUserId = user.id;
        const myEmp = employeesList.find((e: any) => e.userId === currentUserId || e.user?.id === currentUserId || e.id === currentUserId);
        const validMyIds = [currentUserId];
        if (myEmp?.id) validMyIds.push(myEmp.id);
        if (myEmp?.userId) validMyIds.push(myEmp.userId);
        if (myEmp?.user?.id) validMyIds.push(myEmp.user.id);

        const assignedEmployeeIds = getAssignedEmployeeIds(item);
        const directEmpIds = [
          ...assignedEmployeeIds,
          item.assignedEmployeeId,
          item.assignedEmployee?.id,
          item.assignedEmployee?.userId,
        ].filter(Boolean);

        const isAssignedToMe = directEmpIds.some((empId: string) => {
          if (validMyIds.includes(empId)) return true;
          const matchedEmp = employeesList.find((e: any) => e.id === empId || e.userId === empId || e.user?.id === empId);
          if (matchedEmp) {
            const empUserOrProfileIds = [matchedEmp.id, matchedEmp.userId, matchedEmp.user?.id].filter(Boolean);
            return empUserOrProfileIds.some((id: string) => validMyIds.includes(id));
          }
          return false;
        });

        if (!isAssignedToMe) return false;
      }

      // Contact Active Status Resolution
      const isItemActive = item.isActive === true || item.isActive === 'true' || (item.isActive !== false && item.isActive !== 'false' && (item.contactStatus || '').toLowerCase() !== 'inactive');

      // Text Search: Full Name, Phone, Alternate Phone, Email, Contact ID, Aadhaar, PAN, Role, City, Stage, Status, Assigned Employee
      if (search && search.trim()) {
        const sTerm = search.trim().toLowerCase();
        const searchTokens = sTerm.split(/\s+/).filter(Boolean);
        const fullName = [item.firstName || item.contact?.firstName, item.middleName || item.contact?.middleName, item.lastName || item.contact?.lastName].filter(Boolean).join(' ').trim().toLowerCase();
        const phone = (item.phone || item.contact?.phone || '').toLowerCase();
        const altPhone = (item.alternatePhone || item.contact?.alternatePhone || '').toLowerCase();
        const email = (item.email || item.contact?.email || '').toLowerCase();
        const cid = (item.contactId || item.id || '').toLowerCase();
        const aadh = (item.aadhaarNumber || item.contact?.aadhaarNumber || '').toLowerCase();
        const pan = (item.panNumber || item.contact?.panNumber || '').toLowerCase();
        const role = (item.role || item.user?.role || 'Contact').toLowerCase();
        const city = (item.city || item.address?.city || item.addresses?.[0]?.city || item.contact?.city || (item.contact as any)?.addresses?.[0]?.city || '').toLowerCase();
        const leadStage = (item.leadStage || item.stage || '').toLowerCase();
        const leadStatus = (item.leadStatus || '').toLowerCase();
        const source = (item.source || '').toLowerCase();
        const statusStr = isItemActive ? 'active' : 'inactive';
        const empName = getEmployeeName(item.assignedEmployeeId, item.assignedEmployee, item).toLowerCase();

        const matchesFullName = searchTokens.every(token => fullName.includes(token));
        const matchesOther =
          phone.includes(sTerm) ||
          altPhone.includes(sTerm) ||
          email.includes(sTerm) ||
          cid.includes(sTerm) ||
          aadh.includes(sTerm) ||
          pan.includes(sTerm) ||
          role.includes(sTerm) ||
          city.includes(sTerm) ||
          leadStage.includes(sTerm) ||
          leadStatus.includes(sTerm) ||
          source.includes(sTerm) ||
          statusStr === sTerm ||
          empName.includes(sTerm);

        if (!matchesFullName && !matchesOther) {
          return false;
        }
      }

      // Date range filtering
      if (dateFrom) {
        const parseSafe = (dStr: any) => {
          if (!dStr) return null;
          if (dStr instanceof Date) return isNaN(dStr.getTime()) ? null : dStr;
          const s = String(dStr).trim();
          if (/^\d{2}\/\d{2}\/\d{4}$/.test(s)) {
            const [d, m, y] = s.split('/').map(Number);
            return new Date(y, m - 1, d);
          }
          if (/^\d{4}-\d{2}-\d{2}/.test(s)) {
            const [y, m, d] = s.slice(0, 10).split('-').map(Number);
            return new Date(y, m - 1, d);
          }
          const parsed = new Date(s);
          return isNaN(parsed.getTime()) ? null : parsed;
        };
        const itemDate = parseSafe(item.createdAt || item.contact?.createdAt);
        const fromDate = parseSafe(dateFrom);
        if (fromDate && itemDate) {
          fromDate.setHours(0, 0, 0, 0);
          if (itemDate.getTime() < fromDate.getTime()) return false;
        } else if (!itemDate) {
          return false;
        }
      }
      if (dateTo) {
        const parseSafe = (dStr: any) => {
          if (!dStr) return null;
          if (dStr instanceof Date) return isNaN(dStr.getTime()) ? null : dStr;
          const s = String(dStr).trim();
          if (/^\d{2}\/\d{2}\/\d{4}$/.test(s)) {
            const [d, m, y] = s.split('/').map(Number);
            return new Date(y, m - 1, d);
          }
          if (/^\d{4}-\d{2}-\d{2}/.test(s)) {
            const [y, m, d] = s.slice(0, 10).split('-').map(Number);
            return new Date(y, m - 1, d);
          }
          const parsed = new Date(s);
          return isNaN(parsed.getTime()) ? null : parsed;
        };
        const itemDate = parseSafe(item.createdAt || item.contact?.createdAt);
        const toDate = parseSafe(dateTo);
        if (toDate && itemDate) {
          toDate.setHours(23, 59, 59, 999);
          if (itemDate.getTime() > toDate.getTime()) return false;
        } else if (!itemDate) {
          return false;
        }
      }

      const medicalOptions = [
        "BP",
        "Sugar",
        "Heart",
        "Thyroid",
        "Others",
      ];
      // Product Category Quick & Advanced Multi-Select Filter
      if (filterProducts.length > 0) {
        const contactPolicies = (policyMap[item.id] && policyMap[item.id].length > 0)
          ? policyMap[item.id]
          : (item.policies || []);

        const itemTags: string[] = item.tags || item.contact?.tags || [];

        const matchesProduct = filterProducts.some(fp => {
          const filterUpper = fp.toUpperCase();
          const filterLower = fp.toLowerCase();

          const hasProductPolicy = contactPolicies.some((p: any) => {
            const rawCat = (p.category || p.policyCategory || p.policyType || p.type || p.plan?.category || p.plan?.type || p.plan?.company?.category || '').toUpperCase();
            const name = (p.plan?.name || p.policyName || p.policyNumber || '').toLowerCase();
            const notesText = (p.notes || '').toLowerCase();
            const isHealthPlan = rawCat.includes('HEALTH') || rawCat.includes('MEDICLAIM') || name.includes('health') || name.includes('mediclaim') || name.includes('optima') || name.includes('care') || notesText.includes('optima') || notesText.includes('care advantage');
            const isLifePlan = rawCat.includes('LIFE') || rawCat.includes('TERM') || name.includes('life') || name.includes('term') || name.includes('protect') || name.includes('jeevan') || name.includes('gift');
            const isMotorPlan = rawCat.includes('MOTOR') || name.includes('motor') || name.includes('vehicle') || name.includes('car') || name.includes('bike');
            const isAccidentPlan = (rawCat.includes('ACCIDENT') || name.includes('accident') || /(^|[^a-zA-Z])(pa|personal\s*accident)([^a-zA-Z]|$)/i.test(name)) && !isHealthPlan && !isMotorPlan;
            const isGeneralPlan = rawCat.includes('GENERAL') || isMotorPlan || isAccidentPlan || name.includes('travel') || name.includes('fire') || name.includes('sme');

            if (filterUpper === 'HEALTH') return isHealthPlan;
            if (filterUpper === 'LIFE') return isLifePlan;
            if (filterUpper === 'MOTOR') return isMotorPlan;
            if (filterUpper === 'GENERAL') return isGeneralPlan;
            if (filterUpper === 'MF') return rawCat.includes('MF') || rawCat.includes('MUTUAL') || rawCat.includes('FUND') || name.includes('mutual');
            if (filterUpper === 'ACCIDENT') return isAccidentPlan;
            if (filterUpper === 'OTHER') return rawCat.includes('OTHER') || rawCat.includes('SME') || rawCat.includes('TRAVEL');
            return rawCat === filterUpper || rawCat.includes(filterUpper) || name.includes(filterLower);
          });

          const hasProductInterest =
            (item.interests && item.interests.some((i: string) => {
              const iUp = i.toUpperCase();
              if (filterUpper === 'HEALTH' && (iUp.includes('HEALTH') || iUp.includes('MEDICLAIM'))) return true;
              if (filterUpper === 'LIFE' && (iUp.includes('LIFE') || iUp.includes('TERM'))) return true;
              if (filterUpper === 'MOTOR' && (iUp.includes('MOTOR') || iUp.includes('VEHICLE') || iUp.includes('CAR'))) return true;
              if (filterUpper === 'GENERAL' && (iUp.includes('GENERAL') || iUp.includes('MOTOR') || iUp.includes('TRAVEL') || iUp.includes('SME') || iUp.includes('ACCIDENT'))) return true;
              if (filterUpper === 'MF' && (iUp.includes('MF') || iUp.includes('MUTUAL'))) return true;
              if (filterUpper === 'ACCIDENT' && iUp.includes('ACCIDENT')) return true;
              if (filterUpper === 'OTHER' && (iUp.includes('OTHER') || iUp.includes('GENERAL'))) return true;
              return iUp === filterUpper || iUp.includes(filterUpper);
            })) ||
            (item.productInterests && item.productInterests.some((pi: any) =>
              (pi.interests || []).some((i: string) => {
                const iUp = i.toUpperCase();
                if (filterUpper === 'HEALTH' && (iUp.includes('HEALTH') || iUp.includes('MEDICLAIM'))) return true;
                if (filterUpper === 'LIFE' && (iUp.includes('LIFE') || iUp.includes('TERM'))) return true;
                if (filterUpper === 'MOTOR' && (iUp.includes('MOTOR') || iUp.includes('VEHICLE') || iUp.includes('CAR'))) return true;
                if (filterUpper === 'GENERAL' && (iUp.includes('GENERAL') || iUp.includes('MOTOR') || iUp.includes('TRAVEL') || iUp.includes('SME') || iUp.includes('ACCIDENT'))) return true;
                if (filterUpper === 'MF' && (iUp.includes('MF') || iUp.includes('MUTUAL'))) return true;
                if (filterUpper === 'ACCIDENT' && iUp.includes('ACCIDENT')) return true;
                if (filterUpper === 'OTHER' && (iUp.includes('OTHER') || iUp.includes('GENERAL'))) return true;
                return iUp === filterUpper || iUp.includes(filterUpper);
              })
            )) ||
            (item.leadInfo?.interestedIn && item.leadInfo.interestedIn.some((i: string) => {
              const iUp = i.toUpperCase();
              if (filterUpper === 'HEALTH' && iUp.includes('HEALTH')) return true;
              if (filterUpper === 'LIFE' && iUp.includes('LIFE')) return true;
              if (filterUpper === 'MOTOR' && (iUp.includes('MOTOR') || iUp.includes('VEHICLE'))) return true;
              if (filterUpper === 'GENERAL' && (iUp.includes('GENERAL') || iUp.includes('MOTOR') || iUp.includes('ACCIDENT'))) return true;
              if (filterUpper === 'MF' && iUp.includes('MF')) return true;
              if (filterUpper === 'ACCIDENT' && iUp.includes('ACCIDENT')) return true;
              return iUp.includes(filterUpper);
            })) ||
            itemTags.some((t: string) => {
              const tUp = t.toUpperCase();
              if (filterUpper === 'GENERAL') return tUp === 'GENERAL' || tUp.includes('GENERAL');
              if (filterUpper === 'ACCIDENT') return tUp === 'ACCIDENT' || tUp.includes('ACCIDENT');
              if (filterUpper === 'HEALTH') return tUp === 'HEALTH' || tUp.includes('HEALTH');
              if (filterUpper === 'LIFE') return tUp === 'LIFE' || tUp.includes('LIFE');
              if (filterUpper === 'MOTOR') return tUp === 'MOTOR' || tUp.includes('MOTOR');
              if (filterUpper === 'MF') return tUp === 'MF' || tUp.includes('MUTUAL');
              return tUp === filterUpper || tUp.includes(filterUpper);
            });

          return hasProductPolicy || hasProductInterest;
        });

        const ok = excludeProduct ? !matchesProduct : matchesProduct;
        if (!ok) return false;
      }

      const tags = item.tags || item.contact?.tags || [];
      const hasTag = (tag: string) => tags.some((t: string) => t.toLowerCase() === tag.toLowerCase());

      const isCustomer = (item.policies && item.policies.length > 0) || hasTag('customer') || (policyMap[item.id]?.length > 0);

      if (activeTab === 'customers') {
        // Customer tab filters
        if (!isCustomer && !hasTag('customer')) return false;

        const contactPolicies = policyMap[item.id] ?? [];
        const contactClaims = claimMap[item.id] ?? [];

        if (selectedFilters.includes('Renew Due')) {
          const hasDue = contactPolicies.some((p: any) =>
            p.status === 'ACTIVE' && p.endDate && new Date(p.endDate) <= new Date(Date.now() + 30 * 86400000)
          );
          if (!hasDue) return false;
        }
        if (selectedFilters.includes('Active Claim')) {
          const hasActive = contactClaims.some((c: any) =>
            ['INTIMATED', 'FILED', 'IN_REVIEW'].includes(c.status)
          );
          if (!hasActive) return false;
        }
        if (selectedFilters.includes('Health')) {
          const ok = hasTag('health') ||
            contactPolicies.some((p: any) =>
              p.plan?.category?.toLowerCase().includes('health') ||
              p.plan?.name?.toLowerCase().includes('health')
            );
          if (!ok) return false;
        }
        if (selectedFilters.includes('Term')) {
          const ok = hasTag('term') ||
            contactPolicies.some((p: any) =>
              p.plan?.category?.toLowerCase().includes('term') ||
              p.plan?.name?.toLowerCase().includes('term')
            );
          if (!ok) return false;
        }
      }
      // 1. Next Follow-up Date Filter
      if (filterFollowUpFrom || filterFollowUpTo) {
        const dates: number[] = [];
        const extractTime = (d: any) => {
          if (!d) return null;
          if (d instanceof Date) return isNaN(d.getTime()) ? null : d.getTime();
          const s = String(d).trim();
          if (/^\d{2}\/\d{2}\/\d{4}$/.test(s)) {
            const [day, m, y] = s.split('/').map(Number);
            return new Date(y, m - 1, day).getTime();
          }
          if (/^\d{4}-\d{2}-\d{2}/.test(s)) {
            const [y, m, day] = s.slice(0, 10).split('-').map(Number);
            return new Date(y, m - 1, day).getTime();
          }
          const t = new Date(s).getTime();
          return isNaN(t) ? null : t;
        };

        const t1 = extractTime(item.followUpDate);
        if (t1) dates.push(t1);
        const t2 = extractTime(item.leadInfo?.followUpDate);
        if (t2) dates.push(t2);
        if (Array.isArray(item.productInterests)) {
          item.productInterests.forEach((pi: any) => {
            const tPi = extractTime(pi.followUpDate);
            if (tPi) dates.push(tPi);
          });
        }
        if (dates.length === 0) return false;

        const parseBound = (b: any, endOfDay = false) => {
          if (!b) return null;
          const s = String(b).trim();
          let dt: Date;
          if (/^\d{2}\/\d{2}\/\d{4}$/.test(s)) {
            const [day, m, y] = s.split('/').map(Number);
            dt = new Date(y, m - 1, day);
          } else if (/^\d{4}-\d{2}-\d{2}/.test(s)) {
            const [y, m, day] = s.slice(0, 10).split('-').map(Number);
            dt = new Date(y, m - 1, day);
          } else {
            dt = new Date(s);
          }
          if (isNaN(dt.getTime())) return null;
          if (endOfDay) dt.setHours(23, 59, 59, 999);
          else dt.setHours(0, 0, 0, 0);
          return dt.getTime();
        };

        const fromTime = parseBound(filterFollowUpFrom, false);
        const toTime = parseBound(filterFollowUpTo, true);

        const matches = dates.some(t => {
          if (fromTime !== null && t < fromTime) return false;
          if (toTime !== null && t > toTime) return false;
          return true;
        });
        if (!matches) return false;
      }

      // 2. Gender Filter
      if (filterGender && filterGender !== 'ALL') {
        const g = (item.gender || item.contact?.gender || '').toString().trim().toUpperCase();
        if (g !== filterGender.trim().toUpperCase()) return false;
      }

      // 3. Marital Status Filter
      if (filterMaritalStatus && filterMaritalStatus !== 'ALL') {
        const ms = (item.maritalStatus || item.contact?.maritalStatus || '').toString().trim().toUpperCase();
        if (ms !== filterMaritalStatus.trim().toUpperCase()) return false;
      }

      // 4. Age Range Filter
      if (filterAgeRange && filterAgeRange !== 'ALL') {
        const dob = item.dateOfBirth || item.contact?.dateOfBirth;
        if (!dob) return false;
        const age = calculateAge(dob);
        if (filterAgeRange === '0_18' && !(age >= 0 && age <= 18)) return false;
        if (filterAgeRange === '19_25' && !(age >= 19 && age <= 25)) return false;
        if (filterAgeRange === '26_30' && !(age >= 26 && age <= 30)) return false;
        if (filterAgeRange === '31_35' && !(age >= 31 && age <= 35)) return false;
        if (filterAgeRange === '36_40' && !(age >= 36 && age <= 40)) return false;
        if (filterAgeRange === '41_50' && !(age >= 41 && age <= 50)) return false;
        if (filterAgeRange === '51_60' && !(age >= 51 && age <= 60)) return false;
        if (filterAgeRange === '61_75' && !(age >= 61 && age <= 75)) return false;
        if (filterAgeRange === '75_PLUS' && !(age > 75)) return false;
      }

      // 5. Annual Income Filter
      if (filterIncomeRange && filterIncomeRange !== 'ALL') {
        const rawInc = item.annualIncome ?? item.contact?.annualIncome;
        if (rawInc === null || rawInc === undefined || rawInc === '') return false;
        const inc = Number(rawInc);
        if (isNaN(inc)) return false;
        if (filterIncomeRange === '0_2.5L' && !(inc >= 0 && inc <= 250000)) return false;
        if (filterIncomeRange === '2.5L_5L' && !(inc > 250000 && inc <= 500000)) return false;
        if (filterIncomeRange === '5L_10L' && !(inc > 500000 && inc <= 1000000)) return false;
        if (filterIncomeRange === '10L_25L' && !(inc > 1000000 && inc <= 2500000)) return false;
        if (filterIncomeRange === '25L_50L' && !(inc > 2500000 && inc <= 5000000)) return false;
        if (filterIncomeRange === '50L_PLUS' && !(inc > 5000000)) return false;
      }

      // 6. Education Filter
      if (filterEducation && filterEducation !== 'ALL') {
        const targetEdu = filterEducation.trim().toLowerCase();
        const edu = (item.education || item.contact?.education || '').toString().trim().toLowerCase();
        if (!edu || edu !== targetEdu) return false;
      }

      // 7. Occupation Filter
      if (filterOccupation && filterOccupation !== 'ALL') {
        const targetOcc = filterOccupation.trim().toLowerCase();
        const contactOccs = [
          item.occupation,
          item.occupationType,
          ...(item.occupations || []).map((o: any) => o.type),
          ...(item.contact?.occupations || []).map((o: any) => o.type),
        ].filter(Boolean).map((s: string) => s.trim().toLowerCase());

        if (contactOccs.length === 0) return false;

        const matchesOcc = contactOccs.some(occ => {
          if (targetOcc === 'business') {
            return occ === 'business' || occ === 'business / self employed';
          }
          if (targetOcc === 'business owner') {
            return occ === 'business owner' || occ === 'business_owner';
          }
          if (targetOcc === 'salaried private') {
            return occ === 'salaried private' || occ === 'salaried_private';
          }
          if (targetOcc === 'salaried gov') {
            return occ === 'salaried gov' || occ === 'salaried_gov';
          }
          if (targetOcc === 'salaried/service') {
            return occ === 'salaried/service' || occ === 'salaried' || occ === 'salaryed' || occ === 'service';
          }
          if (targetOcc === 'self employed professional') {
            return occ === 'self employed professional' || occ === 'self_employed_professional' || occ === 'self_employed';
          }
          return occ === targetOcc;
        });

        if (!matchesOcc) return false;
      }

      // 8. Residency Status Filter (Indian / NRI / OCI)
      if (filterResidency && filterResidency !== 'ALL') {
        const targetRes = filterResidency.trim().toLowerCase();
        const res = (item.residencyStatus || item.contact?.residencyStatus || '').toString().trim().toLowerCase();
        const country = (item.addresses?.[0]?.country || item.contact?.addresses?.[0]?.country || '').toString().trim().toLowerCase();
        const notes = (item.notes || '').toString().trim().toLowerCase();

        let isMatch = false;
        if (res) {
          isMatch = res.includes(targetRes);
        } else if (targetRes === 'indian') {
          isMatch = !country || country === 'india' || country === 'indian';
        } else if (targetRes === 'nri') {
          isMatch = (country && country !== 'india' && country !== 'indian') || notes.includes('nri');
        } else if (targetRes === 'oci') {
          isMatch = notes.includes('oci');
        }
        if (!isMatch) return false;
      }

      // 9. State Filter
      if (filterState && filterState.trim()) {
        const targetState = filterState.trim().toLowerCase();
        const states = [
          item.state,
          item.contact?.state,
          ...(item.addresses || []).map((a: any) => a.state),
          ...(item.contact?.addresses || []).map((a: any) => a.state),
        ].filter(Boolean).map((s: string) => s.toLowerCase());

        if (!states.some(s => s.includes(targetState))) return false;
      }

      // 10. City Filter
      if (filterCity && filterCity.trim()) {
        const targetCity = filterCity.trim().toLowerCase();
        const cities = [
          item.city,
          item.contact?.city,
          ...(item.addresses || []).map((a: any) => a.city),
          ...(item.contact?.addresses || []).map((a: any) => a.city),
        ].filter(Boolean).map((c: string) => c.toLowerCase());

        if (!cities.some(c => c.includes(targetCity))) return false;
      }

      // 11. Bank Filter
      if (filterBank && filterBank.trim()) {
        const targetBank = filterBank.trim().toLowerCase();
        const banks = [
          item.bankName,
          item.contact?.bankName,
          ...(item.bankAccounts || []).map((b: any) => b.bankName),
          ...(item.contact?.bankAccounts || []).map((b: any) => b.bankName),
        ].filter(Boolean).map((b: string) => b.toLowerCase());

        if (!banks.some(b => b.includes(targetBank))) return false;
      }

      // 12. Medical History Filter
      if (filterMedicalHistory && filterMedicalHistory.length > 0) {
        const medItems: string[] = [
          ...(Array.isArray(item.medicalHistory) ? item.medicalHistory : (item.medicalHistory ? [item.medicalHistory] : [])),
          ...(Array.isArray(item.declaredMedicalHistory) ? item.declaredMedicalHistory : (item.declaredMedicalHistory ? [item.declaredMedicalHistory] : [])),
          ...(Array.isArray(item.notDeclaredMedicalHistory) ? item.notDeclaredMedicalHistory : []),
          item.medicalHistoryDetails,
          item.surgeryDetails,
          item.prescriptionDetails,
          item.notes,
        ].filter(Boolean).map((m: any) => String(m).toLowerCase());

        const medStr = medItems.join(' ');
        const matchesMed = filterMedicalHistory.every(m => medStr.includes(m.toLowerCase()));
        if (!matchesMed) return false;
      }

      // 13. Active / Inactive Status Filter (unified across all tabs and filter triggers)
      const filterActiveEffective = filterActiveStatus !== 'ALL'
        ? filterActiveStatus
        : selectedFilters.includes('Active')
          ? 'Active'
          : selectedFilters.includes('Inactive')
            ? 'Inactive'
            : 'ALL';

      if (filterActiveEffective === 'Active' && !isItemActive) return false;
      if (filterActiveEffective === 'Inactive' && isItemActive) return false;

      // 14. Policy Combo Filter (Health No Term / Term No Health)
      if (filterPolicyCombo && filterPolicyCombo !== 'ALL') {
        const contactPolicies = policyMap[item.id] ?? item.policies ?? [];
        const hasHealth = contactPolicies.some((p: any) =>
          (p.plan?.category || p.category || p.plan?.name || '').toLowerCase().includes('health')
        ) || (item.tags || []).some((t: string) => t.toLowerCase() === 'health');

        const hasTerm = contactPolicies.some((p: any) =>
          (p.plan?.category || p.category || p.plan?.name || '').toLowerCase().includes('term')
        ) || (item.tags || []).some((t: string) => t.toLowerCase() === 'term');

        if (filterPolicyCombo === 'HEALTH_NO_TERM' && !(hasHealth && !hasTerm)) return false;
        if (filterPolicyCombo === 'TERM_NO_HEALTH' && !(hasTerm && !hasHealth)) return false;
      }

      // 15. Role Filter
      if (filterRole && filterRole !== 'ALL') {
        const r = (item.role || item.user?.role || 'Contact').toString().trim().toUpperCase();
        if (r !== filterRole.trim().toUpperCase()) return false;
      }

      // 16. Assigned Agent Filter
      if (filterAssignedAgent && filterAssignedAgent !== 'ALL') {
        const empName = getEmployeeName(item.assignedEmployeeId, item.assignedEmployee, item);
        const assignedEmployeeIds = getAssignedEmployeeIds(item);

        if (filterAssignedAgent === 'UNASSIGNED') {
          if (assignedEmployeeIds.length > 0 || empName !== 'Unassigned') return false;
        } else {
          const selectedEmp = employeesList.find((e: any) =>
            e.userId === filterAssignedAgent || e.id === filterAssignedAgent || e.user?.id === filterAssignedAgent
          );
          const selectedEmpName = (
            `${selectedEmp?.firstName || selectedEmp?.user?.firstName || ''} ${selectedEmp?.lastName || selectedEmp?.user?.lastName || ''}`.trim() ||
            selectedEmp?.name ||
            selectedEmp?.email ||
            ''
          ).toLowerCase();

          const matchIds = [filterAssignedAgent, selectedEmp?.id, selectedEmp?.userId, selectedEmp?.user?.id].filter(Boolean);
          const directEmpIds = [
            ...assignedEmployeeIds,
            item.assignedEmployee?.id,
            item.assignedEmployee?.userId,
          ].filter(Boolean);

          const isNameMatch = Boolean(selectedEmpName && empName.toLowerCase() === selectedEmpName);
          const isIdMatch = directEmpIds.some((employeeId: string) => matchIds.includes(employeeId));

          // Strictly require that the contact's assigned employee matches the selected agent
          if (!isNameMatch && !isIdMatch) {
            return false;
          }
        }
      }

      return true;
    });
  }, [
    activeTab, contactsRes, birthdayRes, search, selectedFilters, policyMap, claimMap, dateFrom, dateTo, filterProducts, excludeProduct,
    user?.id, user?.role, employeesList,
    filterFollowUpFrom, filterFollowUpTo, filterGender, filterMaritalStatus, filterAgeRange, filterIncomeRange,
    filterEducation, filterOccupation, filterResidency, filterState, filterCity, filterBank, filterMedicalHistory,
    filterActiveStatus, filterPolicyCombo, filterRole, filterAssignedAgent
  ]);

  // Client-side Sorting Memo
  const sortedAndFilteredData = useMemo(() => {
    if (!sortKey) {
      return [...filteredData].sort((a: any, b: any) => {
        const timeA = new Date(a.createdAt || 0).getTime();
        const timeB = new Date(b.createdAt || 0).getTime();
        return timeB - timeA;
      });
    }
    return sortData(filteredData, sortKey, sortDir as 'asc' | 'desc', (row: any, key: string) => {
      if (key === 'contactId' || key === 'id') {
        const cid = row.contactId || row.id || '';
        const num = parseInt(cid.replace(/\D/g, ''), 10);
        return isNaN(num) ? cid : num;
      }
      if (key === 'name') return [row.firstName || row.contact?.firstName, row.middleName || row.contact?.middleName, row.lastName || row.contact?.lastName].filter(Boolean).join(' ').trim() || row.name || '';
      if (key === 'phone') return row.phone || row.contact?.phone || '';
      if (key === 'role') return row.role || row.user?.role || 'Contact';
      if (key === 'contactStatus' || key === 'status' || key === 'isActive') {
        const isItemActive = row.isActive === true || row.isActive === 'true' || (row.isActive !== false && row.isActive !== 'false' && (row.contactStatus || '').toLowerCase() !== 'inactive');
        return isItemActive ? 'Active' : 'Inactive';
      }
      if (key === 'leadStage' || key === 'leadstage') return row.leadStage || row.stage || '';
      if (key === 'leadStatus' || key === 'leadstatus') return row.leadStatus || '';
      if (key === 'assignedTo' || key === 'assignedEmployee' || key === 'assignedemployee') return getEmployeeName(row.assignedEmployeeId, row.assignedEmployee, row);
      if (key === 'source') return row.source || '';
      if (key === 'email') return row.email || row.contact?.email || '';
      if (key === 'city') return row.city || row.address?.city || row.addresses?.[0]?.city || row.contact?.city || (row.contact as any)?.addresses?.[0]?.city || '';
      if (key === 'product') {
        const p = policyMap[row.id] ?? row.policies ?? [];
        return p.map((x: any) => x.plan?.category || x.plan?.name || x.policyNumber).join(', ');
      }
      if (key === 'renewStatus' || key === 'renewstatus') {
        const policies = policyMap[row.id] ?? row.policies ?? [];
        const active = policies.filter((p: any) => p.status === 'ACTIVE');
        if (active.length === 0) return '';
        const due = active.some((p: any) =>
          p.endDate && new Date(p.endDate) <= new Date(Date.now() + 30 * 86400000)
        );
        return due ? 'Due' : 'OK';
      }
      if (key === 'renewAssigned' || key === 'renewassigned') {
        const policies = policyMap[row.id] ?? row.policies ?? [];
        const active = policies.find((p: any) => p.status === 'ACTIVE' && p.assignedEmployeeId);
        return active ? getEmployeeName(active.assignedEmployeeId) : '';
      }
      if (key === 'claimStatus' || key === 'claimstatus') {
        const claims = claimMap[row.id] ?? row.claims ?? [];
        const active = claims.find((c: any) => ['INTIMATED', 'FILED', 'IN_REVIEW'].includes(c.status));
        return active ? (active.status || '') : '';
      }
      if (key === 'claimAssigned' || key === 'claimassigned') {
        const claims = claimMap[row.id] ?? row.claims ?? [];
        const active = claims.find((c: any) =>
          ['INTIMATED', 'FILED', 'IN_REVIEW'].includes(c.status) && c.assignedEmployeeId
        );
        return active ? getEmployeeName(active.assignedEmployeeId) : '';
      }
      if (key === 'waCampaign' || key === 'wacampaign') {
        const campaigns = row.tags?.filter((t: string) => [
          'Health Awareness',
          'New Year Offer',
          'Pension Plan',
          'Monsoon Safety',
          'Term Insurance Promo',
          'Family Health Package'
        ].includes(t)) || [];
        return campaigns.join(', ');
      }
      if (key === 'dateOfBirth' || key === 'dateofbirth') return row.dateOfBirth || row.contact?.dateOfBirth || '';
      if (key === 'daysUntil' || key === 'daysuntilbirthday') {
        const dob = row.dateOfBirth || row.contact?.dateOfBirth;
        if (!dob) return 999999;
        const dobDate = new Date(dob);
        const today = new Date();
        const nextBday = new Date(today.getFullYear(), dobDate.getMonth(), dobDate.getDate());
        if (nextBday < today) {
          nextBday.setFullYear(today.getFullYear() + 1);
        }
        return differenceInDays(nextBday, today);
      }

      // Attempt to resolve nested paths generically if standard row[key] is undefined
      const parts = key.split('.');
      let val = row;
      for (const part of parts) {
        if (val == null) break;
        val = val[part];
      }
      if (val !== undefined && val !== null) return val;
      return (
        row[key] ??
        row[key.toLowerCase()] ??
        (row.customFields && (row.customFields[key] ?? row.customFields[key.toLowerCase()])) ??
        (row.extraData && (row.extraData[key] ?? row.extraData[key.toLowerCase()]))
      );
    });
  }, [filteredData, sortKey, sortDir, policyMap, claimMap]);

  // Contact Table Columns
  const CONTACT_COLS: Column<any>[] = [
    {
      key: 'name',
      label: 'NAME',
      sortable: true,
      className: 'w-[24%] min-w-[180px]',
      render: r => {
        const fullName = [r.firstName || r.contact?.firstName, r.middleName || r.contact?.middleName, r.lastName || r.contact?.lastName].filter(Boolean).join(' ').trim() || r.name || '—';
        return (
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              if (e.ctrlKey || e.metaKey) {
                const cid = r.contactId || r.id;
                if (cid) {
                  openContactInNewTab(cid);
                  return;
                }
              }
              openLeadView(r);
            }}
            className="text-left font-extrabold text-slate-900 text-sm hover:text-blue-600 transition-colors cursor-pointer"
            title="Open contact (Ctrl+Click to open in new tab)"
          >
            {fullName}
          </button>
        );
      }
    },
    {
      key: 'phone',
      label: 'PHONE',
      sortable: true,
      className: 'w-[15%] min-w-[130px] whitespace-nowrap',
      render: r => {
        const isDep = !!(r.isDependent || r.relationshipType === 'CHILD' || r.dependentNo);
        const resolvedPhone = (r.phone && !r.phone.startsWith('00') && r.phone !== '0000000000' && !String(r.phone).toLowerCase().includes('unknown'))
          ? r.phone
          : (isDep ? (r.dependentNo || r.guardianWhatsapp || r.relatedTo?.[0]?.primaryContact?.phone || '') : '');
        const rawDigits = (resolvedPhone || '').replace(/\D/g, '');
        const displayPhone = (rawDigits.length > 10 && !rawDigits.startsWith('00')) ? rawDigits.slice(-10) : resolvedPhone;
        return <span className="text-slate-700 text-sm font-bold">{displayPhone || '—'}</span>;
      }
    },
    {
      key: 'role',
      label: 'ROLE',
      sortable: true,
      className: 'w-[10%] min-w-[90px] whitespace-nowrap',
      render: r => {
        const role = r.role || r.user?.role || 'Contact';
        const roleColors: Record<string, string> = {
          'Contact': 'bg-blue-50 text-blue-700 border-blue-200/60',
          'Employee': 'bg-purple-50 text-purple-700 border-purple-200/60',
          'ADMIN/OWNER': 'bg-rose-50 text-rose-700 border-rose-200/60',
          'Business Associate': 'bg-amber-50 text-amber-700 border-amber-200/60',
        };
        const cls = roleColors[role] || 'bg-slate-50 text-slate-600 border-slate-200';
        return (
          <span className={clsx(cls, 'inline-flex items-center gap-1 px-2 py-0.5 rounded-lg text-[10px] font-extrabold tracking-wide border')}>
            {role}
          </span>
        );
      }
    },
    {
      key: 'contactStatus',
      label: 'STATUS',
      sortable: true,
      className: 'w-[10%] min-w-[90px] whitespace-nowrap',
      render: r => {
        const isActive = r.isActive !== false;
        return (
          <span className={isActive ? 'badge-green' : 'badge-gray'}>
            {isActive ? 'Active' : 'Inactive'}
          </span>
        );
      }
    },
    {
      key: 'leadStage',
      label: 'LEAD STAGE',
      sortable: true,
      className: 'w-[14%] min-w-[120px] whitespace-nowrap',
      render: r => {
        const stageColors: Record<string, string> = {
          'To Contact': 'bg-slate-100 text-slate-700 border-slate-200',
          'Contacted': 'bg-blue-50 text-blue-700 border-blue-200/60',
          'Proposal Sent': 'bg-purple-50 text-purple-700 border-purple-200/60',
          'Login in Progress': 'bg-amber-50 text-amber-700 border-amber-200/60',
          'Payment Done': 'bg-emerald-50 text-emerald-700 border-emerald-200/60',
        };
        const cls = stageColors[r.leadStage] || 'bg-slate-50 text-slate-500 border-slate-200';
        return (
          <span className={clsx(cls, 'inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-xs font-extrabold uppercase tracking-wider border shadow-2xs')}>
            <span className="w-1.5 h-1.5 rounded-full bg-current" />
            {r.leadStage || '—'}
          </span>
        );
      }
    },
    {
      key: 'leadStatus',
      label: 'LEAD STATUS',
      sortable: true,
      className: 'w-[14%] min-w-[120px] whitespace-nowrap',
      render: r => {
        const statusColors: Record<string, string> = {
          'Interested': 'bg-teal-50 text-teal-700 border-teal-200/60',
          'Not Interested': 'bg-rose-50 text-rose-700 border-rose-200/60',
          'Hot': 'bg-orange-50 text-orange-700 border-orange-200/60 font-black animate-pulse',
          'Very Hot': 'bg-red-50 text-red-700 border-red-200/60 font-black animate-bounce',
        };
        const cls = statusColors[r.leadStatus] || 'bg-slate-50 text-slate-500 border-slate-200';
        return (
          <span className={clsx(cls, 'inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-xs font-extrabold uppercase tracking-wider border shadow-2xs')}>
            <span className="w-1.5 h-1.5 rounded-full bg-current" />
            {r.leadStatus || '—'}
          </span>
        );
      }
    },
    {
      key: 'assignedTo',
      label: 'ASSIGNED EMPLOYEE',
      sortable: true,
      className: 'w-[25%] min-w-[180px]',
      render: r => {
        const assignedEmployeeIds = getAssignedEmployeeIds(r);
        const assignedEmployeeNames = assignedEmployeeIds
          .map((employeeId: string) => getEmployeeName(employeeId, undefined, r))
          .filter((name: string) => name && name !== 'Unassigned');
        const empName = assignedEmployeeNames.join(', ') || getEmployeeName(r.assignedEmployeeId, r.assignedEmployee, r);
        if (empName === 'Unassigned') {
          return (
            <div className="flex flex-wrap items-center gap-1.5 flex-wrap">
              <span className="inline-flex flex-wrap items-center gap-1 px-2 py-0.5 rounded-md text-xs font-bold bg-amber-50 text-amber-700 border border-amber-200">
                Unassigned
              </span>
              {user?.role === 'EMPLOYEE' && (
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    handlePickContact(r);
                  }}
                  className="px-2.5 py-1 text-xs font-extrabold bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white rounded-lg cursor-pointer shadow-xs transition-all hover:scale-105"
                  title="Assign this contact to yourself"
                >
                  Pick Contact
                </button>
              )}
            </div>
          );
        }
        return (
          <span className="text-slate-700 text-sm font-bold">
            {empName}
            {user?.role === 'OWNER' && assignedEmployeeIds.length > 0 && (
              <span className="ml-1 text-[10px] font-extrabold text-blue-700">
                ({assignedEmployeeIds.length} {assignedEmployeeIds.length === 1 ? 'employee' : 'employees'})
              </span>
            )}
          </span>
        );
      }
    },
    {
      key: 'source',
      label: 'SOURCE',
      sortable: true,
      className: 'w-[12%] min-w-[100px] whitespace-nowrap',
      render: r => <span className="text-slate-600 text-sm font-bold capitalize bg-slate-100 px-2 py-0.5 rounded-md border border-slate-200/60">{r.source || '—'}</span>
    },
    {
      key: 'actions',
      label: 'ACTIONS',
      className: 'w-[16%] min-w-[130px] whitespace-nowrap',
      render: r => {
        const isEmployee = authUser?.role === 'EMPLOYEE';
        const showPickButton = isEmployee && !r.assignedEmployeeId && getAssignedEmployeeIds(r).length === 0;
        return (
          <div className="flex gap-1.5 justify-start items-center" onClick={e => e.stopPropagation()}>
            {showPickButton && (
              <button
                onClick={() => handlePickContact(r.id)}
                className="px-2.5 py-1.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-extrabold text-xs shadow-xs hover:from-blue-700 hover:to-indigo-700 transition-all hover:scale-105 cursor-pointer flex flex-wrap items-center gap-1 shrink-0"
                title="Pick and assign this contact to yourself"
              >
                <UserCheck size={13} />
                Pick Contact
              </button>
            )}
            {(() => {
              const rawEff = (r.phone && !r.phone.startsWith('00') && r.phone !== '0000000000' && !r.phone.toLowerCase().includes('unknown'))
                ? r.phone
                : ((r.isDependent || r.relationshipType === 'CHILD' || r.dependentNo) ? (r.dependentNo || r.guardianWhatsapp || r.relatedTo?.[0]?.primaryContact?.phone || '') : '');
              const effDigits = (rawEff || '').replace(/\D/g, '');
              const effectivePhone = (effDigits.length > 10 && !effDigits.startsWith('00')) ? effDigits.slice(-10) : effDigits;
              if (!effectivePhone || effectivePhone.startsWith('00') || effectivePhone === '0000000000') return null;
              return (
                <>
                  <a
                    href={`https://wa.me/91${effectivePhone}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold flex items-center justify-center cursor-pointer shadow-md shadow-emerald-500/20 hover:shadow-lg hover:scale-105 transition-all"
                    title="WhatsApp"
                  >
                    <MessageCircle size={14} />
                  </a>
                  <a
                    href={`tel:${effectivePhone}`}
                    className="p-2 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold flex items-center justify-center cursor-pointer shadow-md shadow-blue-500/20 hover:shadow-lg hover:scale-105 transition-all"
                    title="Call"
                  >
                    <Phone size={14} />
                  </a>
                </>
              );
            })()}
            {canEditContacts && (
              <button
                onClick={() => openEdit(r)}
                className="p-2 rounded-xl bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-700 hover:to-violet-700 text-white font-bold flex items-center justify-center cursor-pointer shadow-md shadow-purple-500/20 hover:shadow-lg hover:scale-105 transition-all"
                title="Edit Contact"
              >
                <Pencil size={14} />
              </button>
            )}
          </div>
        );
      }
    }
  ];

  // Customer Columns
  const CUSTOMER_COLS: Column<any>[] = [
    {
      key: 'name',
      label: 'NAME',
      sortable: true,
      className: 'min-w-[180px]',
      render: r => {
        const fullName = [r.firstName || r.contact?.firstName, r.middleName || r.contact?.middleName, r.lastName || r.contact?.lastName].filter(Boolean).join(' ').trim() || r.name || '—';
        return (
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              if (e.ctrlKey || e.metaKey) {
                const cid = r.contactId || r.id;
                if (cid) {
                  openContactInNewTab(cid);
                  return;
                }
              }
              openLeadView(r);
            }}
            className="text-left font-extrabold text-slate-900 text-sm hover:text-blue-600 transition-colors cursor-pointer"
            title="Open contact (Ctrl+Click to open in new tab)"
          >
            {fullName}
          </button>
        );
      }
    },
    {
      key: 'phone',
      label: 'PHONE',
      sortable: true,
      className: 'min-w-[130px] whitespace-nowrap',
      render: r => {
        const isDep = !!(r.isDependent || r.relationshipType === 'CHILD' || r.dependentNo);
        const resolvedPhone = (r.phone && !r.phone.startsWith('00') && r.phone !== '0000000000' && !String(r.phone).toLowerCase().includes('unknown'))
          ? r.phone
          : (isDep ? (r.dependentNo || r.guardianWhatsapp || r.relatedTo?.[0]?.primaryContact?.phone || '') : '');
        const rawDigits = (resolvedPhone || '').replace(/\D/g, '');
        const displayPhone = (rawDigits.length > 10 && !rawDigits.startsWith('00')) ? rawDigits.slice(-10) : resolvedPhone;
        return <span className="text-slate-700 text-sm font-bold">{displayPhone || '—'}</span>;
      }
    },
    {
      key: 'product',
      label: 'PRODUCT',
      sortable: true,
      className: 'min-w-[120px]',
      render: r => {
        const policies = policyMap[r.id] ?? [];
        if (policies.length === 0) return <span className="text-slate-400 text-sm">—</span>;
        return (
          <div className="flex gap-1 flex-wrap">
            {policies.map((p: any) => {
              const label = p.plan?.category
                ? p.plan.category.charAt(0).toUpperCase() + p.plan.category.slice(1).toLowerCase()
                : (p.plan?.name || p.policyNumber || 'Policy');
              return (
                <button
                  key={p.id}
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelectedPolicyModalId(p.id);
                  }}
                  className="px-2 py-0.5 rounded-lg bg-blue-50 text-blue-700 hover:bg-blue-600 hover:text-white border border-blue-200/60 text-xs font-extrabold shadow-2xs transition-all cursor-pointer"
                  title={`Click to view policy details ${p.policyNumber ? `(${p.policyNumber})` : ''}`}
                >
                  {label}
                </button>
              );
            })}
          </div>
        );
      }
    },
    {
      key: 'renewStatus',
      label: 'RENEW STATUS',
      sortable: true,
      className: 'min-w-[110px] whitespace-nowrap',
      render: r => {
        const policies = policyMap[r.id] ?? [];
        const active = policies.filter((p: any) => p.status === 'ACTIVE');
        if (active.length === 0) return <span className="text-slate-400 text-sm">—</span>;
        const due = active.some((p: any) =>
          p.endDate && new Date(p.endDate) <= new Date(Date.now() + 30 * 86400000)
        );
        return due ? (
          <span className="inline-flex flex-wrap items-center gap-1 px-2.5 py-0.5 rounded-xl bg-gradient-to-r from-orange-500 to-amber-500 text-white font-extrabold text-xs uppercase tracking-wider shadow-xs shadow-orange-500/20 border border-orange-400">
            <Flame size={11} /> Due
          </span>
        ) : (
          <span className="inline-flex flex-wrap items-center gap-1 px-2.5 py-0.5 rounded-xl bg-emerald-50 text-emerald-700 border border-emerald-200/60 font-extrabold text-xs uppercase tracking-wider shadow-2xs">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" /> OK
          </span>
        );
      }
    },
    {
      key: 'renewAssigned',
      label: 'RENEW ASSIGNED',
      sortable: true,
      className: 'min-w-[140px]',
      render: r => {
        const policies = policyMap[r.id] ?? [];
        const active = policies.find((p: any) => p.status === 'ACTIVE' && p.assignedEmployeeId);
        return <span className="text-blue-600 text-sm font-bold">{active ? getEmployeeName(active.assignedEmployeeId) : '—'}</span>;
      }
    },
    {
      key: 'claimStatus',
      label: 'CLAIM STATUS',
      sortable: true,
      className: 'min-w-[110px] whitespace-nowrap',
      render: r => {
        const claims = claimMap[r.id] ?? [];
        if (claims.length === 0) return <span className="text-slate-400 text-sm">—</span>;
        const active = claims.find((c: any) => ['INTIMATED', 'FILED', 'IN_REVIEW'].includes(c.status));
        if (active) {
          const CLAIM_LABELS: Record<string, string> = {
            INTIMATED: 'Intimated', FILED: 'Filed', IN_REVIEW: 'In Review',
          };
          return (
            <span className="inline-flex flex-wrap items-center gap-1 px-2.5 py-0.5 rounded-xl bg-amber-50 text-amber-700 border border-amber-200/60 font-extrabold text-xs uppercase tracking-wider shadow-2xs">
              <Star size={11} className="text-amber-500" /> {CLAIM_LABELS[active.status] ?? active.status}
            </span>
          );
        }
        return <span className="text-slate-400 text-sm">—</span>;
      }
    },
    {
      key: 'claimAssigned',
      label: 'CLAIM ASSIGNED',
      sortable: true,
      className: 'min-w-[140px]',
      render: r => {
        const claims = claimMap[r.id] ?? [];
        const active = claims.find((c: any) =>
          ['INTIMATED', 'FILED', 'IN_REVIEW'].includes(c.status) && c.assignedEmployeeId
        );
        return <span className="text-slate-600 text-sm font-bold">{active ? getEmployeeName(active.assignedEmployeeId) : '—'}</span>;
      }
    },
    {
      key: 'waCampaign',
      label: 'WA CAMPAIGN',
      sortable: true,
      className: 'min-w-[130px]',
      render: r => {
        const campaigns = r.tags?.filter((t: string) => [
          'Health Awareness',
          'New Year Offer',
          'Pension Plan',
          'Monsoon Safety',
          'Term Insurance Promo',
          'Family Health Package'
        ].includes(t)) || [];
        return <span className="text-slate-600 text-sm font-semibold">{campaigns.join(', ') || '—'}</span>;
      }
    },
    {
      key: 'actions',
      label: 'ACTIONS',
      className: 'min-w-[120px] whitespace-nowrap',
      render: r => {
        const isDep = !!(r.isDependent || r.relationshipType === 'CHILD' || r.dependentNo);
        const resolvedPhone = (r.phone && !r.phone.startsWith('00') && r.phone !== '0000000000' && !String(r.phone).toLowerCase().includes('unknown'))
          ? r.phone
          : (isDep ? (r.dependentNo || r.guardianWhatsapp || r.relatedTo?.[0]?.primaryContact?.phone || '') : '');
        const pDigits = (resolvedPhone || '').replace(/\D/g, '');
        const cleanPhone = (pDigits.length > 10 && !pDigits.startsWith('00')) ? pDigits.slice(-10) : pDigits;
        return (
          <div className="flex gap-1.5 justify-start items-center" onClick={e => e.stopPropagation()}>
            {cleanPhone && !cleanPhone.startsWith('00') && cleanPhone !== '0000000000' && (
              <>
                <a
                  href={`https://wa.me/91${cleanPhone}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold flex items-center justify-center cursor-pointer shadow-md shadow-emerald-500/20 hover:shadow-lg hover:scale-105 transition-all"
                  title="WhatsApp"
                >
                  <MessageCircle size={14} />
                </a>
                <a
                  href={`tel:${cleanPhone}`}
                  className="p-2 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold flex items-center justify-center cursor-pointer shadow-md shadow-blue-500/20 hover:shadow-lg hover:scale-105 transition-all"
                  title="Call"
                >
                  <Phone size={14} />
                </a>
              </>
            )}
          {canEditContacts && (
            <button
              onClick={() => openEdit(r)}
              className="p-2 rounded-xl bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-700 hover:to-violet-700 text-white font-bold flex items-center justify-center cursor-pointer shadow-md shadow-purple-500/20 hover:shadow-lg hover:scale-105 transition-all"
              title="Edit Contact"
            >
              <Pencil size={14} />
            </button>
          )}
        </div>
      );
    }
  }
];

  // Birthday Columns
  const BIRTHDAY_COLS: Column<any>[] = [
    {
      key: 'name',
      label: 'NAME',
      sortable: true,
      className: 'w-[28%] min-w-[180px]',
      render: r => {
        const fullName = [r.firstName || r.contact?.firstName, r.middleName || r.contact?.middleName, r.lastName || r.contact?.lastName].filter(Boolean).join(' ').trim() || r.name || '—';
        return (
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              if (e.ctrlKey || e.metaKey) {
                const cid = r.contactId || r.id;
                if (cid) {
                  openContactInNewTab(cid);
                  return;
                }
              }
              openLeadView(r);
            }}
            className="text-left font-extrabold text-slate-900 text-sm hover:text-blue-600 transition-colors cursor-pointer"
            title="Open contact (Ctrl+Click to open in new tab)"
          >
            {fullName}
          </button>
        );
      }
    },
    {
      key: 'phone',
      label: 'PHONE',
      sortable: true,
      className: 'w-[18%] min-w-[130px] whitespace-nowrap',
      render: r => {
        const isDep = !!(r.isDependent || r.relationshipType === 'CHILD' || r.dependentNo);
        const resolvedPhone = (r.phone && !r.phone.startsWith('00') && r.phone !== '0000000000' && !String(r.phone).toLowerCase().includes('unknown'))
          ? r.phone
          : (isDep ? (r.dependentNo || r.guardianWhatsapp || r.relatedTo?.[0]?.primaryContact?.phone || '') : '');
        const rawDigits = (resolvedPhone || '').replace(/\D/g, '');
        const displayPhone = (rawDigits.length > 10 && !rawDigits.startsWith('00')) ? rawDigits.slice(-10) : resolvedPhone;
        return <span className="text-slate-700 text-sm font-bold">{displayPhone || '—'}</span>;
      }
    },
    {
      key: 'dateOfBirth',
      label: 'DATE OF BIRTH',
      sortable: true,
      className: 'w-[18%] min-w-[130px] whitespace-nowrap',
      render: r => <span className="text-slate-600 text-sm font-semibold">{r.dateOfBirth ? format(new Date(r.dateOfBirth), 'dd/MM/yyyy') : '—'}</span>
    },
    {
      key: 'daysUntil',
      label: 'DAYS UNTIL BIRTHDAY',
      sortable: true,
      className: 'w-[20%] min-w-[140px] whitespace-nowrap',
      render: r => {
        if (!r.dateOfBirth) return '—';
        const dob = new Date(r.dateOfBirth);
        const today = new Date();
        const nextBday = new Date(today.getFullYear(), dob.getMonth(), dob.getDate());
        if (nextBday < today) {
          nextBday.setFullYear(today.getFullYear() + 1);
        }
        const diff = differenceInDays(nextBday, today);
        return (
          <span className={clsx(
            "px-3 py-1 rounded-xl text-[10px] font-black uppercase tracking-wider border shadow-2xs",
            diff === 0 ? "bg-gradient-to-r from-rose-600 to-red-600 text-white border-rose-600 shadow-rose-500/25 animate-pulse" :
              diff <= 7 ? "bg-amber-50 text-amber-700 border-amber-200/80" : "bg-blue-50 text-blue-700 border-blue-200/80"
          )}>
            {diff === 0 ? 'Today! 🎂' : `${diff} days`}
          </span>
        );
      }
    },
    {
      key: 'actions',
      label: 'ACTIONS',
      className: 'w-[16%] min-w-[120px] whitespace-nowrap',
      render: r => {
        const isDep = !!(r.isDependent || r.relationshipType === 'CHILD' || r.dependentNo);
        const resolvedPhone = (r.phone && !r.phone.startsWith('00') && r.phone !== '0000000000' && !String(r.phone).toLowerCase().includes('unknown'))
          ? r.phone
          : (isDep ? (r.dependentNo || r.guardianWhatsapp || r.relatedTo?.[0]?.primaryContact?.phone || '') : '');
        const pDigits = (resolvedPhone || '').replace(/\D/g, '');
        const cleanPhone = (pDigits.length > 10 && !pDigits.startsWith('00')) ? pDigits.slice(-10) : pDigits;
        return (
          <div className="flex gap-1.5 justify-start items-center" onClick={e => e.stopPropagation()}>
            {cleanPhone && !cleanPhone.startsWith('00') && cleanPhone !== '0000000000' ? (
              <>
                <a
                  href={`https://wa.me/91${cleanPhone}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold flex items-center justify-center cursor-pointer shadow-md shadow-emerald-500/20 hover:shadow-lg hover:scale-105 transition-all"
                  title="WhatsApp"
                >
                  <MessageCircle size={14} />
                </a>
                <a
                  href={`tel:${cleanPhone}`}
                  className="p-2 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold flex items-center justify-center cursor-pointer shadow-md shadow-blue-500/20 hover:shadow-lg hover:scale-105 transition-all"
                  title="Call"
                >
                  <Phone size={14} />
                </a>
              </>
            ) : null}
          </div>
        );
      }
    }
  ];

  const handleImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setImportFormatOpen(false);
    const toastId = toast.loading('Importing contacts…');
    try {
      const workbook = XLSX.read(await file.arrayBuffer(), { type: 'array', cellDates: false });
      const firstSheetName = workbook.SheetNames[0];
      if (!firstSheetName) throw new Error('The selected file does not contain a worksheet.');
      const worksheet = workbook.Sheets[firstSheetName];
      const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(worksheet, {
        defval: '',
        raw: false,
        dateNF: 'yyyy-mm-dd',
      });
      if (rows.length === 0) throw new Error('The selected worksheet has no contact rows.');

      const contacts = rows.map((row, index) => ({
        ...mapContactImportRow(row),
        rowNumber: index + 2,
      }));
      const maxBatchBytes = 60 * 1024;
      const batches: typeof contacts[] = [];
      const skipped: string[] = [];
      let currentBatch: typeof contacts = [];
      for (const contact of contacts) {
        const contactSize = new TextEncoder().encode(JSON.stringify([contact])).length;
        if (contactSize > maxBatchBytes) {
          skipped.push(`Row ${contact.rowNumber}: contact data exceeds the import size limit`);
          continue;
        }
        const candidate = [...currentBatch, contact];
        if (currentBatch.length > 0 && new TextEncoder().encode(JSON.stringify(candidate)).length > maxBatchBytes) {
          batches.push(currentBatch);
          currentBatch = [contact];
        } else {
          currentBatch = candidate;
        }
      }
      if (currentBatch.length > 0) batches.push(currentBatch);

      let created = 0;
      const warnings: string[] = [];
      for (const batch of batches) {
        try {
          const result = await contactsService.bulkImport({ contacts: batch });
          created += Number(result.data?.created || 0);
          skipped.push(...(result.data?.skipped || []));
          warnings.push(...(result.data?.warnings || []));
        } catch (err: any) {
          const rowsInBatch = batch.map(contact => contact.rowNumber);
          warnings.push(`Rows ${rowsInBatch[0]}-${rowsInBatch[rowsInBatch.length - 1]}: ${err?.response?.data?.message || err?.message || 'Import request failed'}`);
        }
      }
      toast.success(
        `Imported ${created} contact(s); skipped ${skipped.length} row(s); ${warnings.length} related/import issue(s).`,
        { id: toastId },
      );
      if (warnings.length || skipped.length) {
        const details = [...skipped, ...warnings].slice(0, 3).join('; ');
        const remaining = skipped.length + warnings.length - Math.min(3, skipped.length + warnings.length);
        toast.error(`${details}${remaining > 0 ? `; and ${remaining} more issue(s)` : ''}`, { duration: 9000 });
      }
      qc.invalidateQueries({ queryKey: ['contacts'] });
      qc.invalidateQueries({ queryKey: ['leads'] });
      qc.invalidateQueries({ queryKey: ['policies'] });
      qc.invalidateQueries({ queryKey: ['claims'] });
    } catch (err: any) {
      toast.error(err?.response?.data?.message || err?.message || 'Failed to import contacts', { id: toastId });
    } finally {
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const activeCols = useMemo(() => {
    if (activeTab === 'birthdays') {
      return BIRTHDAY_COLS.filter(c => c.key === 'actions' || isColVisibleInSettings(c.label || String(c.key)));
    }
    if (activeTab === 'customers') {
      return CUSTOMER_COLS.filter(c => c.key === 'actions' || isColVisibleInSettings(c.label || String(c.key)));
    }

    const norm = (s: string) => (s || '').replace(/[^a-zA-Z0-9]/g, '').toLowerCase();

    const KNOWN_COLS: Record<string, Column<any>> = {
      contactid: {
        key: 'contactId',
        label: 'CONTACT ID',
        sortable: true,
        className: 'w-[10%] min-w-[100px] whitespace-nowrap',
        render: r => <span className="text-slate-500 font-mono text-xs">{r.contactId || r.id || '—'}</span>
      },
      name: CONTACT_COLS.find(c => c.key === 'name')!,
      phone: CONTACT_COLS.find(c => c.key === 'phone')!,
      role: CONTACT_COLS.find(c => c.key === 'role')!,
      status: CONTACT_COLS.find(c => c.key === 'contactStatus')!,
      leadstage: CONTACT_COLS.find(c => c.key === 'leadStage')!,
      leadstatus: CONTACT_COLS.find(c => c.key === 'leadStatus')!,
      assignedemployee: CONTACT_COLS.find(c => c.key === 'assignedTo')!,
      source: CONTACT_COLS.find(c => c.key === 'source')!,
      product: CUSTOMER_COLS.find(c => c.key === 'product')!,
      renewstatus: CUSTOMER_COLS.find(c => c.key === 'renewStatus')!,
      renewassigned: CUSTOMER_COLS.find(c => c.key === 'renewAssigned')!,
      claimstatus: CUSTOMER_COLS.find(c => c.key === 'claimStatus')!,
      claimassigned: CUSTOMER_COLS.find(c => c.key === 'claimAssigned')!,
      wacampaign: CUSTOMER_COLS.find(c => c.key === 'waCampaign')!,
      dateofbirth: BIRTHDAY_COLS.find(c => c.key === 'dateOfBirth')!,
      daysuntilbirthday: BIRTHDAY_COLS.find(c => c.key === 'daysUntil')!,
      email: {
        key: 'email',
        label: 'EMAIL',
        sortable: true,
        className: 'w-[16%] min-w-[150px]',
        render: r => <span className="text-slate-600 text-sm">{r.email || '—'}</span>
      },
      city: {
        key: 'city',
        label: 'CITY',
        sortable: true,
        className: 'w-[12%] min-w-[110px]',
        render: r => <span className="text-slate-600 text-sm font-semibold">{r.city || (r as any).addresses?.[0]?.city || (r as any).address?.city || '—'}</span>
      },
      state: {
        key: 'state',
        label: 'STATE',
        sortable: true,
        className: 'w-[12%] min-w-[110px]',
        render: r => <span className="text-slate-600 text-sm font-semibold">{r.state || (r as any).addresses?.[0]?.state || (r as any).address?.state || '—'}</span>
      },
      pincode: {
        key: 'pincode',
        label: 'PINCODE',
        sortable: true,
        className: 'w-[10%] min-w-[100px]',
        render: r => <span className="text-slate-600 text-sm font-semibold">{r.pincode || (r as any).addresses?.[0]?.pincode || (r as any).address?.pincode || '—'}</span>
      },
      occupation: {
        key: 'occupation',
        label: 'OCCUPATION',
        sortable: true,
        className: 'w-[14%] min-w-[120px]',
        render: r => <span className="text-slate-600 text-sm font-semibold">{r.occupation || (r as any).occupations?.[0]?.type || (r as any).occupationType || '—'}</span>
      },
      designation: {
        key: 'designation',
        label: 'DESIGNATION',
        sortable: true,
        className: 'w-[14%] min-w-[120px]',
        render: r => <span className="text-slate-600 text-sm font-semibold">{r.designation || (r as any).occupations?.[0]?.designation || '—'}</span>
      },
      education: {
        key: 'education',
        label: 'EDUCATION',
        sortable: true,
        className: 'w-[12%] min-w-[110px]',
        render: r => <span className="text-slate-600 text-sm font-semibold">{r.education || '—'}</span>
      },
      annualincome: {
        key: 'annualIncome',
        label: 'ANNUAL INCOME',
        sortable: true,
        className: 'w-[14%] min-w-[120px]',
        render: r => <span className="text-slate-700 text-sm font-bold">{r.annualIncome ? `₹${Number(r.annualIncome).toLocaleString('en-IN')}` : '—'}</span>
      },
      alternatephone: {
        key: 'alternatePhone',
        label: 'ALTERNATE PHONE',
        sortable: true,
        className: 'w-[14%] min-w-[120px]',
        render: r => <span className="text-slate-700 text-sm font-semibold">{r.alternatePhone || '—'}</span>
      },
      isdependent: {
        key: 'isDependent',
        label: 'IS DEPENDENT?',
        sortable: true,
        className: 'w-[10%] min-w-[90px]',
        render: r => <span className="text-slate-700 text-sm font-semibold">{r.isDependent ? 'Yes' : 'No'}</span>
      },
    };

    const cols: Column<any>[] = [];
    allContactColumnsConfig.forEach(colName => {
      const n = norm(colName);
      if (n === 'actions') return;
      if (!isColVisibleInSettings(colName)) return;

      if (KNOWN_COLS[n]) {
        cols.push(KNOWN_COLS[n]);
      } else {
        cols.push({
          key: colName,
          label: colName.toUpperCase(),
          sortable: true,
          className: 'min-w-[120px]',
          render: (r: any) => {
            const val = r[colName] ?? r[colName.toLowerCase()] ?? (r.customFields && r.customFields[colName]) ?? (r.extraData && r.extraData[colName]) ?? '—';
            return <span className="text-slate-700 text-sm font-medium">{typeof val === 'object' ? JSON.stringify(val) : String(val)}</span>;
          }
        });
      }
    });

    const actionsCol = CONTACT_COLS.find(c => c.key === 'actions');
    if (actionsCol) cols.push(actionsCol);

    return cols;
  }, [activeTab, allContactColumnsConfig, isColVisibleInSettings, CONTACT_COLS, CUSTOMER_COLS, BIRTHDAY_COLS]);

  return (
    <div className="space-y-4 font-sans text-slate-800 text-sm sm:text-base">
      {/* Hidden file input for CSV import */}
      <input
        ref={fileInputRef}
        type="file"
        accept=".csv,text/csv,.xlsx,.xls,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel"
        className="hidden"
        onChange={handleImport}
      />

      {/* Floating Right Action Panel (Import CSV & Add Buttons) */}
      <div className="fixed right-5 top-1/2 -translate-y-1/2 z-40 flex flex-col gap-3 bg-white/90 backdrop-blur-xl p-2 rounded-2xl shadow-2xl border border-slate-200/80 animate-fadeIn">
        {/* Import CSV */}
        <button
          type="button"
          onClick={() => setImportFormatOpen(true)}
          className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 hover:from-emerald-700 hover:to-teal-600 text-white flex items-center justify-center transition-all hover:scale-105 shadow-md shadow-emerald-500/25 cursor-pointer group relative"
        >
          <Upload size={18} strokeWidth={2.2} />
          <span className="absolute right-full mr-3 px-3 py-1.5 rounded-xl bg-slate-900/90 backdrop-blur-md text-white text-[11px] font-bold whitespace-nowrap opacity-0 group-hover:opacity-100 transition-all pointer-events-none shadow-xl border border-slate-800">
            Import Contact CSV
          </span>
        </button>

        {/* Add Contact */}
        <button
          type="button"
          onClick={openCreate}
          className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white flex items-center justify-center transition-all hover:scale-105 shadow-lg shadow-blue-500/30 cursor-pointer group relative"
        >
          <UserPlus size={18} strokeWidth={2.2} />
          <span className="absolute right-full mr-3 px-3 py-1.5 rounded-xl bg-slate-900/90 backdrop-blur-md text-white text-[11px] font-bold whitespace-nowrap opacity-0 group-hover:opacity-100 transition-all pointer-events-none shadow-xl border border-slate-800">
            Add Contact
          </span>
        </button>
      </div>

      {/* Main Control Hub Card */}
      <div className="bg-white rounded-2xl border border-slate-200/80 p-4 shadow-sm">
        {/* Single Row Layout (Policy & Claims UI Style) */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">

          {/* Left Side: Search Bar ONLY */}
          <div className="flex flex-wrap items-center gap-2 w-full lg:w-auto">
            <div className="page-search-wrapper">
              <Search className="page-search-icon" />
              <input
                type="text"
                className="page-search-input"
                placeholder="Search contact name, phone, email..."
                value={search}
                onChange={e => { setSearch(e.target.value); setPage(1); }}
              />
            </div>
          </div>

          {/* Right Side: Active/Inactive Badges, All Products Filter, Date Range Selector & Column Settings */}
          <div className="flex flex-wrap items-center gap-2.5 flex-wrap justify-end">
            {/* Active / Inactive Status Badges */}
            <button
              type="button"
              onClick={() => {
                const next = (filterActiveStatus === 'Active' || selectedFilters.includes('Active')) ? 'ALL' : 'Active';
                setFilterActiveStatus(next);
                setSelectedFilters(next === 'Active' ? ['Active'] : []);
                setPage(1);
              }}
              className={clsx(
                'inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer border shadow-2xs',
                (filterActiveStatus === 'Active' || selectedFilters.includes('Active'))
                  ? 'bg-emerald-600 text-white border-emerald-600 shadow-emerald-500/20'
                  : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
              )}
            >
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" /> Active
            </button>
            <button
              type="button"
              onClick={() => {
                const next = (filterActiveStatus === 'Inactive' || selectedFilters.includes('Inactive')) ? 'ALL' : 'Inactive';
                setFilterActiveStatus(next);
                setSelectedFilters(next === 'Inactive' ? ['Inactive'] : []);
                setPage(1);
              }}
              className={clsx(
                'inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer border shadow-2xs',
                (filterActiveStatus === 'Inactive' || selectedFilters.includes('Inactive'))
                  ? 'bg-rose-600 text-white border-rose-600 shadow-rose-500/20'
                  : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
              )}
            >
              <span className="w-2 h-2 rounded-full bg-rose-400" /> Inactive
            </button>

            {/* Product Category Multi-Select Dropdown */}
            <div
              className="relative"
              onMouseEnter={() => setShowProductDropdown(true)}
              onMouseLeave={() => setShowProductDropdown(false)}
            >
              <button
                type="button"
                onClick={() => setShowProductDropdown(prev => !prev)}
                className={clsx(
                  "flex items-center gap-2 px-3 py-1.5 rounded-xl border border-slate-200/90 text-xs font-extrabold cursor-pointer transition-all shadow-2xs select-none",
                  filterProducts.length > 0
                    ? "bg-blue-50/90 border-blue-300 text-blue-700"
                    : "bg-slate-50 text-slate-700 hover:bg-slate-100"
                )}
              >
                <Shield size={14} className="text-blue-600 shrink-0" />
                <span>
                  {filterProducts.length === 0
                    ? "All Products"
                    : filterProducts.length === 1
                      ? `Product: ${filterProducts[0]}`
                      : `${filterProducts.length} Products Selected`}
                </span>
                <ChevronDown size={14} className={clsx("text-slate-400 transition-transform duration-150", showProductDropdown && "rotate-180")} />
              </button>

              {/* Dropdown Menu Panel */}
              {showProductDropdown && (
                <div className="absolute right-0 top-full z-50 pt-2">
                <div className="w-56 bg-white border border-slate-200/90 rounded-2xl shadow-2xl p-3 animate-fadeIn text-xs space-y-1.5">
                  <div className="flex items-center justify-between border-b border-slate-100 pb-2 mb-1">
                    <span className="font-extrabold text-slate-400 uppercase tracking-wider text-[10px]">Filter By Product</span>
                    {filterProducts.length > 0 && (
                      <button
                        type="button"
                        onClick={() => { setFilterProducts([]); setPage(1); }}
                        className="text-[10px] font-bold text-blue-600 hover:underline cursor-pointer"
                      >
                        Clear All
                      </button>
                    )}
                  </div>

                  {/* All Products Checkbox */}
                  <label
                    className="flex flex-wrap items-center gap-2.5 p-1.5 rounded-lg hover:bg-slate-50 cursor-pointer font-extrabold text-slate-700 select-none"
                  >
                    <input
                      type="checkbox"
                      checked={filterProducts.length === 0}
                      onChange={() => { setFilterProducts([]); setExcludeProduct(false); setPage(1); }}
                      className="rounded border-slate-300 text-blue-600 focus:ring-blue-500 h-3.5 w-3.5 cursor-pointer"
                    />
                    <span>All Products</span>
                  </label>

                  <div className="border-t border-slate-100 pt-1 space-y-1">
                    {[
                      { id: 'HEALTH', label: 'Health' },
                      { id: 'LIFE', label: 'Life' },
                      { id: 'MOTOR', label: 'Motor' },
                      { id: 'GENERAL', label: 'General' },
                      { id: 'MF', label: 'Mutual Funds (MF)' },
                      { id: 'ACCIDENT', label: 'Accident' },
                      { id: 'OTHER', label: 'Other' },
                    ].map(prod => {
                      const isChecked = filterProducts.includes(prod.id);
                      return (
                        <label
                          key={prod.id}
                          className="flex flex-wrap items-center gap-2.5 p-1.5 rounded-lg hover:bg-slate-50 cursor-pointer font-bold text-slate-700 select-none"
                        >
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={() => {
                              setFilterProducts(prev =>
                                prev.includes(prod.id)
                                  ? prev.filter(p => p !== prod.id)
                                  : [...prev, prod.id]
                              );
                              setExcludeProduct(false);
                              setPage(1);
                            }}
                            className="rounded border-slate-300 text-blue-600 focus:ring-blue-500 h-3.5 w-3.5 cursor-pointer"
                          />
                          <span>{prod.label}</span>
                        </label>
                      );
                    })}
                  </div>
                </div>
                </div>
              )}
            </div>

            {filterProducts.length > 0 && (
              <button
                type="button"
                onClick={() => { setExcludeProduct(!excludeProduct); setPage(1); }}
                className={clsx(
                  'inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-extrabold transition-all cursor-pointer border shadow-2xs',
                  excludeProduct
                    ? 'bg-gradient-to-r from-rose-600 to-red-600 text-white border-rose-600 shadow-rose-500/25'
                    : 'bg-rose-50 text-rose-600 border-rose-200 hover:bg-rose-100'
                )}
                title={excludeProduct ? `Showing contacts who HAVEN'T purchased selected products` : `Click to show who HAVEN'T purchased selected products`}
              >
                {excludeProduct ? `❌ Without Selected Products` : `🚫 Exclude / Not Purchased`}
              </button>
            )}

            {/* Date Range Selector */}
            <div className="flex flex-nowrap items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 shadow-2xs">
              <Calendar size={14} className="text-slate-400 shrink-0" />
              <DatePicker
                value={dateFrom}
                onDateChange={val => { setDateFrom(val); setPage(1); }}
                className="bg-transparent border-0 outline-none text-[11px] font-semibold text-slate-700 w-24 focus:ring-0 p-0 cursor-pointer"
                title="From Date"
              />
              <span className="text-slate-300 font-bold">-</span>
              <DatePicker
                value={dateTo}
                onDateChange={val => { setDateTo(val); setPage(1); }}
                className="bg-transparent border-0 outline-none text-[11px] font-semibold text-slate-700 w-24 focus:ring-0 p-0 cursor-pointer"
                title="To Date"
              />
              {(dateFrom || dateTo) && (
                <button
                  type="button"
                  onClick={() => { setDateFrom(''); setDateTo(''); setPage(1); }}
                  className="text-slate-400 hover:text-red-500 font-bold text-xs ml-0.5 cursor-pointer"
                  title="Clear Date Range"
                >
                  ✕
                </button>
              )}
            </div>

            {/* Column Picker Dropdown */}
            <div className="relative" ref={colPickerRef}>
              <button
                onClick={() => setShowColPicker(!showColPicker)}
                className={clsx(
                  "p-2 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-500 hover:text-slate-700 cursor-pointer shadow-2xs transition-all",
                  showColPicker && "bg-blue-50 border-blue-200 text-blue-600"
                )}
                title="Toggle Columns"
              >
                <Settings size={14} />
              </button>
              {showColPicker && (
                <div className="absolute right-0 mt-2 w-64 max-h-80 overflow-y-auto bg-white border border-slate-200/90 rounded-2xl shadow-2xl p-3 z-50 text-xs space-y-2 animate-fadeIn">
                  <div className="pb-1.5 border-b border-slate-100">
                    <p className="font-extrabold text-slate-400 uppercase tracking-wider text-[10px]">Show Columns</p>
                  </div>
                  {allContactColumnsConfig
                    .filter(c => (c || '').trim().toLowerCase() !== 'actions')
                    .map(colName => {
                      const isVisible = isColVisibleInSettings(colName);
                      return (
                        <label key={colName} className="flex items-center gap-2 cursor-pointer font-bold text-slate-700 hover:text-blue-600 transition-colors">
                          <input
                            type="checkbox"
                            checked={isVisible}
                            onChange={() => {
                              toggleColInSettings(colName, isVisible);
                            }}
                            className="rounded border-slate-300 text-blue-600 focus:ring-blue-500 h-3.5 w-3.5 cursor-pointer"
                          />
                          <span>{colName}</span>
                        </label>
                      );
                    })}
                </div>
              )}
            </div>

            {/* Advanced Filters Toggle Button */}
            <button
              onClick={() => setShowAdvancedFilters(!showAdvancedFilters)}
              className={clsx(
                "p-2 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-500 hover:text-slate-700 cursor-pointer shadow-2xs transition-all flex items-center gap-1.5 text-xs font-bold bg-white",
                showAdvancedFilters && "bg-blue-50 border-blue-200 text-blue-600"
              )}
              title="Advanced Filters"
            >
              <Filter size={14} className={showAdvancedFilters || activeContactsFilterCount > 0 ? "text-blue-600" : "text-slate-500"} />
              <span className="hidden sm:inline">Filters</span>
              {activeContactsFilterCount > 0 && (
                <span className="px-1.5 py-0.5 text-[10px] bg-blue-600 text-white rounded-full font-black leading-none">
                  {activeContactsFilterCount}
                </span>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Active Filter Badges Bar */}
      {activeContactsFilterCount > 0 && (
        <div className="flex flex-wrap items-center gap-1.5 bg-blue-50/60 p-2.5 rounded-2xl border border-blue-100/90 shadow-2xs animate-fadeIn">
          <span className="text-[11px] font-extrabold text-blue-800 mr-1 flex items-center gap-1">
            <Filter size={13} className="text-blue-600" /> Active Filters ({activeContactsFilterCount}):
          </span>

          {(filterFollowUpFrom || filterFollowUpTo) && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-white text-blue-900 text-xs font-bold rounded-xl border border-blue-200 shadow-2xs">
              Follow-up: {filterFollowUpFrom || 'Start'} to {filterFollowUpTo || 'End'}
              <span className="cursor-pointer hover:text-red-500 font-bold ml-1" onClick={() => { setFilterFollowUpFrom(''); setFilterFollowUpTo(''); }}>×</span>
            </span>
          )}
          {filterGender !== 'ALL' && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-white text-blue-900 text-xs font-bold rounded-xl border border-blue-200 shadow-2xs">
              Gender: {filterGender}
              <span className="cursor-pointer hover:text-red-500 font-bold ml-1" onClick={() => setFilterGender('ALL')}>×</span>
            </span>
          )}
          {filterMaritalStatus !== 'ALL' && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-white text-blue-900 text-xs font-bold rounded-xl border border-blue-200 shadow-2xs">
              Marital: {filterMaritalStatus}
              <span className="cursor-pointer hover:text-red-500 font-bold ml-1" onClick={() => setFilterMaritalStatus('ALL')}>×</span>
            </span>
          )}
          {filterAgeRange !== 'ALL' && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-white text-blue-900 text-xs font-bold rounded-xl border border-blue-200 shadow-2xs">
              Age: {filterAgeRange.replace('_', '-').replace('-PLUS', '+')}
              <span className="cursor-pointer hover:text-red-500 font-bold ml-1" onClick={() => setFilterAgeRange('ALL')}>×</span>
            </span>
          )}
          {filterIncomeRange !== 'ALL' && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-white text-blue-900 text-xs font-bold rounded-xl border border-blue-200 shadow-2xs">
              Income: {filterIncomeRange.replace('_', '-').replace('-PLUS', '+')}
              <span className="cursor-pointer hover:text-red-500 font-bold ml-1" onClick={() => setFilterIncomeRange('ALL')}>×</span>
            </span>
          )}
          {filterEducation !== 'ALL' && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-white text-blue-900 text-xs font-bold rounded-xl border border-blue-200 shadow-2xs">
              Education: {filterEducation}
              <span className="cursor-pointer hover:text-red-500 font-bold ml-1" onClick={() => setFilterEducation('ALL')}>×</span>
            </span>
          )}
          {filterOccupation !== 'ALL' && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-white text-blue-900 text-xs font-bold rounded-xl border border-blue-200 shadow-2xs">
              Occupation: {filterOccupation}
              <span className="cursor-pointer hover:text-red-500 font-bold ml-1" onClick={() => setFilterOccupation('ALL')}>×</span>
            </span>
          )}
          {filterResidency !== 'ALL' && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-white text-blue-900 text-xs font-bold rounded-xl border border-blue-200 shadow-2xs">
              Residency: {filterResidency}
              <span className="cursor-pointer hover:text-red-500 font-bold ml-1" onClick={() => setFilterResidency('ALL')}>×</span>
            </span>
          )}
          {filterState && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-white text-blue-900 text-xs font-bold rounded-xl border border-blue-200 shadow-2xs">
              State: {filterState}
              <span className="cursor-pointer hover:text-red-500 font-bold ml-1" onClick={() => setFilterState('')}>×</span>
            </span>
          )}
          {filterCity && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-white text-blue-900 text-xs font-bold rounded-xl border border-blue-200 shadow-2xs">
              City: {filterCity}
              <span className="cursor-pointer hover:text-red-500 font-bold ml-1" onClick={() => setFilterCity('')}>×</span>
            </span>
          )}
          {filterBank && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-white text-blue-900 text-xs font-bold rounded-xl border border-blue-200 shadow-2xs">
              Bank: {filterBank}
              <span className="cursor-pointer hover:text-red-500 font-bold ml-1" onClick={() => setFilterBank('')}>×</span>
            </span>
          )}
          {filterMedicalHistory.length > 0 && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-white text-blue-900 text-xs font-bold rounded-xl border border-blue-200 shadow-2xs">
              Medical: {filterMedicalHistory.join(', ')}
              <span className="cursor-pointer hover:text-red-500 font-bold ml-1" onClick={() => setFilterMedicalHistory([])}>×</span>
            </span>
          )}
          {(filterActiveStatus !== 'ALL' || selectedFilters.includes('Active') || selectedFilters.includes('Inactive')) && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-white text-blue-900 text-xs font-bold rounded-xl border border-blue-200 shadow-2xs">
              Status: {filterActiveStatus !== 'ALL' ? filterActiveStatus : selectedFilters.includes('Active') ? 'Active' : 'Inactive'}
              <span className="cursor-pointer hover:text-red-500 font-bold ml-1" onClick={() => { setFilterActiveStatus('ALL'); setSelectedFilters(prev => prev.filter(f => f !== 'Active' && f !== 'Inactive')); }}>×</span>
            </span>
          )}
          {filterPolicyCombo !== 'ALL' && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-white text-blue-900 text-xs font-bold rounded-xl border border-blue-200 shadow-2xs">
              Combo: {filterPolicyCombo === 'HEALTH_NO_TERM' ? 'Health (No Term)' : 'Term (No Health)'}
              <span className="cursor-pointer hover:text-red-500 font-bold ml-1" onClick={() => setFilterPolicyCombo('ALL')}>×</span>
            </span>
          )}
          {filterRole !== 'ALL' && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-white text-blue-900 text-xs font-bold rounded-xl border border-blue-200 shadow-2xs">
              Role: {filterRole}
              <span className="cursor-pointer hover:text-red-500 font-bold ml-1" onClick={() => setFilterRole('ALL')}>×</span>
            </span>
          )}
          {filterAssignedAgent !== 'ALL' && filterAssignedAgent !== '' && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-white text-blue-900 text-xs font-bold rounded-xl border border-blue-200 shadow-2xs">
              Agent: {(() => {
                if (filterAssignedAgent === 'UNASSIGNED') return 'Unassigned';
                const emp = employeesList.find((e: any) => e.userId === filterAssignedAgent || e.id === filterAssignedAgent || e.user?.id === filterAssignedAgent);
                return emp ? `${emp.firstName || emp.user?.firstName || ''} ${emp.lastName || emp.user?.lastName || ''}`.trim() || emp.email : filterAssignedAgent;
              })()}
              <span className="cursor-pointer hover:text-red-500 font-bold ml-1" onClick={() => setFilterAssignedAgent('ALL')}>×</span>
            </span>
          )}
          {filterProducts.length > 0 && excludeProduct && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-rose-50 text-rose-800 text-xs font-bold rounded-xl border border-rose-200 shadow-2xs">
              Not Purchased: {filterProducts.join(', ')}
              <span className="cursor-pointer hover:text-red-600 font-bold ml-1" onClick={() => { setFilterProducts([]); setExcludeProduct(false); }}>×</span>
            </span>
          )}

          <button
            type="button"
            onClick={resetAllContactsFilters}
            className="text-[11px] font-extrabold text-red-600 hover:text-red-800 hover:underline cursor-pointer ml-auto px-2 py-0.5 rounded-lg bg-red-50 hover:bg-red-100 transition-colors"
          >
            Clear All
          </button>
        </div>
      )}

      {/* Advanced Filters Panel */}
      {showAdvancedFilters && (
        <div className="card bg-gray-50/50 p-5 rounded-2xl border border-slate-200 shadow-sm mt-2 mb-4 animate-fadeIn">
          <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-200/70">
            <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
              <Filter size={16} className="text-blue-600" />
              Advanced Filters
            </h3>
            {activeContactsFilterCount > 0 && (
              <span className="text-xs font-extrabold text-blue-600 bg-blue-50 px-2.5 py-1 rounded-lg border border-blue-100">
                {activeContactsFilterCount} {activeContactsFilterCount === 1 ? 'Filter' : 'Filters'} Active
              </span>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-6 gap-y-4 text-xs">

            {/* 1. Next Followup Date Range */}
            <div>
              <label className="label text-[11px] font-bold text-slate-600">Next Follow-up Date</label>
              <div className="flex gap-2 items-center mt-1">
                <DatePicker className="input text-xs w-full shadow-2xs" value={filterFollowUpFrom} onDateChange={val => setFilterFollowUpFrom(val)} title="From" />
                <span className="text-gray-400 font-bold">-</span>
                <DatePicker className="input text-xs w-full shadow-2xs" value={filterFollowUpTo} onDateChange={val => setFilterFollowUpTo(val)} title="To" />
              </div>
            </div>

            {/* 2. Gender */}
            <div>
              <label className="label text-[11px] font-bold text-slate-600">Gender</label>
              <select className="input text-xs w-full bg-white shadow-2xs mt-1" value={filterGender} onChange={e => setFilterGender(e.target.value)}>
                <option value="ALL">All Genders</option>
                <option value="MALE">Male</option>
                <option value="FEMALE">Female</option>
                <option value="OTHER">Other</option>
              </select>
            </div>

            {/* 3. Married Status */}
            <div>
              <label className="label text-[11px] font-bold text-slate-600">Marital Status</label>
              <select className="input text-xs w-full bg-white shadow-2xs mt-1" value={filterMaritalStatus} onChange={e => setFilterMaritalStatus(e.target.value)}>
                <option value="ALL">All Statuses</option>
                <option value="SINGLE">Single</option>
                <option value="MARRIED">Married</option>
                <option value="DIVORCED">Divorced</option>
                <option value="WIDOWED">Widowed</option>
              </select>
            </div>

            {/* 4. Age (Slabwise) */}
            <div>
              <label className="label text-[11px] font-bold text-slate-600">Age Group (Slabwise)</label>
              <select className="input text-xs w-full bg-white shadow-2xs mt-1" value={filterAgeRange} onChange={e => setFilterAgeRange(e.target.value)}>
                <option value="ALL">All Ages</option>
                <option value="0_18">0 to 18 Years</option>
                <option value="19_25">19 to 25 Years</option>
                <option value="26_30">26 to 30 Years</option>
                <option value="31_35">31 to 35 Years</option>
                <option value="36_40">36 to 40 Years</option>
                <option value="41_50">41 to 50 Years</option>
                <option value="51_60">51 to 60 Years</option>
                <option value="61_75">61 to 75 Years</option>
                <option value="75_PLUS">75+ Years</option>
              </select>
            </div>

            {/* 5. Annual Income (Slabwise) */}
            <div>
              <label className="label text-[11px] font-bold text-slate-600">Annual Income (Slabwise)</label>
              <select className="input text-xs w-full bg-white shadow-2xs mt-1" value={filterIncomeRange} onChange={e => setFilterIncomeRange(e.target.value)}>
                <option value="ALL">All Income Slabs</option>
                <option value="0_2.5L">0 to ₹2.5 Lakhs</option>
                <option value="2.5L_5L">₹2.5L to ₹5 Lakhs</option>
                <option value="5L_10L">₹5L to ₹10 Lakhs</option>
                <option value="10L_25L">₹10L to ₹25 Lakhs</option>
                <option value="25L_50L">₹25L to ₹50 Lakhs</option>
                <option value="50L_PLUS">Above ₹50 Lakhs</option>
              </select>
            </div>

            {/* 6. Education */}
            <div>
              <label className="label text-[11px] font-bold text-slate-600">Education</label>
              <select className="input text-xs w-full bg-white shadow-2xs mt-1" value={filterEducation} onChange={e => setFilterEducation(e.target.value)}>
                <option value="ALL">All Education Levels</option>
                {EDUCATION_OPTIONS.map(edu => (
                  <option key={edu} value={edu}>{edu}</option>
                ))}
              </select>
            </div>

            {/* 7. Occupation Type */}
            <div>
              <label className="label text-[11px] font-bold text-slate-600">Occupation Type</label>
              <select className="input text-xs w-full bg-white shadow-2xs mt-1" value={filterOccupation} onChange={e => setFilterOccupation(e.target.value)}>
                <option value="ALL">All Occupations</option>
                {OCCUPATION_TYPE_OPTIONS.map(occ => (
                  <option key={occ} value={occ}>{occ}</option>
                ))}
              </select>
            </div>

            {/* 8. Residency Status (Indian / NRI / OCI) */}
            <div>
              <label className="label text-[11px] font-bold text-slate-600">Residency Status</label>
              <select className="input text-xs w-full bg-white shadow-2xs mt-1" value={filterResidency} onChange={e => setFilterResidency(e.target.value)}>
                <option value="ALL">All Residency Types</option>
                <option value="Indian">Indian Resident</option>
                <option value="NRI">NRI (Non-Resident Indian)</option>
                <option value="OCI">OCI (Overseas Citizen)</option>
              </select>
            </div>

            {/* 9. State */}
            <div>
              <label className="label text-[11px] font-bold text-slate-600">State</label>
              <input
                type="text"
                placeholder="e.g. Maharashtra, Delhi..."
                className="input text-xs w-full bg-white shadow-2xs mt-1"
                value={filterState}
                onChange={e => setFilterState(e.target.value)}
              />
            </div>

            {/* 10. City */}
            <div>
              <label className="label text-[11px] font-bold text-slate-600">City</label>
              <input
                type="text"
                placeholder="e.g. Mumbai, Pune..."
                className="input text-xs w-full bg-white shadow-2xs mt-1"
                value={filterCity}
                onChange={e => setFilterCity(e.target.value)}
              />
            </div>

            {/* 11. Bank */}
            <div>
              <label className="label text-[11px] font-bold text-slate-600">Bank Name</label>
              <input
                type="text"
                placeholder="e.g. HDFC, ICICI, SBI..."
                className="input text-xs w-full bg-white shadow-2xs mt-1"
                value={filterBank}
                onChange={e => setFilterBank(e.target.value)}
              />
            </div>

            {/* 12. Active Status */}
            <div>
              <label className="label text-[11px] font-bold text-slate-600">Contact Active Status</label>
              <select
                className="input text-xs w-full bg-white shadow-2xs mt-1"
                value={filterActiveStatus !== 'ALL' ? filterActiveStatus : selectedFilters.includes('Active') ? 'Active' : selectedFilters.includes('Inactive') ? 'Inactive' : 'ALL'}
                onChange={e => {
                  const val = e.target.value;
                  setFilterActiveStatus(val);
                  if (val === 'Active') setSelectedFilters(['Active']);
                  else if (val === 'Inactive') setSelectedFilters(['Inactive']);
                  else setSelectedFilters(prev => prev.filter(f => f !== 'Active' && f !== 'Inactive'));
                }}
              >
                <option value="ALL">All Contacts (Active & Inactive)</option>
                <option value="Active">Active Only</option>
                <option value="Inactive">Inactive Only</option>
              </select>
            </div>

            {/* 13. Policy Combination Segment (Health / Term) */}
            <div>
              <label className="label text-[11px] font-bold text-slate-600">Policy Combination Segment</label>
              <select className="input text-xs w-full bg-white shadow-2xs mt-1" value={filterPolicyCombo} onChange={e => setFilterPolicyCombo(e.target.value)}>
                <option value="ALL">All Clients</option>
                <option value="HEALTH_NO_TERM">Health but No Term</option>
                <option value="TERM_NO_HEALTH">Term but No Health</option>
              </select>
            </div>

            {/* 14. Role */}
            <div>
              <label className="label text-[11px] font-bold text-slate-600">Role</label>
              <select className="input text-xs w-full bg-white shadow-2xs mt-1" value={filterRole} onChange={e => setFilterRole(e.target.value)}>
                <option value="ALL">All Roles</option>
                <option value="Contact">Contact</option>
                <option value="Employee">Employee</option>
                <option value="ADMIN/OWNER">ADMIN/OWNER</option>
                <option value="Business Associate">Business Associate</option>
                <option value="SUPERADMIN">Super Admin</option>
                <option value="ADMIN">Admin</option>
                <option value="CUSTOMER">Customer</option>
                <option value="AGENT">Agent</option>
              </select>
            </div>

            {/* 15. Assigned Agent */}
            <div>
              <label className="label text-[11px] font-bold text-slate-600">Assigned Agent</label>
              <select
                value={filterAssignedAgent}
                onChange={e => setFilterAssignedAgent(e.target.value)}
                className="input text-xs w-full bg-white shadow-2xs mt-1 font-semibold"
              >
                <option value="ALL">All Agents</option>
                <option value="UNASSIGNED">Unassigned Contacts</option>
                {employeesList.map((emp: any) => {
                  const empUserId = emp.userId || emp.user?.id || emp.id;
                  const empName = `${emp.firstName || emp.user?.firstName || ''} ${emp.lastName || emp.user?.lastName || ''}`.trim() || emp.email || 'Employee';
                  return (
                    <option key={emp.id || empUserId} value={empUserId}>
                      {empName}
                    </option>
                  );
                })}
              </select>
            </div>

            {/* 16. Product Not Purchased (Exclude Filter) */}
            <div>
              <label className="label text-[11px] font-bold text-slate-600">Product Not Purchased</label>
              <select
                className="input text-xs w-full bg-white shadow-2xs mt-1"
                value={filterProducts.length > 0 && excludeProduct ? filterProducts[0] : 'NONE'}
                onChange={e => {
                  if (e.target.value === 'NONE') {
                    if (excludeProduct) {
                      setFilterProducts([]);
                      setExcludeProduct(false);
                    }
                  } else {
                    setFilterProducts([e.target.value]);
                    setExcludeProduct(true);
                  }
                }}
              >
                <option value="NONE">None (Select Category...)</option>
                <option value="HEALTH">Health (Not Purchased)</option>
                <option value="LIFE">Life (Not Purchased)</option>
                <option value="MF">Mutual Funds / MF (Not Purchased)</option>
                <option value="ACCIDENT">Accident (Not Purchased)</option>
                <option value="OTHER">Other Products (Not Purchased)</option>
              </select>
            </div>

            {/* 17. Medical History Multi-Select */}
            <div className="sm:col-span-2">
              <MultiSelectBox
                label="Medical History (BP, Sugar, Thyroid, etc.)"
                selectedValues={filterMedicalHistory}
                onChange={setFilterMedicalHistory}
                badgeColor="blue"
                placeholder="Select Medical Conditions to filter..."
              />
            </div>

          </div>

          {/* Card Actions */}
          <div className="flex flex-wrap justify-between items-center gap-3 mt-6 pt-4 border-t border-slate-200/70">
            {/* Export Buttons */}
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-bold text-slate-500 mr-1">Export Data:</span>
              <button
                type="button"
                onClick={exportContactsToExcel}
                className="px-3.5 py-1.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 cursor-pointer shadow-2xs transition-all flex items-center gap-1.5 text-xs font-bold bg-white"
                title="Export to Excel"
              >
                <FileText size={14} className="text-emerald-600" />
                <span>Export Excel</span>
              </button>
              <button
                type="button"
                onClick={exportContactsToPdf}
                className="px-3.5 py-1.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 cursor-pointer shadow-2xs transition-all flex items-center gap-1.5 text-xs font-bold bg-white"
                title="Export to PDF"
              >
                <FileText size={14} className="text-red-500" />
                <span>Export PDF</span>
              </button>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={resetAllContactsFilters}
                className="px-6 py-2 text-xs font-bold text-slate-600 bg-white border border-slate-300 rounded-xl hover:bg-slate-50 transition-colors shadow-2xs cursor-pointer"
              >
                Reset Filters
              </button>
              <button
                type="button"
                onClick={() => setShowAdvancedFilters(false)}
                className="px-6 py-2 text-xs font-bold text-white bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 rounded-xl transition-all shadow-md shadow-blue-500/20 cursor-pointer"
              >
                Apply Filters {activeContactsFilterCount > 0 ? `(${activeContactsFilterCount})` : ''}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Data Table */}
      <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
        <DataTable
          columns={activeCols}
          data={sortedAndFilteredData.slice((page - 1) * 20, page * 20)}
          total={sortedAndFilteredData.length}
          page={page}
          pageSize={20}
          scrollAreaHeight="420px"
          showPagination
          horizontalScroll={activeCols.length > 7}
          loading={activeTab === 'birthdays' ? birthdayLoading : contactsLoading}
          rowKey={r => r.id}
          onPageChange={setPage}
          sortKey={sortKey}
          sortDir={sortDir as 'asc' | 'desc'}
          onSort={(key, dir) => {
            setSortKey(key);
            setSortDir(dir);
          }}
          onRowClick={r => {
            if (activeTab === 'customers' || activeTab === 'contacts') {
              openLeadView(r);
            } else {
              const cid = r.contactId || r.id;
              setSelectedDetailId(cid);
              setDetailModalOpen(true);
            }
          }}
        />
      </div>



      {/* Delete Confirm */}
      <Modal open={!!deleteTarget} onClose={() => setDeleteTarget(null)} title="Delete Contact" size="sm">
        <p className="text-sm text-gray-600 mb-4">Delete <strong>{deleteTarget?.firstName} {deleteTarget?.lastName}</strong>? This cannot be undone.</p>
        <div className="flex flex-wrap justify-end gap-2">
          <button className="btn-secondary" onClick={() => setDeleteTarget(null)}>Cancel</button>
          <button className="btn-danger" onClick={confirmDelete} disabled={deleteContact.isPending}>
            {deleteContact.isPending ? 'Deleting…' : 'Delete'}
          </button>
        </div>
      </Modal>

      {/* Log Interaction Modal */}
      <Modal
        open={interactionModalOpen}
        onClose={() => { setInteractionModalOpen(false); setInteractionTarget(null); }}
        title={`Update Contact & Log Interaction — ${interactionTarget?.firstName ?? ''} ${interactionTarget?.lastName ?? ''}`}
        size="lg"
      >
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-stretch">
          {/* Left Column: Form Fields */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (!interactionTarget) return;
              logInteractionMutation.mutate({
                id: interactionTarget.id,
                body: {
                  interactionType: interactionFields.interactionType,
                  leadStage: interactionFields.leadStage,
                  leadStatus: interactionFields.leadStatus,
                  leadType: interactionFields.leadType,
                  nextFollowUp: interactionFields.nextFollowUp || undefined,
                  notes: interactionFields.notes || undefined,
                }
              });
            }}
            className="space-y-4 flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div>
                <label className="label">Interaction Type</label>
                <div className="flex gap-4 mt-1">
                  {['Call', 'WhatsApp', 'Meeting'].map((t) => (
                    <label key={t} className="inline-flex flex-wrap items-center gap-1.5 text-xs text-slate-700 cursor-pointer">
                      <input
                        type="radio"
                        name="interactionType"
                        value={t}
                        checked={interactionFields.interactionType === t}
                        onChange={(e) => setInteractionFields(prev => ({ ...prev, interactionType: e.target.value }))}
                        className="accent-blue-600 h-3.5 w-3.5"
                      />
                      {t}
                    </label>
                  ))}
                </div>
              </div>

              <div>
                <label className="label">Lead Stage</label>
                <select
                  value={interactionFields.leadStage}
                  onChange={(e) => setInteractionFields(prev => ({ ...prev, leadStage: e.target.value }))}
                  className="input text-xs"
                >
                  <option value="To Contact">To Contact</option>
                  <option value="Contacted">Contacted</option>
                  <option value="Proposal Sent">Proposal Sent</option>
                  <option value="Login in Progress">Login in Progress</option>
                  <option value="Payment Done">Payment Done</option>
                </select>
              </div>

              <div>
                <label className="label">Lead Status</label>
                <select
                  value={interactionFields.leadStatus}
                  onChange={(e) => setInteractionFields(prev => ({ ...prev, leadStatus: e.target.value }))}
                  className="input text-xs"
                >
                  <option value="Interested">Interested</option>
                  <option value="Not Interested">Not Interested</option>
                  <option value="Hot">Hot</option>
                  <option value="Very Hot">Very Hot</option>
                </select>
              </div>

              <div>
                <label className="label">Lead Type</label>
                <select
                  value={interactionFields.leadType}
                  onChange={(e) => setInteractionFields(prev => ({ ...prev, leadType: e.target.value }))}
                  className="input text-xs"
                >
                  <option value="New">New</option>
                  <option value="Renewal">Renewal</option>
                  <option value="Payment Due">Payment Due</option>
                </select>
              </div>

              <div>
                <label className="label">Next Follow-up Date</label>
                <DatePicker
                  value={interactionFields.nextFollowUp}
                  onChange={val => setInteractionFields(prev => ({ ...prev, nextFollowUp: val }))}
                  className="input text-xs"
                />
              </div>

              <div>
                <label className="label">Consultation Comment</label>
                <textarea
                  value={interactionFields.notes}
                  onChange={(e) => setInteractionFields(prev => ({ ...prev, notes: e.target.value }))}
                  rows={3}
                  placeholder="Type a new comment..."
                  className="input text-xs font-sans"
                />
              </div>
            </div>

            <div className="flex flex-wrap justify-end gap-2 pt-3 border-t border-slate-100 mt-2">
              <button
                type="button"
                className="btn-secondary"
                onClick={() => { setInteractionModalOpen(false); setInteractionTarget(null); }}
              >
                Cancel
              </button>
              <button
                type="submit"
                className="btn-primary"
                disabled={logInteractionMutation.isPending}
              >
                {logInteractionMutation.isPending ? 'Saving...' : 'Save'}
              </button>
            </div>
          </form>

          {/* Right Column: Timelines and Comments History */}
          <div className="border-t lg:border-t-0 lg:border-l border-slate-100 pt-4 lg:pt-0 lg:pl-6 flex flex-col">
            <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">Consultation Comments Timeline</h3>

            <div className="flex-1 max-h-[420px] overflow-y-auto pr-1 space-y-3 custom-scrollbar">
              {activityLoading ? (
                <div className="py-12 flex justify-center items-center text-slate-400 text-xs">
                  <div className="animate-spin rounded-full h-4 w-4 border-2 border-slate-300 border-t-blue-600 mr-2" />
                  Loading timeline history...
                </div>
              ) : (activityRes?.data ?? []).length === 0 ? (
                <div className="py-16 text-center text-xs text-slate-400 italic">
                  No interactions logged yet.
                </div>
              ) : (
                (activityRes?.data ?? []).map((act: any, idx: number) => {
                  const creatorName = act.user ? `${act.user.firstName} ${act.user.lastName}` : 'System';
                  return (
                    <div key={act.id || idx} className="bg-slate-50/50 hover:bg-slate-50 border border-slate-100 rounded-xl p-3 space-y-1.5 transition-all text-xs">
                      <div className="flex items-center justify-between text-[10px] text-slate-400 font-semibold">
                        <span>{format(new Date(act.createdAt), 'dd/MMM/yyyy hh:mm a')}</span>
                        <span className="text-slate-600 bg-slate-100 px-1.5 py-0.5 rounded-md">{creatorName}</span>
                      </div>
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span className={clsx(
                          'px-1.5 py-0.25 rounded text-[9px] font-bold uppercase tracking-wider',
                          act.action === 'WHATSAPP' ? 'bg-green-100 text-green-700' :
                            act.action === 'MEETING' ? 'bg-purple-100 text-purple-700' :
                              'bg-blue-100 text-blue-700'
                        )}>
                          {act.action}
                        </span>
                      </div>
                      <p className="text-slate-600 whitespace-pre-wrap leading-relaxed mt-1 font-medium">{act.description}</p>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      </Modal>

      <Modal
        open={leadModalOpen}
        onClose={handleCancelLeadModal}
        closeOnEscapeAndBackdrop={false}
        title={
          activeLeadTab === 'Policy'
            ? (editContactId ? (isViewMode ? "View Policy" : "Edit Policy") : "Add Policy")
            : editContactId
              ? (isViewMode
                  ? (activeTab === 'customers' ? "View Customer Profile" : "View Contact Profile")
                  : (activeTab === 'customers' ? "Edit Customer Profile" : "Edit Contact Profile"))
              : (activeTab === 'customers' ? "Add New Customer" : "Add New Contact")
        }
        subtitle={
          activeLeadTab === 'Policy'
            ? "Add or update policy details, company, plan name, and coverage."
            : editContactId
              ? (isViewMode
                  ? (activeTab === 'customers' ? "View customer profile, family details, and policies." : "View contact profile, family details, and address.")
                  : (activeTab === 'customers' ? "Update customer profile, family details, and policies." : "Update contact profile, family details, and address."))
              : (activeTab === 'customers' ? "Manage customer profile, family details, and policies." : "Manage contact profile, family details, and address.")
        }
        size="2xl"
        actions={
          <div className="flex items-center gap-2 mr-1">
            {contactNavHistory.length > 0 && (
              <button
                type="button"
                className="px-3 sm:px-4 py-1.5 sm:py-2 text-[10px] sm:text-xs font-bold text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-xl cursor-pointer transition-all flex items-center gap-1.5 shadow-2xs hover:scale-105"
                onClick={handleCancelLeadModal}
                title={contactNavHistory[contactNavHistory.length - 1]?.contactName ? `Back to ${contactNavHistory[contactNavHistory.length - 1].contactName}` : 'Cancel'}
              >
                <ArrowLeft size={13} />
                <span>Cancel</span>
              </button>
            )}
            {(parentNavInfo || parentNavInfoRef.current) && contactNavHistory.length === 0 && (
              <button
                type="button"
                className="px-3 sm:px-4 py-1.5 sm:py-2 text-[10px] sm:text-xs font-bold text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-xl cursor-pointer transition-all flex items-center gap-1.5 shadow-2xs hover:scale-105"
                onClick={handleCancelLeadModal}
                title="Close and return to previous contact (Family tab)"
              >
                <ArrowLeft size={13} />
                <span>Back</span>
              </button>
            )}
            {!isViewMode && (
              <button
                type="button"
                className="px-3 sm:px-4 py-1.5 sm:py-2 text-[10px] sm:text-xs font-bold text-slate-600 hover:text-slate-800 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-xl cursor-pointer transition-all shadow-2xs hover:scale-105"
                onClick={() => {
                  if (editContactId) {
                    setIsViewMode(true);
                  } else {
                    closeLeadModal();
                  }
                }}
              >
                Cancel
              </button>
            )}
            {isViewMode ? (
              <button
                type="button"
                className="px-3 sm:px-5 py-1.5 sm:py-2 text-[10px] sm:text-xs font-extrabold bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white rounded-xl cursor-pointer shadow-md shadow-blue-500/20 transition-all hover:scale-105 flex items-center gap-1.5"
                onClick={() => setIsViewMode(false)}
              >
                <Pencil size={12} />
                <span>Edit</span>
              </button>
            ) : (
              <button
                type="button"
                className="px-3 sm:px-5 py-1.5 sm:py-2 text-[10px] sm:text-xs font-extrabold bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white rounded-xl cursor-pointer shadow-md shadow-blue-500/20 transition-all hover:scale-105"
                onClick={(e) => handleLeadSubmit(e, false)}
              >
                {activeLeadTab === 'Policy'
                  ? (editContactId ? 'Update Policy' : 'Add Policy')
                  : (editContactId ? 'Update Profile' : 'Save')}
              </button>
            )}
          </div>
        }
      >
        <form className="space-y-3">

          {/* Modal sub-navigation tabs */}
          <div className="flex bg-slate-200/60 p-1.5 rounded-2xl mt-0 mb-3 gap-2 border border-slate-200/80 overflow-x-auto shadow-2xs">
            {['Product Interest', 'Personal', 'Family', 'Policy', 'Claims', 'Documents', 'History'].map(tab => (
              <button
                key={tab}
                type="button"
                onClick={() => setActiveLeadTab(tab)}
                className={clsx(
                  'px-5 py-2.5 rounded-xl text-xs font-extrabold tracking-wide transition-all cursor-pointer whitespace-nowrap',
                  activeLeadTab === tab
                    ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-md shadow-blue-500/25 scale-[1.02]'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-white/80'
                )}
              >
                {tab}
              </button>
            ))}
          </div>

          {/* Tab contents */}
          <div className="h-[430px] overflow-y-auto pr-2 custom-scrollbar">
            <fieldset disabled={isViewMode && ['Product Interest', 'Personal', 'Family'].includes(activeLeadTab)} className="min-w-0 border-0 p-0 m-0 w-full">
            {activeLeadTab === 'Product Interest' && (
              <div className="space-y-3 animate-fadeIn pb-2">

                {/* Cards List */}
                {productInterests.length === 0 && (
                  <div className="flex flex-col items-center justify-center py-10 text-slate-400 text-xs gap-2">
                    <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-blue-50 to-indigo-50 border border-blue-100 flex items-center justify-center mb-1">
                      <Shield size={24} className="text-blue-300" />
                    </div>
                    <p className="font-semibold text-slate-500">No product interests added yet.</p>
                    <p className="text-[11px] text-slate-400">Click "+ Add Product Interest" below to get started.</p>
                  </div>
                )}

                {productInterests.map((card, idx) => {
                  const isExisting = card.id.length === 24 || /^[0-9a-fA-F]{24}$/.test(card.id);
                  const displayName = card.interestedIn.length > 0
                    ? card.interestedIn.map(p => p === 'Other' && card.otherProduct ? card.otherProduct : p).join(', ')
                    : 'New Product Interest';

                  const PRODUCT_COLORS: Record<string, string> = {
                    Health: 'from-emerald-500 to-teal-600',
                    Life: 'from-blue-500 to-indigo-600',
                    Term: 'from-violet-500 to-purple-600',
                    'Accident Policy': 'from-orange-500 to-amber-600',
                    Motor: 'from-rose-500 to-pink-600',
                    'Mutual Funds': 'from-cyan-500 to-sky-600',
                    Porting: 'from-yellow-500 to-orange-500',
                    Other: 'from-slate-500 to-gray-600',
                  };
                  const firstProduct = card.interestedIn[0] || 'Other';
                  const headerGradient = PRODUCT_COLORS[firstProduct] || 'from-blue-500 to-indigo-600';

                  return (
                    <div
                      key={card.id}
                      className="rounded-2xl border border-slate-200/80 overflow-hidden shadow-sm hover:shadow-md transition-all"
                    >
                      {/* Card Header — always visible */}
                      <div
                        className={`bg-gradient-to-r ${headerGradient} px-4 py-3 flex items-center justify-between cursor-pointer select-none`}
                        onClick={() => toggleProductCollapse(card.id)}
                      >
                        <div className="flex flex-wrap items-center gap-3 min-w-0">
                          <div className="w-6 h-6 rounded-lg bg-white/20 backdrop-blur-sm flex items-center justify-center shrink-0">
                            <span className="text-white font-black text-[11px]">{idx + 1}</span>
                          </div>
                          <div className="min-w-0">
                            <p className="text-white font-extrabold text-xs truncate">
                              {displayName}
                              {isExisting && (
                                <span className="ml-2 px-1.5 py-0.5 rounded bg-white/20 text-white font-bold text-[9px] uppercase tracking-wider">
                                  Existing
                                </span>
                              )}
                            </p>
                            {card.collapsed && card.leadStage && (
                              <p className="text-white/70 text-[10px] font-semibold truncate">
                                {card.leadStage.replace(/_/g, ' ')} · {card.leadStatus.replace(/_/g, ' ')}
                              </p>
                            )}
                          </div>
                        </div>
                        <div className="flex flex-wrap items-center gap-2">
                          {!isExisting && (
                            <button
                              type="button"
                              onClick={e => { e.stopPropagation(); removeProductInterest(card.id); }}
                              className="p-1 rounded-lg bg-white/10 hover:bg-red-500/80 text-white transition-all"
                              title="Remove"
                            >
                              <Trash2 size={13} />
                            </button>
                          )}
                          <ChevronDown
                            size={16}
                            className={`text-white transition-transform duration-200 ${card.collapsed ? 'rotate-180' : ''}`}
                          />
                        </div>
                      </div>

                      {/* Card Body — collapse/expand */}
                      {!card.collapsed && (
                        <div className="p-4 space-y-4 bg-white">

                          {/* Interested In — toggle buttons */}
                          <div>
                            <div className="flex items-center justify-between mb-2">
                              <label className="label text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Interested In <span className="text-red-500">*</span></label>
                              {isExisting && (
                                <span className="text-[10px] text-slate-400 font-medium italic">
                                  Category fixed for existing records. Change status below or click "+ Add Product Interest" for a new product.
                                </span>
                              )}
                            </div>
                            <div className="flex flex-wrap gap-2">
                              {['Health', 'Life', 'Term', 'Accident Policy', 'Motor', 'Mutual Funds', 'Porting', 'Other'].map(prod => {
                                const isSel = card.interestedIn.includes(prod);
                                const isAlreadySelected = false;
                                const PILL_COLORS: Record<string, string> = {
                                  Health: isSel ? 'bg-emerald-600 border-emerald-600 text-white' : 'bg-emerald-50 border-emerald-200 text-emerald-700 hover:bg-emerald-100',
                                  Life: isSel ? 'bg-blue-600 border-blue-600 text-white' : 'bg-blue-50 border-blue-200 text-blue-700 hover:bg-blue-100',
                                  Term: isSel ? 'bg-violet-600 border-violet-600 text-white' : 'bg-violet-50 border-violet-200 text-violet-700 hover:bg-violet-100',
                                  'Accident Policy': isSel ? 'bg-orange-600 border-orange-600 text-white' : 'bg-orange-50 border-orange-200 text-orange-700 hover:bg-orange-100',
                                  Motor: isSel ? 'bg-rose-600 border-rose-600 text-white' : 'bg-rose-50 border-rose-200 text-rose-700 hover:bg-rose-100',
                                  'Mutual Funds': isSel ? 'bg-cyan-600 border-cyan-600 text-white' : 'bg-cyan-50 border-cyan-200 text-cyan-700 hover:bg-cyan-100',
                                  Porting: isSel ? 'bg-yellow-500 border-yellow-500 text-white' : 'bg-yellow-50 border-yellow-200 text-yellow-700 hover:bg-yellow-100',
                                  Other: isSel ? 'bg-slate-700 border-slate-700 text-white' : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100',
                                };
                                let btnStyle = PILL_COLORS[prod] || (isSel ? 'bg-slate-700 text-white border-slate-700' : 'bg-white border-slate-200 text-slate-600');
                                return (
                                  <button
                                    key={prod}
                                    type="button"
                                    disabled={isExisting}
                                    onClick={() => {
                                      const next = isSel ? [] : [prod];
                                      updateProductInterest(card.id, 'interestedIn', next);
                                    }}
                                    className={`px-3 py-1.5 rounded-xl text-[11px] font-bold border transition-all select-none ${btnStyle} ${isExisting ? 'opacity-70 cursor-not-allowed' : ''}`}
                                  >
                                    {isSel ? '✓ ' : '+ '}{prod}
                                  </button>
                                );
                              })}
                            </div>
                            {card.interestedIn.includes('Other') && (
                              <div className="bg-slate-100/90 border-2 border-slate-300 rounded-xl p-3 space-y-1.5 animate-fadeIn mt-2.5">
                                <label className="label text-[10px] font-extrabold text-slate-700 uppercase tracking-wider block">
                                  Specify Other Product Name <span className="text-red-500">*</span>
                                </label>
                                <input
                                  type="text"
                                  disabled={isExisting}
                                  className={`w-full text-xs px-3.5 py-2.5 bg-white border border-slate-300 rounded-lg text-slate-800 placeholder-slate-400 font-medium focus:ring-2 focus:ring-slate-500 focus:border-slate-500 outline-none shadow-xs ${isExisting ? 'opacity-75 bg-slate-100 cursor-not-allowed' : ''}`}
                                  placeholder="Specify product name..."
                                  value={card.otherProduct}
                                  onChange={e => updateProductInterest(card.id, 'otherProduct', e.target.value)}
                                />
                              </div>
                            )}
                          </div>

                          {/* Description Details Box */}
                          <div className="bg-slate-50/90 rounded-2xl border border-slate-200/70 p-4 space-y-2 shadow-xs">
                            <div className="flex flex-wrap items-center gap-2">
                              <div className="w-6 h-6 rounded-lg bg-indigo-100 text-indigo-600 flex items-center justify-center shrink-0">
                                <FileText size={13} />
                              </div>
                              <h4 className="text-[11px] font-extrabold text-slate-700 uppercase tracking-wider">
                                Description Details
                              </h4>
                            </div>
                            <textarea
                              rows={2}
                              className="w-full text-xs p-3 bg-white border border-slate-200 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 rounded-xl text-slate-800 placeholder-slate-400 font-medium outline-none resize-y transition-all shadow-2xs"
                              placeholder="Enter details for whom they are interested, specific coverage requirements, family member preferences, or notes..."
                              value={card.descriptionDetails || ''}
                              onChange={e => updateProductInterest(card.id, 'descriptionDetails', e.target.value)}
                            />
                          </div>

                          {/* Row 1: Stage, Status, Type */}
                          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                            <div>
                              <label className="label text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">Lead Stage <span className="text-red-500">*</span></label>
                              <select
                                className="input w-full text-xs"
                                value={card.leadStage}
                                onChange={e => updateProductInterest(card.id, 'leadStage', e.target.value)}
                              >
                                <option value="TO_CONTACT">To Contact</option>
                                <option value="CONTACTED">Contacted</option>
                                <option value="PROPOSAL_SENT">Proposal Sent</option>
                                <option value="LOGIN_PROGRESS">Login in Progress</option>
                                <option value="PAYMENT_DONE">Payment Done</option>
                                <option value="PROCESS_COMPLETED">Process Completed</option>
                              </select>
                            </div>
                            <div>
                              <label className="label text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
                                Lead Status <span className="text-red-500">*</span>{isExisting ? ' (Editable)' : ''}
                              </label>
                              <select
                                className="input w-full text-xs"
                                value={card.leadStatus}
                                onChange={e => updateProductInterest(card.id, 'leadStatus', e.target.value)}
                              >
                                <option value="INTERESTED">Interested</option>
                                <option value="HOT">Hot 🔥</option>
                                <option value="VERY_HOT">Very Hot 🔥🔥</option>
                                <option value="NOT_INTERESTED">Not Interested</option>
                                <option value="LEAD_LOST">Lead Lost</option>
                              </select>
                            </div>
                            <div>
                              <label className="label text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">Lead Type <span className="text-red-500">*</span></label>
                              <select
                                disabled={isExisting}
                                className={`input w-full text-xs ${isExisting ? 'opacity-75 bg-slate-100 cursor-not-allowed' : ''}`}
                                value={card.leadType}
                                onChange={e => updateProductInterest(card.id, 'leadType', e.target.value)}
                              >
                                <option value="FRESH">Fresh</option>
                                <option value="RENEWAL">Renewal</option>
                                <option value="PORTING">Porting</option>
                              </select>
                            </div>
                          </div>

                          {/* Prominent Dependent Details Textbox when Depend is selected */}
                          {card.dependencyType === 'DEPENDENT' && (
                            <div className="bg-blue-50/80 border-2 border-blue-200 rounded-xl p-3 space-y-1.5 animate-fadeIn">
                              <label className="label text-[10px] font-extrabold text-blue-700 uppercase tracking-wider flex flex-wrap items-center gap-1">
                                <span className="w-1.5 h-1.5 rounded-full bg-blue-600 shrink-0" />
                                Dependent Details / Name / Relation <span className="text-red-500">*</span>
                              </label>
                              <input
                                type="text"
                                disabled={isExisting}
                                className={`w-full text-xs px-3.5 py-2.5 bg-white border border-blue-300 rounded-lg text-slate-800 placeholder-slate-400 font-medium focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none shadow-xs ${isExisting ? 'opacity-75 bg-slate-100 cursor-not-allowed' : ''}`}
                                placeholder="Enter dependent details (e.g. Spouse - Anita Sharma, Age 32)..."
                                value={card.dependentDetails || ''}
                                onChange={e => updateProductInterest(card.id, 'dependentDetails', e.target.value)}
                              />
                            </div>
                          )}

                          {/* Row 2: Source, Assigned Employee, Follow-up Date, Expected Premium */}
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            <div>
                              <div className="flex items-center justify-between mb-1">
                                <label className="label text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                                  Lead Source <span className="text-red-500">*</span>
                                  {isExisting && !isAdminOrSuperadmin ? (
                                    <span className="ml-1 text-[8.5px] font-semibold text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded">
                                      Locked
                                    </span>
                                  ) : null}
                                </label>
                              </div>

                              <select
                                disabled={isExisting && !isAdminOrSuperadmin}
                                className={`input w-full text-xs bg-white font-medium ${isExisting && !isAdminOrSuperadmin ? 'opacity-75 bg-slate-100 cursor-not-allowed' : ''}`}
                                value={card.leadSource || 'Walkin'}
                                onChange={e => updateProductInterest(card.id, 'leadSource', e.target.value)}
                              >
                                {LEAD_SOURCES.map(src => (
                                  <option key={src} value={src}>{src}</option>
                                ))}
                                {card.leadSource && !LEAD_SOURCES.includes(card.leadSource) && (
                                  <option value={card.leadSource}>{card.leadSource}</option>
                                )}
                              </select>
                            </div>
                            <div>
                              <label className="label text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">Assigned Employee</label>
                              <select
                                className="input w-full text-xs bg-white"
                                value={card.assignedEmployeeId}
                                onChange={e => updateProductInterest(card.id, 'assignedEmployeeId', e.target.value)}
                              >
                                <option value="">Unassigned</option>
                                {employeesList.map((emp: any) => {
                                  const empUserId = emp.userId || emp.user?.id || emp.id;
                                  const empName = `${emp.firstName || emp.user?.firstName || ''} ${emp.lastName || emp.user?.lastName || ''}`.trim() || emp.email || 'Employee';
                                  return (
                                    <option key={emp.id || empUserId} value={empUserId}>
                                      {empName}
                                    </option>
                                  );
                                })}
                              </select>
                            </div>
                            <div>
                              <label className="label text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">Follow-up Date <span className="text-red-500">*</span></label>
                              <DatePicker
                                disabled={isExisting}
                                className={`input w-full text-xs ${isExisting ? 'opacity-75 bg-slate-100 cursor-not-allowed' : ''}`}
                                value={card.followUpDate}
                                onDateChange={date => updateProductInterest(card.id, 'followUpDate', date)}
                              />
                            </div>
                            <div>
                              <label className="label text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">Expected Premium / Budget (₹) <span className="text-red-500">*</span></label>
                              <input
                                type="number"
                                disabled={isExisting}
                                className={`input w-full text-xs ${isExisting ? 'opacity-75 bg-slate-100 cursor-not-allowed' : ''}`}
                                placeholder="e.g. 12000"
                                min={0}
                                value={card.expectedPremium}
                                onChange={e => updateProductInterest(card.id, 'expectedPremium', e.target.value)}
                              />
                            </div>
                          </div>

                          {/* Consultation Comments Section */}
                          <div className="bg-slate-50/90 rounded-2xl border border-slate-200/70 p-4 space-y-3 shadow-xs">
                            {/* Header */}
                            <div className="flex items-center justify-between">
                              <div className="flex flex-wrap items-center gap-2">
                                <div className="w-6 h-6 rounded-lg bg-blue-100 text-blue-600 flex items-center justify-center shrink-0">
                                  <MessageCircle size={13} />
                                </div>
                                <h4 className="text-[11px] font-extrabold text-slate-700 uppercase tracking-wider">
                                  Consultation Comments
                                </h4>
                              </div>
                              {card.comments.length > 0 && (
                                <span className="text-[10px] font-extrabold bg-slate-200/70 text-slate-600 px-2 py-0.5 rounded-full">
                                  {card.comments.length} {card.comments.length === 1 ? 'Comment' : 'Comments'}
                                </span>
                              )}
                            </div>

                            {/* Timeline List */}
                            <div className="max-h-56 overflow-y-auto space-y-2.5 custom-scrollbar pr-0.5">
                              {card.comments.length === 0 ? (
                                <div className="bg-white/60 rounded-xl border border-dashed border-slate-200 p-4 text-center">
                                  <p className="text-xs text-slate-400 font-medium italic">No comments yet. Add the first summary below.</p>
                                </div>
                              ) : (
                                (card.showAllComments ? card.comments : card.comments.slice(0, 2)).map((cmt, ci) => (
                                  <div key={ci} className="bg-white rounded-xl border border-slate-200/80 p-3 shadow-2xs hover:shadow-xs hover:border-blue-200 transition-all space-y-1.5 relative overflow-hidden group">
                                    <div className="flex items-center justify-between gap-2">
                                      <span className="inline-flex flex-wrap items-center gap-1 text-[10px] font-bold text-blue-700 bg-blue-50 border border-blue-100 px-2 py-0.5 rounded-lg shadow-2xs">
                                        <span className="w-1.5 h-1.5 rounded-full bg-blue-500 shrink-0" />
                                        {cmt.author}
                                      </span>
                                      <span className="text-[10px] text-slate-400 font-semibold flex flex-wrap items-center gap-1">
                                        {cmt.datetime}
                                      </span>
                                    </div>
                                    <p className="text-xs text-slate-700 font-medium leading-relaxed whitespace-pre-wrap pl-0.5">
                                      {cmt.text}
                                    </p>
                                  </div>
                                ))
                              )}
                            </div>

                            {/* Know More / Show Less Toggle Button */}
                            {card.comments.length > 2 && (
                              <div className="pt-0.5 flex justify-start">
                                <button
                                  type="button"
                                  onClick={() => updateProductInterest(card.id, 'showAllComments', !card.showAllComments)}
                                  className="inline-flex flex-wrap items-center gap-1 text-xs font-extrabold text-blue-600 hover:text-blue-800 hover:underline cursor-pointer transition-all"
                                >
                                  {card.showAllComments ? (
                                    <>
                                      Show Less <ChevronUp size={13} />
                                    </>
                                  ) : (
                                    <>
                                      Know More ({card.comments.length - 2} more history) <ChevronDown size={13} />
                                    </>
                                  )}
                                </button>
                              </div>
                            )}

                            {/* Add Call Summary & Consultation Comment Box */}
                            <div className="bg-white rounded-xl border-2 border-blue-200/90 p-3 space-y-2 shadow-2xs focus-within:border-blue-500 focus-within:ring-2 focus-within:ring-blue-100 transition-all mt-1">
                              <div className="flex items-center justify-between">
                                <label className="text-[10px] font-extrabold text-blue-700 uppercase tracking-wider flex flex-wrap items-center gap-1.5">
                                  <MessageCircle size={12} className="text-blue-600" />
                                  Add Call Summary / Comment
                                </label>
                                <span className="text-[9px] text-slate-400 font-semibold italic">Press Ctrl+Enter to save</span>
                              </div>
                              <textarea
                                rows={2}
                                className="w-full text-xs p-2.5 bg-slate-50/70 border border-slate-200 rounded-lg text-slate-800 placeholder-slate-400 font-medium focus:bg-white focus:border-blue-400 outline-none resize-y transition-all"
                                placeholder="Type call summary, client discussion details, or follow-up notes..."
                                value={card.newComment}
                                onChange={e => updateProductInterest(card.id, 'newComment', e.target.value)}
                                onKeyDown={e => {
                                  if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
                                    e.preventDefault();
                                    addProductComment(card.id);
                                  }
                                }}
                              />
                              <div className="flex justify-end pt-0.5">
                                <button
                                  type="button"
                                  onClick={() => addProductComment(card.id)}
                                  disabled={!card.newComment.trim()}
                                  className="px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-xl font-bold text-xs cursor-pointer transition-all shadow-xs flex flex-wrap items-center gap-1.5"
                                >
                                  <Send size={12} />
                                  Save Call Summary
                                </button>
                              </div>
                            </div>

                          </div>

                        </div>
                      )}
                    </div>
                  );
                })}

                {/* Add Product Interest Button */}
                <button
                  type="button"
                  onClick={addProductInterest}
                  className="w-full mt-1 py-3 rounded-2xl border-2 border-dashed border-blue-300 hover:border-blue-500 bg-blue-50/40 hover:bg-blue-50 text-blue-600 hover:text-blue-700 text-[10px] sm:text-xs font-extrabold flex items-center justify-center gap-2 transition-all cursor-pointer group"
                >
                  + Add Product Interest
                </button>

              </div>
            )}
            {activeLeadTab === 'Personal' && (
              <div className="space-y-4 max-h-[62vh] overflow-y-auto pr-1">
                {/* 1. Personal Details */}
                <div className="border border-slate-200/90 rounded-2xl bg-white shadow-2xs hover:shadow-xs transition-all overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-blue-50/80 via-slate-50 to-indigo-50/30 px-4 py-2.5 border-b border-slate-100 flex items-center justify-between cursor-pointer select-none"
                    onClick={() => togglePersonalCollapse('personalDetails')}
                  >
                    <h4 className="text-xs font-extrabold text-slate-800 uppercase tracking-wider flex flex-wrap items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-gradient-to-br from-blue-600 to-indigo-600 text-white text-[10px] font-black flex items-center justify-center shadow-2xs">1</span>
                      Personal Details
                    </h4>
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-[10px] text-slate-400 font-semibold">Basic Demographics</span>
                      <ChevronDown
                        size={16}
                        className={`text-slate-500 transition-transform duration-200 ${personalCollapsed['personalDetails'] ? 'rotate-180' : ''}`}
                      />
                    </div>
                  </div>
                  {!personalCollapsed['personalDetails'] && (
                    <div className="p-4 grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                    <div>
                      <label className="label text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block mb-1">First Name {isFieldRequired('firstName', true) && <span className="text-red-500">*</span>}</label>
                      <input
                        type="text"
                        className="input w-full focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 rounded-xl transition-all"
                        placeholder="e.g. Rahul"
                        value={personalFields.firstName}
                        onChange={e => setPersonalFields(p => ({ ...p, firstName: e.target.value }))}
                      />
                    </div>
                    <div>
                      <label className="label text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block mb-1">Middle Name</label>
                      <input
                        type="text"
                        className="input w-full focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 rounded-xl transition-all"
                        placeholder="e.g. Kumar"
                        value={personalFields.middleName}
                        onChange={e => setPersonalFields(p => ({ ...p, middleName: e.target.value }))}
                      />
                    </div>
                    <div>
                      <label className="label text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block mb-1">Last Name {isFieldRequired('lastName', true) && <span className="text-red-500">*</span>}</label>
                      <input
                        type="text"
                        className="input w-full focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 rounded-xl transition-all"
                        placeholder="e.g. Sharma"
                        value={personalFields.lastName}
                        onChange={e => setPersonalFields(p => ({ ...p, lastName: e.target.value }))}
                      />
                    </div>
                    <div>
                      <label className="label text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block mb-1">Is Dependent?</label>
                      <select
                        className="input w-full focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 rounded-xl transition-all font-semibold"
                        value={personalFields.isDependent ? 'YES' : 'NO'}
                        onChange={e => setPersonalFields(p => ({ ...p, isDependent: e.target.value === 'YES' }))}
                      >
                        <option value="NO">No</option>
                        <option value="YES">Yes</option>
                      </select>
                    </div>
                    {personalFields.isDependent && (
                      <div className="animate-fadeIn">
                        <label className="label text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block mb-1">
                          Guardian WhatsApp Number
                        </label>
                        <CountryPhoneInput
                          value={personalFields.dependentNo || ''}
                          onChange={(value: string) => setPersonalFields(p => ({ ...p, dependentNo: value }))}
                        />
                      </div>
                    )}
                    <div>
                      <label className="label text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block mb-1">Mother's Name</label>
                      <input
                        type="text"
                        className="input w-full focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 rounded-xl transition-all"
                        placeholder="e.g. Sunita Sharma"
                        value={personalFields.motherName || ''}
                        onChange={e => setPersonalFields(p => ({ ...p, motherName: e.target.value }))}
                      />
                    </div>
                    <div>
                      <label className="label text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block mb-1">Gender {isFieldRequired('gender', false) && <span className="text-red-500">*</span>}</label>
                      <select
                        className="input w-full focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 rounded-xl transition-all"
                        value={personalFields.gender}
                        onChange={e => setPersonalFields(p => ({ ...p, gender: e.target.value }))}
                      >
                        <option value="">Select Gender</option>
                        <option value="MALE">Male</option>
                        <option value="FEMALE">Female</option>
                        <option value="OTHER">Other</option>
                      </select>
                    </div>
                    <div>
                      <label className="label text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block mb-1">Marital Status</label>
                      <select
                        className="input w-full focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 rounded-xl transition-all"
                        value={personalFields.maritalStatus}
                        onChange={e => setPersonalFields(p => ({ ...p, maritalStatus: e.target.value }))}
                      >
                        <option value="">Select Status</option>
                        <option value="SINGLE">Single</option>
                        <option value="MARRIED">Married</option>
                        <option value="DIVORCED">Divorced</option>
                        <option value="WIDOWED">Widowed</option>
                      </select>
                    </div>
                    {personalFields.maritalStatus === 'MARRIED' && (
                      <div className="animate-fadeIn">
                        <label className="label text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block mb-1">Wedding Anniversary Date</label>
                        <DatePicker
                          className="input w-full focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 rounded-xl transition-all"
                          value={personalFields.weddingAnniversaryDate || ''}
                          onDateChange={(val) => setPersonalFields(p => ({ ...p, weddingAnniversaryDate: val }))}
                        />
                      </div>
                    )}
                    <div>
                      <label className="label text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block mb-1">Date of Birth {isFieldRequired('dateOfBirth', false) && <span className="text-red-500">*</span>}</label>
                      <DatePicker
                        className="input w-full focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 rounded-xl transition-all"
                        value={personalFields.dateOfBirth}
                        onDateChange={handleDOBChange}
                      />
                    </div>
                    <div>
                      <label className="label text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block mb-1">Age</label>
                      <input
                        type="text"
                        className="input w-full bg-slate-50 font-semibold text-slate-600 cursor-not-allowed rounded-xl"
                        value={personalFields.age}
                        disabled
                        placeholder="Auto-calculated"
                      />
                    </div>
                    <div>
                      <label className="label text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block mb-1">Height (cm)</label>
                      <input
                        type="number"
                        className="input w-full focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 rounded-xl transition-all"
                        placeholder="e.g. 170"
                        value={personalFields.height}
                        onChange={(e) => setPersonalFields((p) => ({ ...p, height: e.target.value }))}
                      />
                    </div>
                    <div>
                      <label className="label text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block mb-1">Weight (kg)</label>
                      <input
                        type="number"
                        className="input w-full focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 rounded-xl transition-all"
                        placeholder="e.g. 65"
                        value={personalFields.weight}
                        onChange={(e) => setPersonalFields((p) => ({ ...p, weight: e.target.value }))}
                      />
                    </div>
                    <div>
                      <label className="label text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block mb-1">PAN Number {isFieldRequired('panNumber', false) && <span className="text-red-500">*</span>}</label>
                      <input
                        type="text"
                        placeholder="ABCDE1234F"
                        className="input w-full focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 rounded-xl transition-all uppercase"
                        value={personalFields.pan || personalFields.panNumber || ''}
                        onChange={(e) => setPersonalFields(p => ({ ...p, pan: e.target.value.toUpperCase(), panNumber: e.target.value.toUpperCase() }))}
                      />
                    </div>
                    <div>
                      <label className="label text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block mb-1">Role</label>
                      <select
                        className="input w-full focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 rounded-xl transition-all font-semibold"
                        value={personalFields.role || 'Contact'}
                        onChange={e => setPersonalFields(p => ({ ...p, role: e.target.value }))}
                      >
                        <option value="Contact">Contact</option>
                        <option value="Employee">Employee</option>
                        <option value="ADMIN/OWNER">ADMIN/OWNER</option>
                        <option value="Business Associate">Business Associate</option>
                      </select>
                    </div>
                    <div>
                      <label className="label text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block mb-1">Birth Place</label>
                      <input
                        type="text"
                        className="input w-full focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 rounded-xl transition-all"
                        placeholder="e.g. Pune, Maharashtra"
                        value={personalFields.birthPlace || ''}
                        onChange={e => setPersonalFields(p => ({ ...p, birthPlace: e.target.value }))}
                      />
                    </div>
                    <div>
                      <label className="label text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block mb-1">Assigned Employees</label>
                      {(() => {
                        const selectedIds: string[] = Array.isArray(personalFields.assignedEmployeeIds)
                          ? personalFields.assignedEmployeeIds
                          : (personalFields.assignedEmployeeId ? [personalFields.assignedEmployeeId] : []);
                        const isEmpSelected = (emp: any) => {
                          const ids = [emp.userId, emp.user?.id, emp.id].filter(Boolean);
                          return selectedIds.some((id: string) => ids.includes(id));
                        };
                        const selectedEmployees = employeesList.filter((emp: any) => isEmpSelected(emp));
                        const searchTerm = employeePickerSearch.trim().toLowerCase();
                        const filteredEmployees = employeesList.filter((emp: any) => {
                          const name = `${emp.firstName || emp.user?.firstName || ''} ${emp.lastName || emp.user?.lastName || ''}`.trim()
                            || emp.name || emp.email || 'Employee';
                          return !searchTerm
                            || name.toLowerCase().includes(searchTerm)
                            || (emp.email || emp.user?.email || '').toLowerCase().includes(searchTerm)
                            || (emp.department || '').toLowerCase().includes(searchTerm);
                        });
                        const updateAssignedEmployees = (employeeIds: string[]) => {
                          const primaryEmployeeId = employeeIds[0] || '';
                          setPersonalFields(p => ({
                            ...p,
                            assignedEmployeeIds: employeeIds,
                            assignedEmployeeId: primaryEmployeeId,
                          }));
                          setLeadInfoFields(p => ({ ...p, assignedEmployeeId: primaryEmployeeId }));
                          setProductInterests(prev => prev.map(c => ({ ...c, assignedEmployeeId: primaryEmployeeId })));
                        };

                        return (
                          <>
                            <button
                              type="button"
                              disabled={authUser?.role === 'EMPLOYEE'}
                              aria-expanded={isEmployeePickerOpen}
                              aria-controls="contact-assigned-employees"
                              onClick={() => setIsEmployeePickerOpen(open => !open)}
                              className={clsx(
                                'w-full min-h-[42px] px-3 py-2 rounded-xl border bg-white text-left transition-colors flex items-center justify-between gap-2',
                                authUser?.role === 'EMPLOYEE'
                                  ? 'border-slate-200 cursor-not-allowed'
                                  : 'border-slate-300 hover:border-blue-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500'
                              )}
                            >
                              <span className="min-w-0 flex items-center gap-2">
                                <Users size={15} className="shrink-0 text-blue-600" />
                                <span className="truncate text-xs font-semibold text-slate-700">
                                  {selectedEmployees.length
                                    ? selectedEmployees.map((emp: any) =>
                                        `${emp.firstName || emp.user?.firstName || ''} ${emp.lastName || emp.user?.lastName || ''}`.trim()
                                        || emp.name || emp.email || 'Employee'
                                      ).join(', ')
                                    : 'Choose employees'}
                                </span>
                              </span>
                              <span className="shrink-0 flex items-center gap-2">
                                {selectedIds.length > 0 && (
                                  <span className="rounded-full bg-blue-50 px-2 py-0.5 text-[10px] font-bold text-blue-700">
                                    {selectedIds.length} selected
                                  </span>
                                )}
                                {isEmployeePickerOpen ? <ChevronUp size={15} /> : <ChevronDown size={15} />}
                              </span>
                            </button>

                            {selectedEmployees.length > 0 && (
                              <div className="mt-2 flex flex-wrap gap-1.5">
                                {selectedEmployees.map((emp: any) => {
                                  const empId = emp.userId || emp.user?.id || emp.id;
                                  const name = `${emp.firstName || emp.user?.firstName || ''} ${emp.lastName || emp.user?.lastName || ''}`.trim()
                                    || emp.name || emp.email || 'Employee';
                                  return (
                                    <span key={empId} className="inline-flex items-center gap-1 rounded-full border border-blue-100 bg-blue-50 px-2.5 py-1 text-[10px] font-semibold text-blue-800">
                                      <UserCheck size={11} />
                                      <span className="max-w-[150px] truncate">{name}</span>
                                    </span>
                                  );
                                })}
                              </div>
                            )}

                            {isEmployeePickerOpen && authUser?.role !== 'EMPLOYEE' && (
                              <div id="contact-assigned-employees" className="mt-2 overflow-hidden rounded-xl border border-slate-200 bg-white shadow-lg">
                                <div className="border-b border-slate-100 p-2.5">
                                  <div className="relative">
                                    <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                                    <input
                                      type="search"
                                      value={employeePickerSearch}
                                      onChange={e => setEmployeePickerSearch(e.target.value)}
                                      placeholder="Search by name, email or department"
                                      className="w-full rounded-lg border border-slate-200 py-2 pl-9 pr-3 text-xs outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-500/10"
                                    />
                                  </div>
                                  <div className="mt-2 flex items-center justify-between">
                                    <span className="text-[10px] font-semibold text-slate-500">
                                      {selectedIds.length} of {employeesList.length} selected
                                    </span>
                                    <div className="flex items-center gap-3">
                                      <button
                                        type="button"
                                        className="text-[10px] font-bold text-blue-600 hover:text-blue-800"
                                        onClick={() => updateAssignedEmployees(employeesList.map((emp: any) => emp.userId || emp.user?.id || emp.id))}
                                      >
                                        Select all
                                      </button>
                                      <button
                                        type="button"
                                        className="text-[10px] font-bold text-slate-500 hover:text-slate-800"
                                        onClick={() => updateAssignedEmployees([])}
                                      >
                                        Clear
                                      </button>
                                    </div>
                                  </div>
                                </div>
                                <div className="max-h-52 overflow-y-auto p-1.5">
                                  {filteredEmployees.length === 0 ? (
                                    <p className="px-3 py-5 text-center text-xs text-slate-500">No employees match your search.</p>
                                  ) : filteredEmployees.map((emp: any) => {
                                    const empId = emp.userId || emp.user?.id || emp.id;
                                    const name = `${emp.firstName || emp.user?.firstName || ''} ${emp.lastName || emp.user?.lastName || ''}`.trim()
                                      || emp.name || emp.email || 'Employee';
                                    const email = emp.email || emp.user?.email;
                                    const isSelected = isEmpSelected(emp);
                                    return (
                                      <label key={empId} className={clsx(
                                        'flex cursor-pointer items-center gap-3 rounded-lg px-2.5 py-2 transition-colors',
                                        isSelected ? 'bg-blue-50' : 'hover:bg-slate-50'
                                      )}>
                                        <input
                                          type="checkbox"
                                          checked={isSelected}
                                          onChange={e => {
                                            const empIds = [emp.userId, emp.user?.id, emp.id].filter(Boolean);
                                            updateAssignedEmployees(
                                              e.target.checked
                                                ? Array.from(new Set([...selectedIds, empId]))
                                                : selectedIds.filter(id => !empIds.includes(id))
                                            );
                                          }}
                                          className="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                                        />
                                        <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-slate-100 text-xs font-bold text-slate-600">
                                          {name.charAt(0).toUpperCase()}
                                        </span>
                                        <span className="min-w-0 flex-1">
                                          <span className="block truncate text-xs font-semibold text-slate-800">{name}</span>
                                          <span className="block truncate text-[10px] text-slate-500">
                                            {[email, emp.department].filter(Boolean).join(' · ') || 'Employee'}
                                          </span>
                                        </span>
                                      </label>
                                    );
                                  })}
                                </div>
                                <div className="border-t border-slate-100 px-3 py-2 text-[10px] text-slate-500">
                                  Changes are saved when you update the contact.
                                </div>
                              </div>
                            )}

                            {authUser?.role === 'EMPLOYEE' && (
                              <p className="mt-1 text-[10px] text-slate-500">Only the owner can change employee assignments.</p>
                            )}
                          </>
                        );
                      })()}
                    </div>
                    </div>
                  )}
                </div>

                {/* 2. Contact Details */}
                <div className="border border-slate-200/90 rounded-2xl bg-white shadow-2xs hover:shadow-xs transition-all overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-blue-50/80 via-slate-50 to-indigo-50/30 px-4 py-2.5 border-b border-slate-100 flex items-center justify-between cursor-pointer select-none"
                    onClick={() => togglePersonalCollapse('contactDetails')}
                  >
                    <h4 className="text-xs font-extrabold text-slate-800 uppercase tracking-wider flex flex-wrap items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-gradient-to-br from-blue-600 to-indigo-600 text-white text-[10px] font-black flex items-center justify-center shadow-2xs">2</span>
                      Contact Details
                    </h4>
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-[10px] text-slate-400 font-semibold">Communication Info</span>
                      <ChevronDown
                        size={16}
                        className={`text-slate-500 transition-transform duration-200 ${personalCollapsed['contactDetails'] ? 'rotate-180' : ''}`}
                      />
                    </div>
                  </div>
                  {!personalCollapsed['contactDetails'] && (
                    <div className="p-4 grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                    <div>
                      <label className="label text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block mb-1">Email Address {isFieldRequired('email', false) && <span className="text-red-500">*</span>}</label>
                      <input
                        type="email"
                        className="input w-full focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 rounded-xl transition-all"
                        placeholder="client@example.com"
                        value={personalFields.email}
                        onChange={e => setPersonalFields(p => ({ ...p, email: e.target.value }))}
                      />
                    </div>
                    <div>
                      <label className="label text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block mb-1">Aadhaar Number {isFieldRequired('aadhaarNumber', false) && <span className="text-red-500">*</span>}</label>
                      <input
                        type="text"
                        className="input w-full focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 rounded-xl transition-all"
                        placeholder="12-digit Aadhaar No"
                        maxLength={12}
                        value={personalFields.aadhaarNumber}
                        onChange={e => setPersonalFields(p => ({ ...p, aadhaarNumber: e.target.value.replace(/\D/g, '') }))}
                      />
                    </div>
                    <div>
                      <label className="label text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block mb-1">
                        Whatsapp Number {!personalFields.isDependent && isFieldRequired('phone', true) && <span className="text-red-500">*</span>}
                      </label>
                      <CountryPhoneInput
                        value={personalFields.whatsappNumber}
                        onChange={(value: string) =>
                          setPersonalFields((p) => ({
                            ...p,
                            whatsappNumber: value,
                            callingNumber: p.sameAsWhatsapp ? value : p.callingNumber,
                          }))
                        }
                      />
                    </div>
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="label text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block">Calling Number</label>
                        <label className="flex flex-wrap items-center gap-1 text-[10px] text-blue-600 font-semibold cursor-pointer select-none">
                          <input
                            type="checkbox"
                            className="accent-blue-600 w-3 h-3 rounded"
                            checked={personalFields.sameAsWhatsapp}
                            onChange={e => {
                              const checked = e.target.checked;
                              setPersonalFields(p => ({
                                ...p,
                                sameAsWhatsapp: checked,
                                callingNumber: checked ? p.whatsappNumber : p.callingNumber
                              }));
                            }}
                          />
                          Same as Whatsapp
                        </label>
                      </div>
                      <CountryPhoneInput
                        disabled={personalFields.sameAsWhatsapp}
                        value={personalFields.callingNumber}
                        onChange={(value: string) =>
                          setPersonalFields((p) => ({
                            ...p,
                            callingNumber: value,
                          }))
                        }
                      />
                    </div>
                    <div>
                      <label className="label text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block mb-1">Contact Status</label>
                      <select
                        className="input w-full focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 rounded-xl transition-all font-semibold"
                        value={personalFields.contactStatus || (personalFields.isActive !== false ? 'Active' : 'Inactive')}
                        onChange={e => {
                          const val = e.target.value;
                          setPersonalFields(p => ({
                            ...p,
                            contactStatus: val,
                            isActive: val === 'Active'
                          }));
                        }}
                      >
                        <option value="Active">Active</option>
                        <option value="Inactive">Inactive</option>
                      </select>
                    </div>
                    </div>
                  )}
                </div>

                {/* 3. Education & Occupation */}
                <div className="border border-slate-200/90 rounded-2xl bg-white shadow-2xs hover:shadow-xs transition-all overflow-visible">
                  <div
                    className="bg-gradient-to-r from-blue-50/80 via-slate-50 to-indigo-50/30 px-4 py-2.5 border-b border-slate-100 flex items-center justify-between cursor-pointer select-none"
                    onClick={() => togglePersonalCollapse('educationOccupation')}
                  >
                    <h4 className="text-xs font-extrabold text-slate-800 uppercase tracking-wider flex flex-wrap items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-gradient-to-br from-blue-600 to-indigo-600 text-white text-[10px] font-black flex items-center justify-center shadow-2xs">3</span>
                      Education &amp; Occupation
                    </h4>
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-[10px] text-slate-400 font-semibold">Professional Profile</span>
                      <ChevronDown
                        size={16}
                        className={`text-slate-500 transition-transform duration-200 ${personalCollapsed['educationOccupation'] ? 'rotate-180' : ''}`}
                      />
                    </div>
                  </div>
                  {!personalCollapsed['educationOccupation'] && (
                    <div className="p-4 grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                    <div>
                      <label className="label text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block mb-1">Education</label>
                      <DatalistInput
                        className="input w-full focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 rounded-xl transition-all"
                        placeholder="Select or enter Education"
                        value={personalFields.education || ''}
                        options={EDUCATION_OPTIONS}
                        onChange={val => setPersonalFields(p => ({ ...p, education: val }))}
                      />
                    </div>
                    <div>
                      <label className="label text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block mb-1">Annual Income {isFieldRequired('annualIncome', false) && <span className="text-red-500">*</span>}</label>
                      <select
                        className="input w-full focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 rounded-xl transition-all"
                        value={personalFields.annualIncome}
                        onChange={e => setPersonalFields(p => ({ ...p, annualIncome: e.target.value }))}
                      >
                        <option value="">Select Income Bracket</option>
                        <option value="200000">Below 2 Lakhs</option>
                        <option value="500000">2 - 5 Lakhs</option>
                        <option value="1000000">5 - 10 Lakhs</option>
                        <option value="2000000">10 - 20 Lakhs</option>
                        <option value="5000000">20+ Lakhs</option>
                      </select>
                    </div>
                    <div>
                      <label className="label text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block mb-1">Occupation Type {isFieldRequired('occupationType', false) && <span className="text-red-500">*</span>}</label>
                      <DatalistInput
                        className="input w-full focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 rounded-xl transition-all"
                        placeholder="Select or enter Occupation Type"
                        value={personalFields.occupationType || ''}
                        options={OCCUPATION_TYPE_OPTIONS}
                        onChange={val => setPersonalFields(p => ({ ...p, occupationType: val }))}
                      />
                    </div>
                    <div>
                      <label className="label text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block mb-1">Company / Business Name</label>
                      <input
                        type="text"
                        className="input w-full focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 rounded-xl transition-all"
                        placeholder="e.g. Infosys / Traders"
                        value={personalFields.companyName}
                        onChange={e => setPersonalFields(p => ({ ...p, companyName: e.target.value }))}
                      />
                    </div>
                    </div>
                  )}
                </div>

                {/* 4. Address Details */}
                <div className="border border-slate-200/90 rounded-2xl bg-white shadow-2xs hover:shadow-xs transition-all overflow-visible">
                  <div
                    className="bg-gradient-to-r from-blue-50/80 via-slate-50 to-indigo-50/30 px-4 py-2.5 border-b border-slate-100 flex items-center justify-between cursor-pointer select-none"
                    onClick={() => togglePersonalCollapse('addressDetails')}
                  >
                    <h4 className="text-xs font-extrabold text-slate-800 uppercase tracking-wider flex flex-wrap items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-gradient-to-br from-blue-600 to-indigo-600 text-white text-[10px] font-black flex items-center justify-center shadow-2xs">4</span>
                      Address Details
                    </h4>
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-[10px] text-slate-400 font-semibold">Location &amp; Residence</span>
                      <ChevronDown
                        size={16}
                        className={`text-slate-500 transition-transform duration-200 ${personalCollapsed['addressDetails'] ? 'rotate-180' : ''}`}
                      />
                    </div>
                  </div>
                  {!personalCollapsed['addressDetails'] && (
                    <div className="p-4 grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                    <div>
                      <label className="label text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block mb-1">State {isFieldRequired('state', false) && <span className="text-red-500">*</span>}</label>
                      <DatalistInput
                        className="input w-full focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 rounded-xl transition-all"
                        placeholder="Select or search State"
                        value={personalFields.state || ''}
                        options={INDIAN_STATES_AND_UTS}
                        onChange={val => setPersonalFields(p => ({ ...p, state: val, district: '' }))}
                      />
                    </div>
                    <div>
                      <label className="label text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block mb-1">District {isFieldRequired('district', false) && <span className="text-red-500">*</span>}</label>
                      <DatalistInput
                        className="input w-full focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 rounded-xl transition-all"
                        placeholder={personalFields.state ? "Select or search District" : "Select State first"}
                        value={personalFields.district || ''}
                        options={personalFields.state ? (INDIAN_DISTRICTS_BY_STATE[personalFields.state] || []) : []}
                        onChange={val => setPersonalFields(p => ({ ...p, district: val }))}
                      />
                    </div>
                    <div>
                      <label className="label text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block mb-1">City / Town {isFieldRequired('city', false) && <span className="text-red-500">*</span>}</label>
                      <input
                        type="text"
                        className="input w-full focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 rounded-xl transition-all"
                        placeholder="e.g. Pune"
                        value={personalFields.city}
                        onChange={e => setPersonalFields(p => ({ ...p, city: e.target.value }))}
                      />
                    </div>
                    <div>
                      <label className="label text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block mb-1">Pincode {isFieldRequired('pincode', false) && <span className="text-red-500">*</span>}</label>
                      <input
                        type="text"
                        className="input w-full focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 rounded-xl transition-all"
                        placeholder="000000"
                        value={personalFields.pincode}
                        onChange={e => setPersonalFields(p => ({ ...p, pincode: e.target.value }))}
                      />
                    </div>
                    <div className="col-span-3">
                      <label className="label text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block mb-1">Street Address / House No {isFieldRequired('address', false) && <span className="text-red-500">*</span>}</label>
                      <textarea
                        className="input w-full text-xs focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 rounded-xl transition-all"
                        rows={2}
                        placeholder="Flat No, Street, Landmark..."
                        value={personalFields.streetAddress}
                        onChange={e => setPersonalFields(p => ({ ...p, streetAddress: e.target.value }))}
                      />
                    </div>
                    </div>
                  )}
                </div>

                {/* 5. Bank Details */}
                <div className="border border-slate-200/90 rounded-2xl bg-white shadow-2xs hover:shadow-xs transition-all overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-blue-50/80 via-slate-50 to-indigo-50/30 px-4 py-2.5 border-b border-slate-100 flex items-center justify-between cursor-pointer select-none"
                    onClick={() => togglePersonalCollapse('bankDetails')}
                  >
                    <h4 className="text-xs font-extrabold text-slate-800 uppercase tracking-wider flex flex-wrap items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-gradient-to-br from-blue-600 to-indigo-600 text-white text-[10px] font-black flex items-center justify-center shadow-2xs">5</span>
                      Bank Details
                    </h4>
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-[10px] text-slate-400 font-semibold">Banking Information</span>
                      <ChevronDown
                        size={16}
                        className={`text-slate-500 transition-transform duration-200 ${personalCollapsed['bankDetails'] ? 'rotate-180' : ''}`}
                      />
                    </div>
                  </div>
                  {!personalCollapsed['bankDetails'] && (
                    <div className="p-4 grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                    <div>
                      <label className="label text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block mb-1">Bank Name</label>
                      <input
                        type="text"
                        className="input w-full focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 rounded-xl transition-all"
                        placeholder="e.g. HDFC Bank"
                        value={personalFields.bankName || ''}
                        onChange={e => setPersonalFields(p => ({ ...p, bankName: e.target.value }))}
                      />
                    </div>
                    <div>
                      <label className="label text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block mb-1">Account Number</label>
                      <input
                        type="text"
                        className="input w-full focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 rounded-xl transition-all"
                        placeholder="e.g. 50100012345678"
                        value={personalFields.bankAccountNumber || ''}
                        onChange={e => setPersonalFields(p => ({ ...p, bankAccountNumber: e.target.value }))}
                      />
                    </div>
                    <div>
                      <label className="label text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block mb-1">IFSC Code</label>
                      <input
                        type="text"
                        className="input w-full focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 rounded-xl transition-all uppercase"
                        placeholder="e.g. HDFC0001234"
                        value={personalFields.bankIfsc || ''}
                        onChange={e => setPersonalFields(p => ({ ...p, bankIfsc: e.target.value.toUpperCase() }))}
                      />
                    </div>
                    <div>
                      <label className="label text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block mb-1">Branch Name</label>
                      <input
                        type="text"
                        className="input w-full focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 rounded-xl transition-all"
                        placeholder="e.g. Shivajinagar Branch"
                        value={personalFields.bankBranch || ''}
                        onChange={e => setPersonalFields(p => ({ ...p, bankBranch: e.target.value }))}
                      />
                    </div>
                    </div>
                  )}
                </div>

                {/* 6. Lifestyle Habits */}
                <div className="border border-slate-200/90 rounded-2xl bg-white shadow-2xs hover:shadow-xs transition-all overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-blue-50/80 via-slate-50 to-indigo-50/30 px-4 py-2.5 border-b border-slate-100 flex items-center justify-between cursor-pointer select-none"
                    onClick={() => togglePersonalCollapse('lifestyleHabits')}
                  >
                    <h4 className="text-xs font-extrabold text-slate-800 uppercase tracking-wider flex flex-wrap items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-gradient-to-br from-blue-600 to-indigo-600 text-white text-[10px] font-black flex items-center justify-center shadow-2xs">6</span>
                      Lifestyle Habits
                    </h4>
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-[10px] text-slate-400 font-semibold">Personal Habits</span>
                      <ChevronDown
                        size={16}
                        className={`text-slate-500 transition-transform duration-200 ${personalCollapsed['lifestyleHabits'] ? 'rotate-180' : ''}`}
                      />
                    </div>
                  </div>
                  {!personalCollapsed['lifestyleHabits'] && (
                    <div className="p-4 flex flex-wrap gap-4">
                    <label className={`flex items-center gap-2.5 px-4 py-2.5 rounded-xl border transition-all cursor-pointer select-none ${personalFields.chewTobacco ? 'bg-blue-50/80 border-blue-300 text-blue-800 font-bold shadow-2xs' : 'bg-slate-50/50 border-slate-200 text-slate-600 hover:bg-slate-50'}`}>
                      <input
                        type="checkbox"
                        className="accent-blue-600 w-4 h-4 rounded"
                        checked={!!personalFields.chewTobacco}
                        onChange={e => setPersonalFields(p => ({ ...p, chewTobacco: e.target.checked }))}
                      />
                      <span className="text-xs font-semibold">Chew Tobacco</span>
                    </label>
                    <label className={`flex items-center gap-2.5 px-4 py-2.5 rounded-xl border transition-all cursor-pointer select-none ${personalFields.smoke ? 'bg-blue-50/80 border-blue-300 text-blue-800 font-bold shadow-2xs' : 'bg-slate-50/50 border-slate-200 text-slate-600 hover:bg-slate-50'}`}>
                      <input
                        type="checkbox"
                        className="accent-blue-600 w-4 h-4 rounded"
                        checked={!!personalFields.smoke}
                        onChange={e => setPersonalFields(p => ({ ...p, smoke: e.target.checked }))}
                      />
                      <span className="text-xs font-semibold">Smoke</span>
                    </label>
                    <label className={`flex items-center gap-2.5 px-4 py-2.5 rounded-xl border transition-all cursor-pointer select-none ${personalFields.consumeAlcohol ? 'bg-blue-50/80 border-blue-300 text-blue-800 font-bold shadow-2xs' : 'bg-slate-50/50 border-slate-200 text-slate-600 hover:bg-slate-50'}`}>
                      <input
                        type="checkbox"
                        className="accent-blue-600 w-4 h-4 rounded"
                        checked={!!personalFields.consumeAlcohol}
                        onChange={e => setPersonalFields(p => ({ ...p, consumeAlcohol: e.target.checked }))}
                      />
                      <span className="text-xs font-semibold">Consume Alcohol</span>
                    </label>
                    </div>
                  )}
                </div>

                {/* 7. Health History / Medical History */}
                <div className="border border-slate-200/90 rounded-2xl bg-white shadow-2xs hover:shadow-xs transition-all overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-blue-50/80 via-slate-50 to-indigo-50/30 px-4 py-2.5 border-b border-slate-100 flex items-center justify-between cursor-pointer select-none"
                    onClick={() => togglePersonalCollapse('healthHistory')}
                  >
                    <h4 className="text-xs font-extrabold text-slate-800 uppercase tracking-wider flex flex-wrap items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-gradient-to-br from-blue-600 to-indigo-600 text-white text-[10px] font-black flex items-center justify-center shadow-2xs">7</span>
                      Health History / Medical History
                    </h4>
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-[10px] text-slate-400 font-semibold">Medical Records</span>
                      <ChevronDown
                        size={16}
                        className={`text-slate-500 transition-transform duration-200 ${personalCollapsed['healthHistory'] ? 'rotate-180' : ''}`}
                      />
                    </div>
                  </div>
                  {!personalCollapsed['healthHistory'] && (
                    <div className="p-4 space-y-4">
                    {/* Declared Medical History Multi-Select */}
                    <MultiSelectBox
                      label="Declared Medical History (Multi-Select)"
                      selectedValues={(personalFields.declaredMedicalHistory || []) as string[]}
                      onChange={(vals) => setPersonalFields(p => ({ ...p, declaredMedicalHistory: vals }))}
                      badgeColor="blue"
                      placeholder="Click to select medical conditions..."
                    />

                    {/* NOT Declared Medical History Multi-Select */}
                    <MultiSelectBox
                      label="NOT Declared Medical History (Multi-Select)"
                      selectedValues={(personalFields.notDeclaredMedicalHistory || []) as string[]}
                      onChange={(vals) => setPersonalFields(p => ({ ...p, notDeclaredMedicalHistory: vals }))}
                      badgeColor="orange"
                      placeholder="Click to select NOT declared conditions..."
                    />

                    {/* Details of Medical History */}
                    <div>
                      <label className="label text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block mb-1">Details of Medical History</label>
                      <textarea
                        ref={el => autoResizeTextarea(el)}
                        className="input w-full text-xs focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 rounded-xl transition-all leading-relaxed py-2 resize-y"
                        style={{ height: 'auto', minHeight: '56px' }}
                        rows={Math.max(2, (personalFields.medicalHistoryDetails || '').split('\n').length)}
                        placeholder="Add any additional medical history details..."
                        value={personalFields.medicalHistoryDetails}
                        onInput={e => autoResizeTextarea(e.currentTarget)}
                        onChange={e => setPersonalFields(p => ({ ...p, medicalHistoryDetails: e.target.value }))}
                      />
                    </div>
                    </div>
                  )}
                </div>

                {/* 8. Any Surgery Done / Advised */}
                <div className="border border-slate-200/90 rounded-2xl bg-white shadow-2xs hover:shadow-xs transition-all overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-blue-50/80 via-slate-50 to-indigo-50/30 px-4 py-2.5 border-b border-slate-100 flex items-center justify-between cursor-pointer select-none"
                    onClick={() => togglePersonalCollapse('surgeryDetails')}
                  >
                    <h4 className="text-xs font-extrabold text-slate-800 uppercase tracking-wider flex flex-wrap items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-gradient-to-br from-blue-600 to-indigo-600 text-white text-[10px] font-black flex items-center justify-center shadow-2xs">8</span>
                      Any Surgery Done / Advised
                    </h4>
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-[10px] text-slate-400 font-semibold">Surgical History</span>
                      <ChevronDown
                        size={16}
                        className={`text-slate-500 transition-transform duration-200 ${personalCollapsed['surgeryDetails'] ? 'rotate-180' : ''}`}
                      />
                    </div>
                  </div>
                  {!personalCollapsed['surgeryDetails'] && (
                    <div className="p-4">
                    <label className="label text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block mb-1">Surgery Details / History</label>
                    <textarea
                      ref={el => autoResizeTextarea(el)}
                      className="input w-full text-xs focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 rounded-xl transition-all leading-relaxed py-2 resize-y"
                      style={{ height: 'auto', minHeight: '56px' }}
                      rows={Math.max(2, (personalFields.surgeryDetails || '').split('\n').length)}
                      placeholder="Specify any surgeries done or advised..."
                      value={personalFields.surgeryDetails || ''}
                      onInput={e => autoResizeTextarea(e.currentTarget)}
                      onChange={e => setPersonalFields(p => ({ ...p, surgeryDetails: e.target.value }))}
                    />
                    </div>
                  )}
                </div>

                {/* 9. Current Medicines / Prescription */}
                <div className="border border-slate-200/90 rounded-2xl bg-white shadow-2xs hover:shadow-xs transition-all overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-blue-50/80 via-slate-50 to-indigo-50/30 px-4 py-2.5 border-b border-slate-100 flex items-center justify-between cursor-pointer select-none"
                    onClick={() => togglePersonalCollapse('prescriptionDetails')}
                  >
                    <h4 className="text-xs font-extrabold text-slate-800 uppercase tracking-wider flex flex-wrap items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-gradient-to-br from-blue-600 to-indigo-600 text-white text-[10px] font-black flex items-center justify-center shadow-2xs">9</span>
                      Current Medicines / Prescription
                    </h4>
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-[10px] text-slate-400 font-semibold">Ongoing Medications</span>
                      <ChevronDown
                        size={16}
                        className={`text-slate-500 transition-transform duration-200 ${personalCollapsed['prescriptionDetails'] ? 'rotate-180' : ''}`}
                      />
                    </div>
                  </div>
                  {!personalCollapsed['prescriptionDetails'] && (
                    <div className="p-4">
                    <label className="label text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block mb-1">Prescription &amp; Medication Details</label>
                    <textarea
                      ref={el => autoResizeTextarea(el)}
                      className="input w-full text-xs focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 rounded-xl transition-all leading-relaxed py-2 resize-y"
                      style={{ height: 'auto', minHeight: '56px' }}
                      rows={Math.max(2, (personalFields.prescriptionDetails || '').split('\n').length)}
                      placeholder="List current ongoing medicines or prescriptions..."
                      value={personalFields.prescriptionDetails || ''}
                      onInput={e => autoResizeTextarea(e.currentTarget)}
                      onChange={e => setPersonalFields(p => ({ ...p, prescriptionDetails: e.target.value }))}
                    />
                    </div>
                  )}
                </div>
              </div>
            )}


            {activeLeadTab === 'Family' && (
              <div className="h-full flex flex-col">
                {/* Action buttons bar */}
                <div className="flex items-center justify-between gap-3 mb-3 flex-shrink-0">
                  <div>
                    <h3 className="text-xs font-bold text-slate-800">Family Members &amp; Dependents</h3>
                    <p className="text-[11px] text-slate-500 font-medium">
                      Manage relationship profiles, personal details, contact info, and medical history.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={(e) => {
                      if (e.ctrlKey || e.metaKey) {
                        e.preventDefault();
                        const contactId = editContactId || loadedContact?.id;
                        if (contactId) openFamilyMemberInNewTab(contactId);
                        return;
                      }
                      openAddFamilyMemberModal();
                    }}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
                        e.preventDefault();
                        e.stopPropagation();
                        const contactId = editContactId || loadedContact?.id;
                        if (contactId) openFamilyMemberInNewTab(contactId);
                      }
                    }}
                    className="flex items-center justify-center gap-2 px-4 py-2.5 border-2 border-blue-400 text-blue-600 text-xs font-bold rounded-xl hover:bg-blue-50 cursor-pointer transition-all shadow-xs shrink-0"
                    title="Add Family Member (Ctrl+Click or Ctrl+Enter to open in new tab)"
                  >
                    <Plus size={15} />
                    + Add Family Member
                  </button>
                </div>

                <div className="space-y-3 mb-3 overflow-y-auto max-h-[60vh] custom-scrollbar pr-1">
                  {familyMembers.length === 0 ? (
                    <div className="flex flex-col items-center justify-center rounded-2xl border-2 border-dashed border-slate-200 bg-slate-50/60 px-6 py-12 text-center min-h-[220px]">
                      <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-blue-100 to-indigo-100 text-blue-600 flex items-center justify-center mb-3 shadow-xs">
                        <Users size={26} className="text-blue-600" />
                      </div>
                      <p className="text-sm font-bold text-slate-700">No family members added yet</p>
                      <p className="text-[11px] text-slate-500 mt-1 max-w-[320px]">
                        Add family members, spouses, children, or dependents to manage full relationship and health profiles in a dedicated popup.
                      </p>
                      <button
                        type="button"
                        onClick={(e) => {
                          if (e.ctrlKey || e.metaKey) {
                            e.preventDefault();
                            const contactId = editContactId || loadedContact?.id;
                            if (contactId) openFamilyMemberInNewTab(contactId);
                            return;
                          }
                          openAddFamilyMemberModal();
                        }}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
                            e.preventDefault();
                            e.stopPropagation();
                            const contactId = editContactId || loadedContact?.id;
                            if (contactId) openFamilyMemberInNewTab(contactId);
                          }
                        }}
                        className="mt-4 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-md shadow-blue-500/20 transition-all flex items-center gap-1.5 cursor-pointer"
                        title="Add First Family Member (Ctrl+Click or Ctrl+Enter to open in new tab)"
                      >
                        <Plus size={14} />
                        Add First Family Member
                      </button>
                    </div>
                  ) : (
                    <div className="grid gap-3">
                      {familyMembers.map((member, idx) => {
                        const fullName = [member.firstName, member.middleName, member.lastName].filter(Boolean).join(' ').trim() || member.name || 'Family Member';
                        const rel = (member.relation || 'OTHER').toUpperCase();
                        let relLabel = rel.replace(/_/g, ' ');
                        if (rel === 'SPOUSE') {
                          const g = (member.gender || '').toUpperCase();
                          if (g === 'FEMALE') relLabel = 'WIFE';
                          else if (g === 'MALE') relLabel = 'HUSBAND';
                          else {
                            const fn = (member.firstName || member.name || '').trim().split(' ')[0].toLowerCase();
                            if (/(a|i|ee|ita|ika|shree|priya|devi|bai|ben)$/i.test(fn)) relLabel = 'WIFE';
                          }
                        }
                        const dobVal = member.dob || member.dateOfBirth || '';
                        const ageVal = member.age || (dobVal ? calculateAge(dobVal) : '');
                        const mainPersonPhone = (personalFields.whatsappNumber || personalFields.callingNumber || loadedContact?.phone || '').trim();
                        let phoneVal = (member.whatsapp && !member.whatsapp.startsWith('00') && member.whatsapp !== '0000000000')
                          ? member.whatsapp
                          : (member.whatsappNumber || member.phone || member.contactNo || member.callingNumber || member.alternatePhone || '');
                        if (phoneVal.startsWith('00') || phoneVal === '0000000000' || phoneVal.toLowerCase().includes('unknown')) phoneVal = '';
                        if (!phoneVal && member.isDependent) {
                          phoneVal = (member.dependentNo && !member.dependentNo.startsWith('00') && member.dependentNo !== '0000000000')
                            ? member.dependentNo
                            : (member.guardianWhatsapp && !member.guardianWhatsapp.startsWith('00') && member.guardianWhatsapp !== '0000000000')
                            ? member.guardianWhatsapp
                            : mainPersonPhone;
                        }
                        const pDigits = (phoneVal || '').replace(/\D/g, '');
                        if (pDigits.length > 10 && !pDigits.startsWith('00')) {
                          phoneVal = pDigits.slice(-10);
                        }
                        const addressVal = [member.city, member.state].filter(Boolean).join(', ');
                        const declaredCount = (member.declaredMedicalHistory || member.medicalHistory || []).length;

                        const isSpouse = ['SPOUSE', 'HUSBAND', 'WIFE'].includes(rel);
                        const isChild = ['SON', 'DAUGHTER', 'CHILD', 'GRANDSON', 'GRANDDAUGHTER', 'GRANDCHILD', 'NEPHEW', 'NIECE'].includes(rel);
                        const isParent = ['FATHER', 'MOTHER', 'PARENT', 'GRANDFATHER', 'GRANDMOTHER', 'GRANDPARENT', 'UNCLE', 'AUNT'].includes(rel);

                        const cardBorder = isSpouse
                          ? 'border-purple-200 hover:border-purple-300'
                          : isChild
                          ? 'border-emerald-200 hover:border-emerald-300'
                          : isParent
                          ? 'border-amber-200 hover:border-amber-300'
                          : 'border-blue-200 hover:border-blue-300';

                        const headerGradient = isSpouse
                          ? 'from-purple-600 to-indigo-700'
                          : isChild
                          ? 'from-emerald-600 to-teal-700'
                          : isParent
                          ? 'from-amber-600 to-orange-700'
                          : 'from-blue-600 to-slate-700';

                        return (
                          <div
                            key={idx}
                            tabIndex={0}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') {
                                e.preventDefault();
                                e.stopPropagation();
                                if (e.ctrlKey || e.metaKey) {
                                  if (member.contactId) {
                                    openContactInNewTab(member.contactId, {
                                      parentContactId: editContactId || loadedContact?.id,
                                      returnTab: 'Family',
                                    });
                                  } else {
                                    const contactId = editContactId || loadedContact?.id;
                                    if (contactId) {
                                      openFamilyMemberInNewTab(contactId, idx, {
                                        parentContactId: contactId,
                                        returnTab: 'Family',
                                      });
                                    }
                                  }
                                } else {
                                  if (member.contactId) {
                                    navigateToContact({ id: member.contactId, contactId: member.contactId });
                                  } else {
                                    openEditFamilyMemberModal(idx);
                                  }
                                }
                              }
                            }}
                            className={`overflow-hidden rounded-2xl border ${cardBorder} bg-white shadow-xs hover:shadow-md transition-all relative outline-none focus-within:ring-2 focus-within:ring-blue-400`}
                          >
                            {/* Card Header (Clicking card opens family member in same tab; Ctrl+Click or Ctrl+Enter opens in new tab) */}
                            <div
                              onClick={(e) => {
                                e.stopPropagation();
                                if (e.ctrlKey || e.metaKey) {
                                  if (member.contactId) {
                                    openContactInNewTab(member.contactId, {
                                      parentContactId: editContactId || loadedContact?.id,
                                      returnTab: 'Family',
                                    });
                                  } else {
                                    const contactId = editContactId || loadedContact?.id;
                                    if (contactId) {
                                      openFamilyMemberInNewTab(contactId, idx, {
                                        parentContactId: contactId,
                                        returnTab: 'Family',
                                      });
                                    }
                                  }
                                  return;
                                }
                                if (member.contactId) {
                                  navigateToContact({ id: member.contactId, contactId: member.contactId });
                                } else {
                                  openEditFamilyMemberModal(idx);
                                }
                              }}
                              className={`flex items-center justify-between bg-gradient-to-r ${headerGradient} px-4 py-3 cursor-pointer select-none`}
                              title="Click to view full contact profile with all tabs in same tab (Ctrl+Click or Ctrl+Enter to open in new tab)"
                            >
                              <div className="flex items-center gap-3 min-w-0 flex-1">
                                <div className="w-7 h-7 rounded-lg bg-white/20 backdrop-blur-sm flex items-center justify-center text-white shrink-0 font-black text-xs">
                                  {idx + 1}
                                </div>
                                <div className="min-w-0 flex-1">
                                  <div className="flex flex-wrap items-center gap-2">
                                    <span className="px-2 py-0.5 rounded-full bg-white/20 text-white font-black text-[10px] tracking-wider uppercase">
                                      {relLabel}
                                    </span>
                                    <h4 className="text-white font-extrabold text-xs sm:text-sm truncate">
                                      {fullName}
                                    </h4>
                                  </div>
                                  <div className="flex flex-wrap items-center gap-3 text-white/80 text-[11px] font-medium mt-0.5">
                                    {ageVal ? <span>Age: <strong className="text-white">{ageVal} yrs</strong></span> : null}
                                    {dobVal ? <span>DOB: <strong className="text-white">{dobVal}</strong></span> : null}
                                    {member.gender ? <span>Gender: <strong className="text-white">{member.gender}</strong></span> : null}
                                  </div>
                                </div>
                              </div>

                              {/* Actions on Card Header */}
                              <div className="flex items-center gap-1.5 shrink-0 ml-2" onClick={e => e.stopPropagation()}>
                                {member.contactId && (
                                  <button
                                    type="button"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      if (e.ctrlKey || e.metaKey) {
                                        openContactInNewTab(member.contactId, {
                                          parentContactId: editContactId || loadedContact?.id,
                                          returnTab: 'Family',
                                        });
                                        return;
                                      }
                                      navigateToContact({ id: member.contactId, contactId: member.contactId });
                                    }}
                                    onKeyDown={(e) => {
                                      if (e.key === 'Enter') {
                                        e.preventDefault();
                                        e.stopPropagation();
                                        if (e.ctrlKey || e.metaKey) {
                                          openContactInNewTab(member.contactId, {
                                            parentContactId: editContactId || loadedContact?.id,
                                            returnTab: 'Family',
                                          });
                                        } else {
                                          navigateToContact({ id: member.contactId, contactId: member.contactId });
                                        }
                                      }
                                    }}
                                    className="px-2.5 py-1 rounded-lg bg-white/20 hover:bg-white/30 text-white font-bold text-[10px] flex items-center gap-1 transition-all cursor-pointer"
                                    title="Open this family member's direct Contact Form in same tab (Ctrl+Click or Ctrl+Enter to open in new tab)"
                                  >
                                    <ExternalLink size={12} />
                                    <span className="hidden sm:inline">Open Contact</span>
                                  </button>
                                )}
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    if (e.ctrlKey || e.metaKey) {
                                      e.preventDefault();
                                      if (member.contactId) {
                                        openContactInNewTab(member.contactId, {
                                          parentContactId: editContactId || loadedContact?.id,
                                          returnTab: 'Family',
                                        });
                                      } else {
                                        const contactId = editContactId || loadedContact?.id;
                                        if (contactId) openFamilyMemberInNewTab(contactId, idx);
                                      }
                                      return;
                                    }
                                    openEditFamilyMemberModal(idx);
                                  }}
                                  onKeyDown={(e) => {
                                    if (e.key === 'Enter') {
                                      if (e.ctrlKey || e.metaKey) {
                                        e.preventDefault();
                                        e.stopPropagation();
                                        if (member.contactId) {
                                          openContactInNewTab(member.contactId, {
                                            parentContactId: editContactId || loadedContact?.id,
                                            returnTab: 'Family',
                                          });
                                        } else {
                                          const contactId = editContactId || loadedContact?.id;
                                          if (contactId) openFamilyMemberInNewTab(contactId, idx);
                                        }
                                        return;
                                      }
                                    }
                                  }}
                                  className="p-1.5 rounded-lg bg-white/15 hover:bg-white/30 text-white font-bold text-xs flex items-center gap-1 transition-all cursor-pointer"
                                  title="Edit Family Member Details in Popup (Ctrl+Click or Ctrl+Enter to open full profile in new tab)"
                                >
                                  <Pencil size={13} />
                                  <span className="text-[11px]">Edit</span>
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleDeleteFamilyMember(idx)}
                                  className="p-1.5 rounded-lg bg-white/15 hover:bg-red-500 text-white transition-all cursor-pointer"
                                  title="Remove Member"
                                >
                                  <Trash2 size={13} />
                                </button>
                              </div>
                            </div>

                            {/* Card Body Summary */}
                            <div
                              onClick={(e) => {
                                e.stopPropagation();
                                if (e.ctrlKey || e.metaKey) {
                                  if (member.contactId) {
                                    openContactInNewTab(member.contactId, {
                                      parentContactId: editContactId || loadedContact?.id,
                                      returnTab: 'Family',
                                    });
                                  } else {
                                    const contactId = editContactId || loadedContact?.id;
                                    if (contactId) {
                                      openFamilyMemberInNewTab(contactId, idx, {
                                        parentContactId: contactId,
                                        returnTab: 'Family',
                                      });
                                    }
                                  }
                                  return;
                                }
                                if (member.contactId) {
                                  navigateToContact({ id: member.contactId, contactId: member.contactId });
                                } else {
                                  openEditFamilyMemberModal(idx);
                                }
                              }}
                              className="p-3.5 bg-slate-50/40 hover:bg-slate-50/80 transition-colors cursor-pointer grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs text-slate-600"
                              title="Click to view full contact profile with all tabs in same tab (Ctrl+Click or Ctrl+Enter to open in new tab)"
                            >
                              <div>
                                <span className="text-[10px] uppercase font-bold text-slate-400 block mb-0.5">Contact</span>
                                <p className="font-semibold text-slate-800 flex items-center gap-1.5 truncate">
                                  <Phone size={12} className="text-blue-500 shrink-0" />
                                  {phoneVal || <span className="text-slate-400 font-normal">Not specified</span>}
                                </p>
                                {member.email && (
                                  <p className="text-[11px] text-slate-500 truncate mt-0.5">
                                    {member.email}
                                  </p>
                                )}
                              </div>

                              <div>
                                <span className="text-[10px] uppercase font-bold text-slate-400 block mb-0.5">Occupation &amp; Income</span>
                                <p className="font-semibold text-slate-800 truncate">
                                  {member.occupation || member.occupationType || 'Not specified'}
                                </p>
                                {(member.companyName || member.annualIncome) && (
                                  <p className="text-[11px] text-slate-500 truncate mt-0.5">
                                    {member.companyName ? member.companyName : ''} {member.annualIncome ? `• ₹${member.annualIncome}` : ''}
                                  </p>
                                )}
                              </div>

                              <div>
                                <span className="text-[10px] uppercase font-bold text-slate-400 block mb-0.5">Health &amp; Medical</span>
                                {declaredCount > 0 ? (
                                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-blue-50 text-blue-700 border border-blue-200 text-[11px] font-bold">
                                    <Shield size={11} className="text-blue-600" />
                                    {declaredCount} condition{declaredCount > 1 ? 's' : ''} declared
                                  </span>
                                ) : (
                                  <span className="text-[11px] text-slate-400 font-medium">
                                    No medical conditions declared
                                  </span>
                                )}
                                {addressVal && (
                                  <p className="text-[11px] text-slate-500 truncate mt-1">
                                    📍 {addressVal}
                                  </p>
                                )}
                              </div>
                            </div>
                          </div>
                        );
                      })}

                      {/* Add Another Member Button */}
                      <button
                        type="button"
                        onClick={(e) => {
                          if (e.ctrlKey || e.metaKey) {
                            e.preventDefault();
                            const contactId = editContactId || loadedContact?.id;
                            if (contactId) openFamilyMemberInNewTab(contactId);
                            return;
                          }
                          openAddFamilyMemberModal();
                        }}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
                            e.preventDefault();
                            e.stopPropagation();
                            const contactId = editContactId || loadedContact?.id;
                            if (contactId) openFamilyMemberInNewTab(contactId);
                          }
                        }}
                        className="w-full mt-2 py-3 rounded-2xl border-2 border-dashed border-blue-300 hover:border-blue-500 bg-blue-50/40 hover:bg-blue-50 text-blue-600 hover:text-blue-700 text-xs font-extrabold flex items-center justify-center gap-2 transition-all cursor-pointer group"
                        title="Add Another Family Member in same tab (Ctrl+Click or Ctrl+Enter to open in new tab)"
                      >
                        <Plus size={15} />
                        + Add Another Family Member
                      </button>
                    </div>
                  )}
                </div>
              </div>
            )}

            {activeLeadTab === 'Policy' && (() => {
              // Collect all connected family contact IDs
              const connectedContactIds = new Set<string>();
              if (loadedContact?.id) connectedContactIds.add(String(loadedContact.id));
              if (loadedContact?.contactId) connectedContactIds.add(String(loadedContact.contactId));
              if (editContactId) connectedContactIds.add(String(editContactId));

              (loadedContact?.relatedTo || []).forEach((r: any) => {
                if (r.primaryContactId) connectedContactIds.add(String(r.primaryContactId));
                if (r.primaryContact?.id) connectedContactIds.add(String(r.primaryContact.id));
              });

              (loadedContact?.relationships || []).forEach((r: any) => {
                if (r.relatedContactId) connectedContactIds.add(String(r.relatedContactId));
                if (r.relatedContact?.id) connectedContactIds.add(String(r.relatedContact.id));
                if (r.primaryContactId) connectedContactIds.add(String(r.primaryContactId));
                if (r.primaryContact?.id) connectedContactIds.add(String(r.primaryContact.id));
              });

              familyMembers.forEach((m: any) => {
                if (m.contactId) connectedContactIds.add(String(m.contactId));
                if (m.id) connectedContactIds.add(String(m.id));
              });

              const direct = loadedContact?.policies || [];
              const mappedFromPolicyMap = Array.from(connectedContactIds).flatMap(cid => policyMap[cid] || []);

              // Also match by contact full name & contact number in policyListArray
              const contactFullName = [
                loadedContact?.firstName || personalFields?.firstName || '',
                loadedContact?.middleName || personalFields?.middleName || '',
                loadedContact?.lastName || personalFields?.lastName || ''
              ].filter(Boolean).join(' ').trim().toLowerCase();

              const contactPhone = (
                loadedContact?.phone ||
                personalFields?.whatsappNumber ||
                personalFields?.callingNumber ||
                ''
              ).replace(/\D/g, '').slice(-10);

              // Gather connected family members' full names & contact numbers
              const familyClusters: Array<{ fullName: string; phone: string }> = [];
              if (contactFullName && contactPhone && contactPhone.length >= 7) {
                familyClusters.push({ fullName: contactFullName, phone: contactPhone });
              }
              familyMembers.forEach((m: any) => {
                const famFullName = (
                  m.name ||
                  [m.firstName, m.middleName, m.lastName].filter(Boolean).join(' ')
                ).trim().toLowerCase();
                const famPhone = (m.phone || m.mobile || m.contactNo || '').replace(/\D/g, '').slice(-10);
                if (famFullName && famPhone && famPhone.length >= 7) {
                  familyClusters.push({ fullName: famFullName, phone: famPhone });
                }
              });

              const matchedFromAllPolicies = policyListArray.filter((p: any) => {
                const pContactId = String(p.contactId || p.contact?.id || p.contact?.contactId || '');
                if (pContactId && connectedContactIds.has(pContactId)) return true;

                if (Array.isArray(p.members)) {
                  const hasMemberId = p.members.some((m: any) => m.contactId && connectedContactIds.has(String(m.contactId)));
                  if (hasMemberId) return true;
                }

                // Match ONLY when BOTH full name AND contact number match together
                const pContactFullName = [
                  p.contact?.firstName || '',
                  p.contact?.middleName || '',
                  p.contact?.lastName || ''
                ].filter(Boolean).join(' ').trim().toLowerCase();
                const pPhone = String(p.contact?.phone || '').replace(/\D/g, '').slice(-10);

                if (contactFullName && contactPhone && contactPhone.length >= 7) {
                  if (pContactFullName === contactFullName && pPhone === contactPhone) {
                    return true;
                  }
                }

                if (familyClusters.length > 0 && pContactFullName && pPhone && pPhone.length >= 7) {
                  const matchesFamily = familyClusters.some(fc => fc.fullName === pContactFullName && fc.phone === pPhone);
                  if (matchesFamily) return true;
                }

                return false;
              });

              const combined = [...direct, ...mappedFromPolicyMap, ...matchedFromAllPolicies];
              const uniqueMap = new Map();
              combined.forEach(p => { if (p && p.id) uniqueMap.set(p.id, p); });
              const displayedPolicies = Array.from(uniqueMap.values());

              const isPolicyActive = (p: any) => {
                const statusUpper = (p.status || 'ACTIVE').toUpperCase();
                if (['EXPIRED', 'LAPSED', 'CANCELLED', 'INACTIVE'].includes(statusUpper)) {
                  return false;
                }
                if (p.endDate && new Date(p.endDate) < new Date()) {
                  return false;
                }
                return true;
              };

              const activePolicies = displayedPolicies.filter(isPolicyActive);
              const historicalPolicies = displayedPolicies.filter(p => !isPolicyActive(p));

              const renderPolicyCard = (policy: any) => {
                const isExpanded = !!expandedPolicyIds[policy.id];
                const type = (policy.plan?.category || 'OTHER').toUpperCase();
                const typeLabel = type === 'HEALTH' ? 'Health' : type === 'LIFE' ? 'Life' : type.charAt(0) + type.slice(1).toLowerCase();
                const isActive = isPolicyActive(policy);
                const displayStatus = policy.status || (isActive ? 'ACTIVE' : 'EXPIRED');
                const borderTone = isActive
                  ? (type === 'HEALTH' ? 'border-emerald-200' : type === 'LIFE' ? 'border-blue-200' : 'border-slate-200')
                  : 'border-amber-200 opacity-90';
                const headerTone = isActive
                  ? (type === 'HEALTH' ? 'from-emerald-500 to-teal-600' : type === 'LIFE' ? 'from-blue-500 to-indigo-600' : 'from-slate-600 to-slate-700')
                  : 'from-amber-600 to-orange-700';
                const statusTone = isActive ? 'bg-emerald-50 text-emerald-700 border-emerald-100' : 'bg-amber-50 text-amber-700 border-amber-100';

                return (
                  <div
                    key={policy.id}
                    className={`overflow-hidden rounded-2xl border ${borderTone} bg-white shadow-sm hover:shadow-md hover:border-blue-300 transition-all pointer-events-auto relative z-10`}
                  >
                    {/* Header / Minimized Summary Bar (Clicking card opens Policy Form in View Mode) */}
                    <div
                      onClick={(e) => {
                        e.stopPropagation();
                        if (e.ctrlKey || e.metaKey) {
                          const contactId = editContactId || loadedContact?.id;
                          if (contactId && policy?.id) {
                            openPolicyInNewTab(contactId, policy.id);
                          }
                          return;
                        }
                        if (policy) {
                          setPolicyToEdit(policy);
                          setCreatePolicyModalOpen(true);
                        }
                      }}
                      className={`flex items-center justify-between bg-gradient-to-r ${headerTone} px-4 py-3 cursor-pointer select-none`}
                      title="Click to open Policy Form in View Mode (Ctrl+Click to open in new tab)"
                    >
                      <div className="flex items-center gap-3 min-w-0 flex-1">
                        <div className="w-8 h-8 rounded-xl bg-white/15 backdrop-blur-sm flex items-center justify-center text-white shrink-0">
                          <Shield size={16} />
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="text-[10px] font-black uppercase tracking-[0.22em] text-white/80">{typeLabel}</span>
                            <span className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wide border ${statusTone}`}>{displayStatus}</span>
                          </div>
                          <p className="text-white font-extrabold text-sm truncate mt-0.5">{policy.policyNumber || 'Policy Number'}</p>
                        </div>
                      </div>

                      {/* Expand / Collapse toggle button for inline card summary */}
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setExpandedPolicyIds(prev => ({ ...prev, [policy.id]: !prev[policy.id] }));
                        }}
                        className="p-1.5 rounded-xl bg-white/15 hover:bg-white/25 backdrop-blur-sm text-white transition-all cursor-pointer shrink-0 ml-1.5"
                        title={isExpanded ? 'Collapse inline summary' : 'Expand inline summary'}
                      >
                        {isExpanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                      </button>
                    </div>

                    {/* Expanded Details Section */}
                    {isExpanded && (
                      <div className="p-4 space-y-4 border-t border-slate-100 bg-slate-50/40">
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          <div className="rounded-xl bg-white p-3 border border-slate-100 shadow-2xs">
                            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Company</p>
                            <p className="text-xs font-bold text-slate-800 truncate mt-0.5">{policy.plan?.company?.name || policy.plan?.name || 'Insurance Co.'}</p>
                          </div>
                          <div className="rounded-xl bg-white p-3 border border-slate-100 shadow-2xs">
                            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Plan</p>
                            <p className="text-xs font-bold text-slate-800 truncate mt-0.5">{policy.plan?.name || 'Standard Plan'}</p>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-slate-600">
                          <div className="rounded-xl border border-slate-100 bg-white p-2.5 shadow-2xs">
                            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Sum Assured</p>
                            <p className="text-xs font-extrabold text-slate-900 mt-0.5">₹{(policy.sumAssured || 0).toLocaleString('en-IN')}</p>
                          </div>
                          <div className="rounded-xl border border-slate-100 bg-white p-2.5 shadow-2xs">
                            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Premium</p>
                            <p className="text-xs font-extrabold text-emerald-700 mt-0.5">₹{(policy.premiumAmount || 0).toLocaleString('en-IN')}</p>
                          </div>
                          <div className="rounded-xl border border-slate-100 bg-white p-2.5 shadow-2xs">
                            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Frequency</p>
                            <p className="text-xs font-bold text-slate-700 mt-0.5">{policy.paymentFrequency || 'Yearly'}</p>
                          </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-slate-600">
                          <div className="flex flex-wrap items-center gap-2 rounded-xl border border-slate-100 bg-white p-2.5 shadow-2xs">
                            <Calendar size={13} className="text-slate-400 shrink-0" />
                            <div>
                              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Start</p>
                              <p className="text-xs font-semibold text-slate-700">{policy.startDate ? new Date(policy.startDate).toLocaleDateString('en-IN') : '—'}</p>
                            </div>
                          </div>
                          <div className="flex flex-wrap items-center gap-2 rounded-xl border border-slate-100 bg-slate-50/70 px-3 py-2.5">
                            <Calendar size={13} className="text-slate-400 shrink-0" />
                            <div>
                              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">End</p>
                              <p className="text-xs font-semibold text-slate-700">{policy.endDate ? new Date(policy.endDate).toLocaleDateString('en-IN') : '—'}</p>
                            </div>
                          </div>
                        </div>

                        {/* Connected Persons / Covered Members on this Policy */}
                        {(() => {
                          const pMembers: any[] = [];
                          const seenPM = new Set<string>();
                          if (Array.isArray(policy.members)) {
                            policy.members.forEach((m: any) => {
                              const name = (m.name || `${m.firstName || ''} ${m.lastName || ''}`).trim();
                              if (name && !seenPM.has(name.toLowerCase())) {
                                seenPM.add(name.toLowerCase());
                                pMembers.push({
                                  id: m.id,
                                  name,
                                  relationship: m.relationship || 'Member',
                                  phone: m.phone || m.contactNo || '',
                                });
                              }
                            });
                          }
                          if (policy.notes) {
                            policy.notes.split('\n').forEach((line: string, i: number) => {
                              if (line.startsWith('Connected Person')) {
                                const nameM = line.match(/Name:\s*([^,]+)/);
                                const relM = line.match(/Relationship:\s*([^,]+)/);
                                const contactM = line.match(/Contact:\s*([^,]+)/);
                                if (nameM) {
                                  const name = nameM[1].trim();
                                  if (name && !seenPM.has(name.toLowerCase())) {
                                    seenPM.add(name.toLowerCase());
                                    pMembers.push({
                                      id: `note-m-${i}`,
                                      name,
                                      relationship: relM ? relM[1].trim() : 'Member',
                                      phone: contactM && contactM[1].trim() !== 'N/A' ? contactM[1].trim() : '',
                                    });
                                  }
                                }
                              }
                            });
                          }
                          if (pMembers.length === 0 && Array.isArray(familyMembers) && familyMembers.length > 0) {
                            familyMembers.forEach((fm: any, i: number) => {
                              const name = (fm.name || `${fm.firstName || ''} ${fm.lastName || ''}`).trim();
                              if (name && !seenPM.has(name.toLowerCase())) {
                                seenPM.add(name.toLowerCase());
                                pMembers.push({
                                  id: fm.id || fm.contactId || `fm-${i}`,
                                  name,
                                  relationship: fm.relation || fm.relationship || 'Member',
                                  phone: fm.phone || fm.contactNo || fm.whatsapp || '',
                                });
                              }
                            });
                          }
                          if (pMembers.length === 0 && Array.isArray(loadedContact?.relationships) && loadedContact.relationships.length > 0) {
                            loadedContact.relationships.forEach((rel: any, i: number) => {
                              const target = rel.relatedContact || rel.contact || rel;
                              const name = (target?.name || `${target?.firstName || ''} ${target?.lastName || ''}`).trim();
                              if (name && !seenPM.has(name.toLowerCase())) {
                                seenPM.add(name.toLowerCase());
                                pMembers.push({
                                  id: target?.id || rel.id || `rel-${i}`,
                                  name,
                                  relationship: rel.relationshipType || rel.relation || target?.relation || 'Member',
                                  phone: target?.phone || target?.contactNo || '',
                                });
                              }
                            });
                          }
                          if (pMembers.length === 0) return null;
                          return (
                            <div className="rounded-xl border border-blue-100 bg-blue-50/30 p-2.5 shadow-2xs">
                              <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                                <Users size={12} className="text-blue-600" /> Connected Persons ({pMembers.length})
                              </p>
                              <div className="flex flex-wrap gap-2">
                                {pMembers.map((m, mIdx) => (
                                  <div
                                    key={m.id || mIdx}
                                    className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-white border border-slate-200 shadow-2xs text-xs font-semibold text-slate-800"
                                  >
                                    <span>{m.name}</span>
                                    {m.relationship && (
                                      <span className="text-[9px] font-black uppercase tracking-wider px-1.5 py-0.5 rounded bg-blue-100 text-blue-700">
                                        {m.relationship}
                                      </span>
                                    )}
                                    {m.phone && (
                                      <span className="text-[10px] text-slate-400 font-normal">
                                        · {m.phone}
                                      </span>
                                    )}
                                  </div>
                                ))}
                              </div>
                            </div>
                          );
                        })()}

                        <div className="flex justify-end pt-2 border-t border-slate-200/80 mt-2">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              if (e.ctrlKey || e.metaKey) {
                                const contactId = editContactId || loadedContact?.id;
                                if (contactId && policy?.id) {
                                  openPolicyInNewTab(contactId, policy.id);
                                }
                                return;
                              }
                              if (policy) {
                                setPolicyToEdit(policy);
                                setCreatePolicyModalOpen(true);
                              }
                            }}
                            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-blue-600 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors cursor-pointer"
                            title="Open Policy Form (Ctrl+Click to open in new tab)"
                          >
                            <FileText size={13} /> Open Policy Form
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                );
              };

              return (
                <div className="h-full flex flex-col">
                  {/* Action buttons */}
                  <div className="flex items-center justify-between gap-3 mb-3 flex-shrink-0">
                    <p className="text-[11px] text-slate-500 font-semibold">
                      Policies are created in the main policy form and will appear here after saving.
                    </p>
                    <button
                      type="button"
                      onClick={(e) => {
                        const contactId = editContactId || loadedContact?.id;
                        if (!contactId) {
                          toast.error('Please save the contact details first before adding a policy.');
                          return;
                        }
                        if (e.ctrlKey || e.metaKey) {
                          openPolicyInNewTab(contactId);
                          return;
                        }
                        setPolicyToEdit(null);
                        setCreatePolicyModalOpen(true);
                      }}
                      className="flex items-center justify-center gap-2 px-4 py-2.5 border-2 border-blue-400 text-blue-600 text-xs font-semibold rounded-lg hover:bg-blue-50 cursor-pointer transition-colors"
                      title="Add New Policy (Ctrl+Click to open in new tab)"
                    >
                      + Add New Policy
                    </button>
                  </div>

                  <div className="space-y-5 mb-3 overflow-y-auto max-h-[60vh] custom-scrollbar pr-1">
                    {displayedPolicies.length === 0 ? (
                      <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-slate-200 bg-slate-50/60 px-6 py-10 text-center min-h-[180px]">
                        <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mb-3">
                          <FileText size={18} />
                        </div>
                        <p className="text-sm font-bold text-slate-700">No policies linked yet</p>
                        <p className="text-[11px] text-slate-500 mt-1 max-w-[280px]">
                          Add a policy from the main policy form and it will show up here as a summary card.
                        </p>
                      </div>
                    ) : (
                      <>
                        {/* Active Policies Section */}
                        {activePolicies.length > 0 && (
                          <div className="space-y-2.5">
                            <div className="flex items-center gap-2 px-1">
                              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 shrink-0" />
                              <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                                Active / Current Policies ({activePolicies.length})
                              </h4>
                            </div>
                            <div className="grid gap-3">
                              {activePolicies.map(renderPolicyCard)}
                            </div>
                          </div>
                        )}

                        {/* Historical / Expired Policies Section */}
                        {historicalPolicies.length > 0 && (
                          <div className="space-y-2.5 pt-2">
                            <div className="flex items-center gap-2 px-1">
                              <span className="w-2.5 h-2.5 rounded-full bg-amber-500 shrink-0" />
                              <h4 className="text-xs font-bold text-slate-600 uppercase tracking-wider">
                                Historical / Expired Policies ({historicalPolicies.length})
                              </h4>
                            </div>
                            <div className="grid gap-3">
                              {historicalPolicies.map(renderPolicyCard)}
                            </div>
                          </div>
                        )}
                      </>
                    )}
                  </div>
                </div>
              );
            })()}


            {activeLeadTab === 'Claims' && (() => {
              // 1. Gather all policy IDs for current contact
              const directPolicies = loadedContact?.policies || [];
              const mapPol1 = loadedContact?.id ? (policyMap[loadedContact.id] || []) : [];
              const mapPol2 = loadedContact?.contactId ? (policyMap[loadedContact.contactId] || []) : [];
              const mapPol3 = editContactId ? (policyMap[editContactId] || []) : [];
              const contactPolicyIds = new Set(
                [...directPolicies, ...mapPol1, ...mapPol2, ...mapPol3]
                  .map((p: any) => p?.id)
                  .filter(Boolean)
              );

              const contactPhone = (
                loadedContact?.phone ||
                personalFields?.callingNumber ||
                personalFields?.whatsappNumber ||
                ''
              ).trim();

              const contactFullName = [
                loadedContact?.firstName || personalFields?.firstName || '',
                loadedContact?.middleName || personalFields?.middleName || '',
                loadedContact?.lastName || personalFields?.lastName || ''
              ].filter(Boolean).join(' ').trim().toLowerCase();

              // 2. Direct contact claims & mapped claims
              const directClaims = loadedContact?.claims || [];
              const mapClaim1 = loadedContact?.id ? (claimMap[loadedContact.id] || []) : [];
              const mapClaim2 = loadedContact?.contactId ? (claimMap[loadedContact.contactId] || []) : [];
              const mapClaim3 = editContactId ? (claimMap[editContactId] || []) : [];

              // 3. Additional policy, phone & name matching across all loaded claims
              const matchedByPolicyOrPhone = claimListArray.filter((c: any) => {
                if (c?.policyId && contactPolicyIds.has(c.policyId)) return true;
                if (c?.policy?.id && contactPolicyIds.has(c.policy.id)) return true;

                const claimFullName = [
                  c?.contact?.firstName || '',
                  c?.contact?.middleName || '',
                  c?.contact?.lastName || ''
                ].filter(Boolean).join(' ').trim().toLowerCase();
                const claimPhone = String(c?.contact?.phone || c?.phone || '').replace(/\D/g, '').slice(-10);

                if (contactFullName && contactPhone && contactPhone.length >= 7) {
                  if (claimFullName === contactFullName && claimPhone === contactPhone) return true;
                }

                return false;
              });

              const uniqueClaimsMap = new Map();
              [...directClaims, ...mapClaim1, ...mapClaim2, ...mapClaim3, ...matchedByPolicyOrPhone].forEach(c => {
                if (c && c.id) uniqueClaimsMap.set(c.id, c);
              });
              const displayedContactClaims = Array.from(uniqueClaimsMap.values());

              return (
                <div className="space-y-4">
                  {/* Claims Tab Header */}
                  <div className="flex items-center justify-between">
                    <div className="flex flex-wrap items-center gap-2">
                      <div className="w-6 h-6 rounded-lg bg-blue-100 text-blue-600 flex items-center justify-center shrink-0">
                        <FileText size={13} />
                      </div>
                      <h3 className="text-xs font-black text-slate-700 uppercase tracking-wider">
                        Claims History & Log
                      </h3>
                    </div>
                    {editContactId && (
                      <span className="text-[10px] font-extrabold bg-blue-50 text-blue-700 border border-blue-100 px-2.5 py-0.5 rounded-full">
                        {displayedContactClaims.length} {displayedContactClaims.length === 1 ? 'Claim' : 'Claims'}
                      </span>
                    )}
                  </div>

                  {!editContactId ? (
                    <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-slate-200 bg-slate-50/60 px-6 py-10 text-center">
                      <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mb-3">
                        <FileText size={18} />
                      </div>
                      <p className="text-sm font-bold text-slate-700">Save Contact First</p>
                      <p className="text-[11px] text-slate-500 mt-1 max-w-[280px]">
                        Please save the contact details first to view and manage claims associated with this contact.
                      </p>
                    </div>
                  ) : displayedContactClaims.length === 0 ? (
                    <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-slate-200 bg-slate-50/60 px-6 py-10 text-center">
                      <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mb-3">
                        <FileText size={18} />
                      </div>
                      <p className="text-sm font-bold text-slate-700">No Claims Found</p>
                      <p className="text-[11px] text-slate-500 mt-1 max-w-[280px]">
                        No active or historical claims filed for this contact yet.
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-3 max-h-[420px] overflow-y-auto pr-1 custom-scrollbar">
                      {displayedContactClaims.map((cl: any) => (
                        <div
                          key={cl.id}
                          role="button"
                          tabIndex={0}
                          onClick={() => setSelectedClaimDetail(cl)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter' || e.key === ' ') {
                              e.preventDefault();
                              setSelectedClaimDetail(cl);
                            }
                          }}
                          className="w-full text-left p-3.5 bg-white rounded-2xl border border-blue-300 shadow-2xs space-y-2 hover:border-blue-400 hover:shadow-sm transition-all cursor-pointer pointer-events-auto select-none group"
                          aria-label={`View claim ${cl.claimNumber || ''}`}
                        >
                          <div className="flex items-center justify-between">
                            <div>
                              <span className="text-[9px] font-black uppercase text-blue-600 tracking-wider bg-blue-50 px-1.5 py-0.5 rounded">
                                {cl.claimType}
                              </span>
                              <h4 className="text-xs font-bold text-slate-900 mt-1 group-hover:text-blue-600 transition-colors">{cl.claimNumber}</h4>
                              <p className="text-[10px] text-slate-400">Policy: {cl.policy?.policyNumber || 'N/A'}</p>
                            </div>
                            <div className="text-right">
                              <span className="px-2 py-0.5 rounded text-[9px] font-extrabold uppercase bg-blue-50 text-blue-700 border border-blue-200">
                                {cl.status}
                              </span>
                              <p className="text-xs font-extrabold text-slate-800 mt-1">₹{Number(cl.claimAmount || 0).toLocaleString('en-IN')}</p>
                            </div>
                          </div>
                          <p className="text-[10px] text-slate-400 border-t border-slate-100 pt-1.5 flex justify-between">
                            <span>Intimated: {cl.intimatedAt ? format(new Date(cl.intimatedAt), 'dd MMM yyyy') : '—'}</span>
                            <span>Approved: ₹{Number(cl.approvedAmount || 0).toLocaleString('en-IN')}</span>
                          </p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              );
            })()}

            {activeLeadTab === 'History' && (
              <ActivityTimeline
                events={[contactHistoryRes, loadedContact?.activityLogs]}
                fallbackEvents={[
                  ...(loadedContact?.createdAt ? [{
                    id: `contact-created-${loadedContact.id}`,
                    entityType: 'Contact',
                    entityId: loadedContact.id,
                    action: 'CREATE',
                    description: 'Contact profile created',
                    createdAt: loadedContact.createdAt,
                  }] : []),
                ]}
                entityType="Contact"
                entityId={historyContactId}
                isLoading={contactHistoryLoading}
                isError={contactHistoryError}
                subtitle="Unified timeline tracking changes across this contact and family members."
              />
            )}

            {activeLeadTab === 'Documents' && (() => {
              const currentContactDocId = editContactId || loadedContact?.id || loadedContact?.contactId;
              const contactPhoneNo = (
                loadedContact?.phone ||
                personalFields?.whatsappNumber ||
                personalFields?.callingNumber ||
                ''
              ).replace(/\D/g, '');

              return (
                <div className="space-y-4">
                  {/* Documents Tab Header */}
                  <div className="flex items-center justify-between">
                    <div className="flex flex-wrap items-center gap-2">
                      <div className="w-6 h-6 rounded-lg bg-indigo-100 text-indigo-600 flex items-center justify-center shrink-0">
                        <FileText size={13} />
                      </div>
                      <h3 className="text-xs font-black text-slate-700 uppercase tracking-wider">
                        Contact Documents & Files ({contactDocsList.length})
                      </h3>
                    </div>
                    {currentContactDocId && (
                      <button
                        type="button"
                        onClick={() => setContactDocUploadOpen(true)}
                        className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white text-xs font-bold shadow-md shadow-blue-500/20 transition-all hover:scale-[1.02] cursor-pointer"
                      >
                        <Upload size={13} />
                        <span>Upload Document</span>
                      </button>
                    )}
                  </div>

                  <DocumentUploadModal
                    open={contactDocUploadOpen}
                    onClose={() => setContactDocUploadOpen(false)}
                    onUpload={async (file: File, meta: DocumentUploadMeta) => {
                      if (!currentContactDocId) {
                        toast.error('Please save the contact first.');
                        return;
                      }
                      try {
                        await documentsService.upload(file, { contactId: String(currentContactDocId), ...meta });
                        await qc.invalidateQueries({ queryKey: ['contact-documents-list'] });
                        setContactDocUploadOpen(false);
                        toast.success('Document uploaded successfully!');
                        return true;
                      } catch (err: any) {
                        const message = err?.response?.data?.message;
                        toast.error(Array.isArray(message) ? message.join(', ') : message || 'Failed to upload document.');
                        return false;
                      }
                    }}
                    title="Upload Contact Document"
                    subtitle="Attach identity proof, policy bonds, or medical records for this contact."
                    defaultType="IDENTITY_PROOF"
                    types={CONTACT_DOC_TYPES}
                    zIndexClass="z-[70]"
                  />

                  {!currentContactDocId ? (
                    <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-slate-200 bg-slate-50/60 px-6 py-10 text-center">
                      <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center mb-3">
                        <FileText size={18} />
                      </div>
                      <p className="text-sm font-bold text-slate-700">Save Contact First</p>
                      <p className="text-[11px] text-slate-500 mt-1 max-w-[280px]">
                        Please save the contact details first before uploading and managing documents.
                      </p>
                    </div>
                  ) : (
                    <DocumentsTable
                      documents={contactDocsList}
                      onView={async doc => {
                        try {
                          const response = await documentsService.url(doc.id);
                          const url = response?.url || response?.data?.url || doc.url || doc.fileUrl;
                          if (!url) throw new Error('Unable to fetch preview link.');
                          setDocPreviewModal({ open: true, title: doc.name || doc.title || doc.originalName || 'Document', url });
                        } catch {
                          toast.error('Failed to preview document.');
                        }
                      }}
                      onDelete={async doc => {
                        if (!confirm('Are you sure you want to delete this document?')) return;
                        try {
                          await documentsService.remove(doc.id);
                          await qc.invalidateQueries({ queryKey: ['contact-documents-list'] });
                          toast.success('Document deleted');
                        } catch {
                          toast.error('Failed to delete document');
                        }
                      }}
                      onShare={async doc => {
                        try {
                          const response = await documentsService.url(doc.id);
                          const url = response?.url || response?.data?.url || doc.url || doc.fileUrl || '';
                          if (!url) throw new Error('Unable to fetch document link.');
                          const title = doc.name || doc.title || doc.originalName || 'Document';
                          const message = `Hi, here is the document: *${title}*\n${url}`;
                          const shareUrl = contactPhoneNo
                            ? `https://api.whatsapp.com/send?phone=91${contactPhoneNo.slice(-10)}&text=${encodeURIComponent(message)}`
                            : `https://api.whatsapp.com/send?text=${encodeURIComponent(message)}`;
                          window.open(shareUrl, '_blank');
                        } catch {
                          toast.error('Failed to prepare WhatsApp share link.');
                        }
                      }}
                    />
                  )}
                </div>
              );
            })()}
            </fieldset>
          </div>
        </form>

        <FamilyMemberModal
          open={familyMemberModalOpen}
          onClose={() => {
            setFamilyMemberModalOpen(false);
            setEditingFamilyMemberIdx(null);
            setSelectedFamilyMemberForModal(null);
          }}
          initialData={selectedFamilyMemberForModal}
          isEditing={editingFamilyMemberIdx !== null}
          primaryContact={{
            gender: personalFields.gender,
            phone: personalFields.whatsappNumber || personalFields.callingNumber || loadedContact?.phone || '',
            whatsappNumber: personalFields.whatsappNumber || loadedContact?.phone || '',
            state: personalFields.state,
            district: personalFields.district,
            city: personalFields.city,
            pincode: personalFields.pincode,
            streetAddress: personalFields.streetAddress,
            fullName: [personalFields.firstName, personalFields.middleName, personalFields.lastName].filter(Boolean).join(' ').trim(),
          }}
          employeesList={employeesList}
          onSave={handleSaveFamilyMemberFromModal}
        />
      </Modal>



      {/* Document Preview Modal */}
      <Modal
        open={docPreviewModal.open}
        onClose={() => setDocPreviewModal({ open: false, title: '', url: '' })}
        title={docPreviewModal.title || 'Document Preview'}
        size="2xl"
        zIndexClass="z-[70]"
        icon={<Eye className="text-blue-600" size={20} />}
      >
        <div className="space-y-3 py-1">
          <div className="w-full h-[65vh] rounded-xl border border-slate-200 bg-slate-50 overflow-hidden flex items-center justify-center">
            {docPreviewModal.url.match(/\.(jpg|jpeg|png|webp|gif)/i) ? (
              <img src={docPreviewModal.url} alt={docPreviewModal.title} className="max-h-full max-w-full object-contain" />
            ) : (
              <iframe src={docPreviewModal.url} className="w-full h-full border-0" title={docPreviewModal.title} />
            )}
          </div>
          <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
            <button
              type="button"
              onClick={() => window.open(docPreviewModal.url, '_blank')}
              className="px-4 py-2 text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white rounded-xl cursor-pointer shadow-md shadow-blue-500/20"
            >
              Open Original File
            </button>
          </div>
        </div>
      </Modal>

      {/* Import from Phone Directory Modal */}
      <Modal open={dirImportOpen} onClose={() => setDirImportOpen(false)} title="Import from Phone Directory">
        <div className="space-y-4">
          <p className="text-xs text-gray-500">
            Paste contacts below in the format: <span className="font-mono">First Name, Phone</span> (one per line).
          </p>
          <textarea
            className="input font-mono w-full text-xs"
            rows={8}
            placeholder="John Doe, 9876543210&#10;Jane Smith, 9876543211"
            value={dirText}
            onChange={e => setDirText(e.target.value)}
          />
          <div className="flex flex-wrap justify-end gap-2">
            <button type="button" className="btn-secondary text-[10px] sm:text-xs h-9" onClick={() => setDirImportOpen(false)}>Cancel</button>
            <button
              type="button"
              className="btn-primary text-[10px] sm:text-xs h-9"
              onClick={async () => {
                const lines = dirText.split('\n').filter(l => l.trim());
                const contactsToImport = lines.map(l => {
                  const parts = l.split(',');
                  const namePart = parts[0] || '';
                  const phonePart = parts[1] || '';
                  const nameTokens = namePart.trim().split(/\s+/);
                  const firstName = nameTokens[0] || '';
                  const lastName = nameTokens.slice(1).join(' ') || '';
                  return {
                    firstName,
                    lastName,
                    phone: phonePart.trim(),
                  };
                }).filter(c => c.firstName && c.phone);

                if (contactsToImport.length === 0) {
                  toast.error('No valid contacts found in import text');
                  return;
                }

                const toastId = toast.loading('Bulk importing directory...');
                try {
                  await contactsService.bulkImport({ contacts: contactsToImport });
                  toast.success('Contacts imported successfully!', { id: toastId });
                  setDirImportOpen(false);
                  setDirText('');
                  qc.invalidateQueries({ queryKey: ['contacts'] });
                } catch (err: any) {
                  toast.error(err.response?.data?.message || 'Bulk import failed', { id: toastId });
                }
              }}
            >
              Import
            </button>
          </div>
        </div>
      </Modal>

      <ContactDetailModal
        open={detailModalOpen}
        onClose={() => setDetailModalOpen(false)}
        contactId={selectedDetailId}
        onEditClick={(c) => {
          setDetailModalOpen(false);
          openEdit(c);
        }}
      />

      <PolicyDetailModal
        open={!!selectedPolicyModalId}
        policyId={selectedPolicyModalId}
        onClose={() => setSelectedPolicyModalId(null)}
      />

      <ClaimDetailModal
        open={!!selectedClaimDetail}
        claim={selectedClaimDetail}
        onClose={() => setSelectedClaimDetail(null)}
      />

      <CreatePolicyModal
        open={createPolicyModalOpen}
        policyToEdit={policyToEdit}
        onClose={() => {
          setPolicyToEdit(null);
          setCreatePolicyModalOpen(false);
          if (isDirectPolicyModalRef.current) {
            isDirectPolicyModalRef.current = false;
            setLoadedContact(null);
            setEditContactId(null);
            return;
          }
          qc.invalidateQueries({ queryKey: ['contacts-policies-list'] });
          qc.invalidateQueries({ queryKey: ['policies'] });
          if (editContactId) {
            qc.invalidateQueries({ queryKey: ['contact', editContactId] });
            setLeadModalOpen(true);
            setActiveLeadTab('Policy');
          }
        }}
        contactId={editContactId || loadedContact?.id}
        contactName={loadedContact ? [loadedContact.firstName, loadedContact.middleName, loadedContact.lastName].filter(Boolean).join(' ').trim() : undefined}
        initialData={{
          ...(loadedContact || {}),
          familyMembers: familyMembers.length > 0 ? familyMembers : (loadedContact?.relationships || []),
          relationships: loadedContact?.relationships || [],
        }}
        onSuccess={() => {
          setPolicyToEdit(null);
          refetchContacts();
          qc.invalidateQueries({ queryKey: ['contacts-policies-list'] });
          qc.invalidateQueries({ queryKey: ['policies'] });
          if (editContactId) {
            qc.invalidateQueries({ queryKey: ['contact', editContactId] });
          }
        }}
      />

      <ImportFormatModal
        open={importFormatOpen}
        onClose={() => setImportFormatOpen(false)}
        onChooseFile={() => fileInputRef.current?.click()}
        title="Import Contacts from CSV or Excel"
        description="Use one row per contact. Keep the column headers unchanged."
        warning="First Name and a unique 10-digit Customer Contact No. are required. Date of Birth uses YYYY-MM-DD or DD-MM-YYYY; declared medical conditions can be separated with commas or |."
        columns={CONTACT_IMPORT_COLUMNS}
        sampleRows={[CONTACT_IMPORT_SAMPLE_ROW]}
        fileFormats="CSV, XLS, and XLSX"
        sampleFileName="Import Format.xlsx"
        sampleFileType="xlsx"
        sheetName="Import Format"
      />

    </div>
  );
}
