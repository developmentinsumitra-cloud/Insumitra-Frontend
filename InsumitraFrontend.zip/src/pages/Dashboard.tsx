import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Users, Shield, FileText, TrendingUp, DollarSign, AlertCircle,
  RefreshCw, Plus, Calendar, ChevronRight, CheckCircle,
  Clock, UserPlus, Briefcase, PhoneCall, Star, Award, Settings,
  BarChart2, Activity, RotateCcw, FileCheck2
} from 'lucide-react';
import { format, isToday, isTomorrow, differenceInDays } from 'date-fns';
import {
  useDashboardKpis, useDashboardRevenue, useDashboardPortfolio,
  useDashboardPipeline, useDashboardDbSummary, useDashboardAnalytics
} from '@hooks/useDashboard';
import { useClaims } from '@hooks/useClaims';
import { LineChartWidget, PieChartWidget, BarChartWidget, CoverageBarChartWidget } from '@comps/common/Charts';
import { SkeletonCard, SkeletonChart, SkeletonTable } from '@comps/common/Skeleton';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useAuthStore } from '@store/auth.store';
import { claimsService, employeesService } from '@api/index';
import { DatePicker } from '@comps/common/DatePicker';
import { getClaimUiStatus, getClaimNotesData } from './Claims';
import clsx from 'clsx';

// ── Dashboard Mock Data ──────────────────────────────────────────────────────
const MOCK_ACTIVE_POLICIES = [
  { name: 'Health Insurance', value: 450 },
  { name: 'Life Insurance', value: 310 },
  { name: 'General Insurance', value: 240 },
];

const MOCK_CONTACTS = { total: 2090, male: 1150, female: 940, under18: 380, above60: 420 };

const MOCK_PREMIUM_BY_PLAN = [
  { name: 'Health', value: 4500000 },
  { name: 'Accident', value: 850000 },
  { name: 'Critical Illness', value: 1200000 },
  { name: 'Group Health', value: 3500000 },
  { name: 'Group PA', value: 950000 },
  { name: 'SME Health', value: 2800000 },
  { name: 'Term Life', value: 5200000 },
  { name: 'TULIP', value: 1800000 },
  { name: 'ULIP', value: 3200000 },
  { name: 'Endowment', value: 4100000 },
  { name: 'Moneyback', value: 2100000 },
  { name: 'Business', value: 1500000 },
  { name: 'MF', value: 2900000 },
  { name: 'Other', value: 650000 },
];

const MOCK_PERSONS_COVERED = [
  { name: 'Health', value: 80, total: 100 },
  { name: 'Term', value: 40, total: 100 },
  { name: 'Life', value: 65, total: 100 },
  { name: 'General', value: 45, total: 100 },
  { name: 'Other', value: 20, total: 100 },
];

const MOCK_MF_LEADS = {
  activeSipAmount: 150000,
  lumpsumAmount: 500000,
  investors: 120,
  activeSips: 85
};

const MOCK_BUSINESS_CATEGORY_WISE = [
  { month: 'Jan', health: 420000, accident: 120000, critical: 180000, groupHealth: 300000, groupPa: 150000, sme: 200000, termLife: 250000, tulip: 100000, ulip: 220000, endowment: 310000, moneyback: 190000, business: 140000, mf: 280000, other: 90000 },
  { month: 'Feb', health: 380000, accident: 140000, critical: 200000, groupHealth: 320000, groupPa: 160000, sme: 210000, termLife: 270000, tulip: 110000, ulip: 240000, endowment: 330000, moneyback: 200000, business: 150000, mf: 290000, other: 80000 },
  { month: 'Mar', health: 510000, accident: 160000, critical: 230000, groupHealth: 350000, groupPa: 180000, sme: 240000, termLife: 320000, tulip: 140000, ulip: 280000, endowment: 380000, moneyback: 230000, business: 180000, mf: 320000, other: 110000 },
  { month: 'Apr', health: 450000, accident: 150000, critical: 210000, groupHealth: 330000, groupPa: 170000, sme: 220000, termLife: 290000, tulip: 120000, ulip: 260000, endowment: 350000, moneyback: 210000, business: 160000, mf: 300000, other: 100000 },
  { month: 'May', health: 470000, accident: 155000, critical: 220000, groupHealth: 340000, groupPa: 175000, sme: 230000, termLife: 300000, tulip: 130000, ulip: 270000, endowment: 360000, moneyback: 220000, business: 170000, mf: 310000, other: 105000 },
  { month: 'Jun', health: 490000, accident: 165000, critical: 240000, groupHealth: 360000, groupPa: 185000, sme: 250000, termLife: 330000, tulip: 150000, ulip: 290000, endowment: 390000, moneyback: 240000, business: 190000, mf: 330000, other: 115000 },
  { month: 'Jul', health: 430000, accident: 145000, critical: 190000, groupHealth: 310000, groupPa: 155000, sme: 205000, termLife: 260000, tulip: 105000, ulip: 230000, endowment: 320000, moneyback: 195000, business: 145000, mf: 285000, other: 85000 },
  { month: 'Aug', health: 460000, accident: 150000, critical: 215000, groupHealth: 335000, groupPa: 170000, sme: 225000, termLife: 295000, tulip: 125000, ulip: 265000, endowment: 355000, moneyback: 215000, business: 165000, mf: 305000, other: 100000 },
  { month: 'Sep', health: 500000, accident: 170000, critical: 250000, groupHealth: 370000, groupPa: 190000, sme: 260000, termLife: 340000, tulip: 160000, ulip: 300000, endowment: 400000, moneyback: 250000, business: 200000, mf: 340000, other: 120000 },
  { month: 'Oct', health: 530000, accident: 180000, critical: 270000, groupHealth: 390000, groupPa: 200000, sme: 280000, termLife: 370000, tulip: 170000, ulip: 320000, endowment: 430000, moneyback: 270000, business: 220000, mf: 360000, other: 130000 },
  { month: 'Nov', health: 480000, accident: 160000, critical: 230000, groupHealth: 350000, groupPa: 180000, sme: 240000, termLife: 310000, tulip: 140000, ulip: 280000, endowment: 370000, moneyback: 230000, business: 180000, mf: 320000, other: 110000 },
  { month: 'Dec', health: 580000, accident: 200000, critical: 300000, groupHealth: 420000, groupPa: 220000, sme: 310000, termLife: 420000, tulip: 200000, ulip: 360000, endowment: 480000, moneyback: 300000, business: 250000, mf: 400000, other: 150000 },
];

const BUSINESS_CATEGORY_BARS = [
  { key: 'health', label: 'Health', color: '#1e40af' }, // Blue 800
  { key: 'accident', label: 'Accident', color: '#2563eb' }, // Blue 600
  { key: 'critical', label: 'Critical Illness', color: '#60a5fa' }, // Blue 400
  { key: 'groupHealth', label: 'Group Health', color: '#0f766e' }, // Teal 700
  { key: 'groupPa', label: 'Group PA', color: '#0d9488' }, // Teal 600
  { key: 'sme', label: 'SME Health', color: '#2dd4bf' }, // Teal 400
  { key: 'termLife', label: 'Term Life', color: '#4338ca' }, // Indigo 700
  { key: 'tulip', label: 'TULIP', color: '#6366f1' }, // Indigo 500
  { key: 'ulip', label: 'ULIP', color: '#818cf8' }, // Indigo 400
  { key: 'endowment', label: 'Endowment', color: '#0f172a' }, // Slate 900
  { key: 'moneyback', label: 'Moneyback', color: '#334155' }, // Slate 700
  { key: 'business', label: 'Business', color: '#64748b' }, // Slate 500
  { key: 'mf', label: 'MF', color: '#0369a1' }, // Sky 700
  { key: 'other', label: 'Other', color: '#0ea5e9' }, // Sky 500
];

const MOCK_BUSINESS_COMPANY_WISE = [
  { month: 'Jan', 'HDFC Life': 320000, 'LIC': 450000, 'Star Health': 180000, 'SBI Life': 280000, 'Max Life': 150000 },
  { month: 'Feb', 'HDFC Life': 340000, 'LIC': 470000, 'Star Health': 190000, 'SBI Life': 290000, 'Max Life': 160000 },
  { month: 'Mar', 'HDFC Life': 420000, 'LIC': 550000, 'Star Health': 250000, 'SBI Life': 380000, 'Max Life': 220000 },
  { month: 'Apr', 'HDFC Life': 310000, 'LIC': 430000, 'Star Health': 170000, 'SBI Life': 260000, 'Max Life': 140000 },
  { month: 'May', 'HDFC Life': 330000, 'LIC': 460000, 'Star Health': 185000, 'SBI Life': 275000, 'Max Life': 155000 },
  { month: 'Jun', 'HDFC Life': 350000, 'LIC': 480000, 'Star Health': 195000, 'SBI Life': 295000, 'Max Life': 165000 },
  { month: 'Jul', 'HDFC Life': 300000, 'LIC': 410000, 'Star Health': 160000, 'SBI Life': 250000, 'Max Life': 135000 },
  { month: 'Aug', 'HDFC Life': 340000, 'LIC': 465000, 'Star Health': 180000, 'SBI Life': 285000, 'Max Life': 150000 },
  { month: 'Sep', 'HDFC Life': 380000, 'LIC': 500000, 'Star Health': 210000, 'SBI Life': 320000, 'Max Life': 180000 },
  { month: 'Oct', 'HDFC Life': 410000, 'LIC': 540000, 'Star Health': 240000, 'SBI Life': 360000, 'Max Life': 200000 },
  { month: 'Nov', 'HDFC Life': 390000, 'LIC': 510000, 'Star Health': 220000, 'SBI Life': 340000, 'Max Life': 190000 },
  { month: 'Dec', 'HDFC Life': 500000, 'LIC': 650000, 'Star Health': 300000, 'SBI Life': 450000, 'Max Life': 280000 },
];

const COMPANY_LINES = [
  { key: 'HDFC Life', label: 'HDFC Life', color: '#1e40af' }, // Blue 800
  { key: 'LIC', label: 'LIC', color: '#0f766e' }, // Teal 700
  { key: 'Star Health', label: 'Star Health', color: '#4338ca' }, // Indigo 700
  { key: 'SBI Life', label: 'SBI Life', color: '#0369a1' }, // Sky 700
  { key: 'Max Life', label: 'Max Life', color: '#0f172a' }, // Slate 900
];

const MOCK_TENURE_WISE = [
  { month: 'Jan', year1: 120, year2: 45, year3: 30, year4: 10, year5: 5 },
  { month: 'Feb', year1: 110, year2: 50, year3: 25, year4: 12, year5: 4 },
  { month: 'Mar', year1: 140, year2: 60, year3: 35, year4: 15, year5: 8 },
  { month: 'Apr', year1: 105, year2: 40, year3: 20, year4: 8, year5: 3 },
  { month: 'May', year1: 115, year2: 48, year3: 28, year4: 11, year5: 6 },
  { month: 'Jun', year1: 125, year2: 55, year3: 32, year4: 14, year5: 7 },
  { month: 'Jul', year1: 95, year2: 38, year3: 18, year4: 7, year5: 2 },
  { month: 'Aug', year1: 108, year2: 42, year3: 22, year4: 9, year5: 4 },
  { month: 'Sep', year1: 130, year2: 58, year3: 34, year4: 16, year5: 9 },
  { month: 'Oct', year1: 145, year2: 65, year3: 40, year4: 18, year5: 10 },
  { month: 'Nov', year1: 118, year2: 52, year3: 29, year4: 13, year5: 5 },
  { month: 'Dec', year1: 160, year2: 75, year3: 45, year4: 22, year5: 12 },
];

const TENURE_BARS = [
  { key: 'year1', label: '1 Year', color: '#3b82f6' }, // blue-500
  { key: 'year2', label: '2 Years', color: '#10b981' }, // emerald-500
  { key: 'year3', label: '3 Years', color: '#f59e0b' }, // amber-500
  { key: 'year4', label: '4 Years', color: '#8b5cf6' }, // violet-500
  { key: 'year5', label: '5 Years', color: '#ec4899' }, // pink-500
];

const MOCK_LEADS_STATUS_WISE = [
  { stage: 'To Contact', hot: 25, warm: 40, cold: 60, dropped: 10, converted: 0 },
  { stage: 'Contacted', hot: 35, warm: 50, cold: 40, dropped: 15, converted: 0 },
  { stage: 'Proposal Sent', hot: 45, warm: 30, cold: 20, dropped: 5, converted: 0 },
  { stage: 'Login Progress', hot: 55, warm: 20, cold: 10, dropped: 2, converted: 0 },
  { stage: 'Payment Done', hot: 60, warm: 10, cold: 5, dropped: 1, converted: 80 },
  { stage: 'Process Completed', hot: 20, warm: 5, cold: 2, dropped: 0, converted: 95 },
];

const LEAD_STATUS_BARS = [
  { key: 'hot', label: 'Hot', color: '#ef4444' }, // red
  { key: 'warm', label: 'Warm', color: '#f59e0b' }, // amber
  { key: 'cold', label: 'Cold', color: '#3b82f6' }, // blue
  { key: 'converted', label: 'Converted', color: '#10b981' }, // emerald
  { key: 'dropped', label: 'Dropped', color: '#64748b' }, // slate
];

// ── Comprehensive Dummy Fallback Data ─────────────────────────────────────────
const FALLBACK_KPIS = {
  activePolicies: 1248,
  openLeads: 86,
  monthlyPremium: 3840000,
  openClaims: 14,
};

const FALLBACK_REVENUE_12 = [
  { month: 'Jan', revenue: 2450000, target: 2200000 },
  { month: 'Feb', revenue: 2800000, target: 2500000 },
  { month: 'Mar', revenue: 3950000, target: 3200000 },
  { month: 'Apr', revenue: 3100000, target: 3000000 },
  { month: 'May', revenue: 3400000, target: 3200000 },
  { month: 'Jun', revenue: 3650000, target: 3400000 },
  { month: 'Jul', revenue: 3200000, target: 3100000 },
  { month: 'Aug', revenue: 3500000, target: 3300000 },
  { month: 'Sep', revenue: 4100000, target: 3600000 },
  { month: 'Oct', revenue: 4350000, target: 3800000 },
  { month: 'Nov', revenue: 3900000, target: 3700000 },
  { month: 'Dec', revenue: 4800000, target: 4200000 },
];

const FALLBACK_PORTFOLIO_PRODUCT = [
  { name: 'Health Insurance', value: 450 },
  { name: 'Term Life', value: 380 },
  { name: 'Motor Insurance', value: 240 },
  { name: 'Investment / ULIP', value: 180 },
  { name: 'General / SME', value: 120 },
];

const FALLBACK_PORTFOLIO_COMPANY = [
  { name: 'HDFC Life', value: 420 },
  { name: 'Star Health', value: 340 },
  { name: 'LIC of India', value: 290 },
  { name: 'ICICI Lombard', value: 210 },
  { name: 'Tata AIG', value: 160 },
];

const FALLBACK_PIPELINE_STAGES = [
  { stage: 'TO_CONTACT', count: 28 },
  { stage: 'CONTACTED', count: 22 },
  { stage: 'PROPOSAL_SENT', count: 16 },
  { stage: 'LOGIN_PROGRESS', count: 11 },
  { stage: 'PAYMENT_DONE', count: 9 },
  { stage: 'PROCESS_COMPLETED', count: 14 },
];

const FALLBACK_RECENT_CLAIMS = [
  { id: 'clm-001', claimNumber: 'CLM-8492', policy: { contact: { firstName: 'Amit', lastName: 'Sharma' }, plan: { category: 'Health Insurance' } }, claimAmount: 185000, status: 'APPROVED' },
  { id: 'clm-002', claimNumber: 'CLM-7321', policy: { contact: { firstName: 'Priya', lastName: 'Patel' }, plan: { category: 'Critical Illness' } }, claimAmount: 350000, status: 'PENDING' },
  { id: 'clm-003', claimNumber: 'CLM-9104', policy: { contact: { firstName: 'Vikram', lastName: 'Singh' }, plan: { category: 'Motor Insurance' } }, claimAmount: 48000, status: 'APPROVED' },
  { id: 'clm-004', claimNumber: 'CLM-6540', policy: { contact: { firstName: 'Sunita', lastName: 'Verma' }, plan: { category: 'Group Health' } }, claimAmount: 92000, status: 'UNDER_PROCESS' },
  { id: 'clm-005', claimNumber: 'CLM-4819', policy: { contact: { firstName: 'Rajesh', lastName: 'Gupta' }, plan: { category: 'Term Life' } }, claimAmount: 1500000, status: 'PENDING' },
];

const FALLBACK_TOP_AGENTS = [
  { id: 'agt-001', firstName: 'Kavita', lastName: 'Deshmukh', designation: 'Senior Insurance Specialist', policiesCount: 38, premiumTotal: 4250000 },
  { id: 'agt-002', firstName: 'Rohit', lastName: 'Kashyap', designation: 'Field Relationship Officer', policiesCount: 31, premiumTotal: 3400000 },
  { id: 'agt-003', firstName: 'Ananya', lastName: 'Roy', designation: 'Inbound Tele-Calling Executive', policiesCount: 26, premiumTotal: 2850000 },
  { id: 'agt-004', firstName: 'Siddharth', lastName: 'Nair', designation: 'Corporate Agency Associate', policiesCount: 22, premiumTotal: 2400000 },
];

const FALLBACK_CLAIMS_FOR_REPORTS = [
  { id: 'clm-101', claimNumber: 'CLM-4910', claimType: 'CASHLESS', policy: { plan: { company: { name: 'Star Health' } } }, notes: JSON.stringify({ hospital: 'Apollo Hospitals', diagnosis: 'Dengue Treatment' }), claimAmount: 68000, approvedAmount: 64000, intimatedAt: new Date(Date.now() - 5 * 86400000).toISOString(), createdAt: new Date(Date.now() - 5 * 86400000).toISOString(), status: 'SETTLED' },
  { id: 'clm-102', claimNumber: 'CLM-5821', claimType: 'REIMBURSEMENT', policy: { plan: { company: { name: 'HDFC ERGO' } } }, notes: JSON.stringify({ hospital: 'Fortis Healthcare', diagnosis: 'Knee Arthroscopy' }), claimAmount: 145000, approvedAmount: 138000, intimatedAt: new Date(Date.now() - 12 * 86400000).toISOString(), createdAt: new Date(Date.now() - 12 * 86400000).toISOString(), status: 'SETTLED' },
  { id: 'clm-103', claimNumber: 'CLM-6194', claimType: 'CASHLESS', policy: { plan: { company: { name: 'Care Insurance' } } }, notes: JSON.stringify({ hospital: 'Manipal Hospital', diagnosis: 'Cardiac Angioplasty' }), claimAmount: 320000, approvedAmount: 0, intimatedAt: new Date(Date.now() - 2 * 86400000).toISOString(), createdAt: new Date(Date.now() - 2 * 86400000).toISOString(), status: 'PENDING' },
  { id: 'clm-104', claimNumber: 'CLM-7012', claimType: 'CASHLESS', policy: { plan: { company: { name: 'Niva Bupa' } } }, notes: JSON.stringify({ hospital: 'Max Super Speciality', diagnosis: 'Cataract Surgery' }), claimAmount: 52000, approvedAmount: 50000, intimatedAt: new Date(Date.now() - 18 * 86400000).toISOString(), createdAt: new Date(Date.now() - 18 * 86400000).toISOString(), status: 'SETTLED' },
  { id: 'clm-105', claimNumber: 'CLM-8145', claimType: 'REIMBURSEMENT', policy: { plan: { company: { name: 'ICICI Lombard' } } }, notes: JSON.stringify({ hospital: 'Narayana Health', diagnosis: 'Accidental Fracture' }), claimAmount: 95000, approvedAmount: 0, intimatedAt: new Date(Date.now() - 4 * 86400000).toISOString(), createdAt: new Date(Date.now() - 4 * 86400000).toISOString(), status: 'IN_PROGRESS' },
  { id: 'clm-106', claimNumber: 'CLM-9230', claimType: 'CASHLESS', policy: { plan: { company: { name: 'Tata AIG' } } }, notes: JSON.stringify({ hospital: 'Kokilaben Hospital', diagnosis: 'Gallbladder Removal' }), claimAmount: 110000, approvedAmount: 105000, intimatedAt: new Date(Date.now() - 25 * 86400000).toISOString(), createdAt: new Date(Date.now() - 25 * 86400000).toISOString(), status: 'SETTLED' },
  { id: 'clm-107', claimNumber: 'CLM-9411', claimType: 'REIMBURSEMENT', policy: { plan: { company: { name: 'Star Health' } } }, notes: JSON.stringify({ hospital: 'Ruby Hall Clinic', diagnosis: 'Pre-existing Exclusion' }), claimAmount: 42000, approvedAmount: 0, intimatedAt: new Date(Date.now() - 30 * 86400000).toISOString(), createdAt: new Date(Date.now() - 30 * 86400000).toISOString(), status: 'REJECTED' },
];

// ── Helpers ──────────────────────────────────────────────────────────────────

function fmt(n?: number) {
  if (n === undefined || n === null) return '—';
  return n.toLocaleString('en-IN');
}

function fmtINR(n?: number) {
  if (n === undefined || n === null) return '—';
  return `₹${n.toLocaleString('en-IN')}`;
}


// ── Section header inside cards ──────────────────────────────────────────────
function SectionHeader({ title, action, onAction }: { title: string; action?: string; onAction?: () => void }) {
  return (
    <div className="flex items-center justify-between mb-4">
      <h3 className="text-xs font-bold text-gray-900 tracking-wider uppercase">{title}</h3>
      {action && (
        <button
          onClick={onAction}
          className="text-[10px] sm:text-xs text-blue-600 hover:text-blue-700 font-bold transition-colors cursor-pointer"
        >
          {action}
        </button>
      )}
    </div>
  );
}

// ── New Premium KPI Card to match the mockup ─────────────────────────────────
interface KpiCardProps {
  label: string;
  value: string | number;
  trend?: string;
  trendUp?: boolean;
  icon: React.ReactNode;
  color: string;
  onClick?: () => void;
}

function PremiumKpiCard({ label, value, trend, trendUp = true, icon, color, onClick }: KpiCardProps) {
  return (
    <div
      onClick={onClick}
      className={clsx(
        "bg-white rounded-2xl border border-gray-100 p-5 shadow-sm hover:shadow-md transition-all duration-200 flex flex-col justify-between h-32 relative overflow-hidden group",
        onClick && "cursor-pointer hover:border-blue-200 hover:shadow-lg active:scale-[0.98]"
      )}
    >
      <div className="flex items-start justify-between">
        <div className="flex flex-col gap-0.5">
          <span className="text-xs font-semibold text-gray-400 tracking-wide">{label}</span>
          <span className="text-2xl font-extrabold text-gray-900 tracking-tight mt-1">{value}</span>
        </div>
        <div className={clsx('h-10 w-10 rounded-xl flex items-center justify-center shrink-0 shadow-sm transition-transform duration-300 group-hover:scale-110', color)}>
          {icon}
        </div>
      </div>
      <div className="flex flex-wrap items-center gap-1 text-[11px] mt-2 font-medium">
        {trend ? (
          <>
            <span className={clsx(trendUp ? 'text-green-600' : 'text-red-500')}>
              {trendUp ? '▲' : '▼'} {trend}
            </span>
            <span className="text-gray-400">vs last month</span>
          </>
        ) : (
          <span className="text-gray-400 text-[10px]">Real-time live data</span>
        )}
      </div>
    </div>
  );
}

// ── Contacts Breakdown Indicator Card ─────────────────────────────────────────
function ContactsBreakdownCard({ data }: { data: { total: number; male: number; female: number; under18: number; above60: number } }) {
  const total = data?.total > 0 ? data.total : 1;
  const maleCount = data?.male || 0;
  const femaleCount = data?.female || 0;
  const under18Count = data?.under18 || 0;
  const above60Count = data?.above60 || 0;

  const malePct = ((maleCount / total) * 100).toFixed(0);
  const femalePct = ((femaleCount / total) * 100).toFixed(0);
  const under18Pct = ((under18Count / total) * 100).toFixed(0);
  const above60Pct = ((above60Count / total) * 100).toFixed(0);

  return (
    <div className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm h-full flex flex-col justify-between group hover:shadow-md transition-all">
      <div>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xs font-bold text-gray-900 tracking-wider uppercase">Total Contacts</h3>
          <div className="h-8 w-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
            <Users size={16} />
          </div>
        </div>

        <div className="mb-4">
          <span className="text-3xl font-extrabold text-gray-900">{fmt(data?.total || 0)}</span>
          <p className="text-[10px] font-semibold text-gray-400 mt-1 uppercase tracking-wide">Total registered contacts</p>
        </div>

        <div className="space-y-3.5">
          {/* Male */}
          <div>
            <div className="flex justify-between text-[11px] font-bold text-gray-700 mb-1.5">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-blue-500 inline-block shadow-xs" />
                Male
              </span>
              <span>{fmt(data.male)} ({malePct}%)</span>
            </div>
            <div className="w-full bg-gray-100 rounded-full h-1.5 overflow-hidden">
              <div className="h-full bg-blue-500 rounded-full transition-all duration-500" style={{ width: `${malePct}%` }} />
            </div>
          </div>

          {/* Female */}
          <div>
            <div className="flex justify-between text-[11px] font-bold text-gray-700 mb-1.5">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-pink-500 inline-block shadow-xs" />
                Female
              </span>
              <span>{fmt(data.female)} ({femalePct}%)</span>
            </div>
            <div className="w-full bg-gray-100 rounded-full h-1.5 overflow-hidden">
              <div className="h-full bg-pink-500 rounded-full transition-all duration-500" style={{ width: `${femalePct}%` }} />
            </div>
          </div>

          {/* Under 18 */}
          <div>
            <div className="flex justify-between text-[11px] font-bold text-gray-700 mb-1.5">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block shadow-xs" />
                Under 18
              </span>
              <span>{fmt(data.under18)} ({under18Pct}%)</span>
            </div>
            <div className="w-full bg-gray-100 rounded-full h-1.5 overflow-hidden">
              <div className="h-full bg-emerald-500 rounded-full transition-all duration-500" style={{ width: `${under18Pct}%` }} />
            </div>
          </div>

          {/* Above 60 */}
          <div>
            <div className="flex justify-between text-[11px] font-bold text-gray-700 mb-1.5">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-500 inline-block shadow-xs" />
                Above 60
              </span>
              <span>{fmt(data.above60)} ({above60Pct}%)</span>
            </div>
            <div className="w-full bg-gray-100 rounded-full h-1.5 overflow-hidden">
              <div className="h-full bg-amber-500 rounded-full transition-all duration-500" style={{ width: `${above60Pct}%` }} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── MF Leads Business Summary Card ──────────────────────────────────────────
function MfLeadsSummaryCard({ data }: { data: any }) {
  const totalAum = (data?.activeSipAmount || 0) + (data?.lumpsumAmount || 0);

  return (
    <div className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm h-full flex flex-col justify-between group hover:shadow-md transition-all">
      <div>
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-xl bg-gradient-to-tr from-teal-500 to-emerald-600 text-white flex items-center justify-center shadow-xs shadow-teal-500/20">
              <TrendingUp size={16} />
            </div>
            <div>
              <h3 className="text-xs font-bold text-gray-900 tracking-wider uppercase">MF Leads Business</h3>
              <p className="text-[10px] text-gray-400 font-semibold">SIP, Lumpsum & Investor Pool</p>
            </div>
          </div>
          <span className="text-[10px] font-extrabold text-emerald-700 bg-emerald-50 border border-emerald-200/60 px-2 py-0.5 rounded-full">
            ● Active
          </span>
        </div>

        {/* 4 Attractive Metric Tiles */}
        <div className="grid grid-cols-2 gap-3 mt-3">
          {/* Active SIP Amt */}
          <div className="bg-gradient-to-br from-emerald-50/80 to-teal-50/40 rounded-2xl p-3.5 border border-emerald-100/80 hover:border-emerald-300 transition-all shadow-2xs">
            <div className="flex items-center justify-between">
              <p className="text-[10px] font-bold text-emerald-800 uppercase tracking-wide">Active SIP Amt</p>
              <span className="text-[9px] font-black text-emerald-600 bg-emerald-100/70 px-1.5 py-0.5 rounded">Monthly</span>
            </div>
            <p className="text-base font-black text-emerald-950 mt-1.5 tracking-tight">{fmtINR(data?.activeSipAmount || 0)}</p>
            <p className="text-[9px] font-bold text-emerald-700 mt-1 flex items-center gap-1">
              <span className="text-gray-400 font-normal">{data?.activeSipAmount ? 'Active SIPs running' : 'No active SIPs'}</span>
            </p>
          </div>

          {/* Lumpsum Amt */}
          <div className="bg-gradient-to-br from-blue-50/80 to-indigo-50/40 rounded-2xl p-3.5 border border-blue-100/80 hover:border-blue-300 transition-all shadow-2xs">
            <div className="flex items-center justify-between">
              <p className="text-[10px] font-bold text-blue-800 uppercase tracking-wide">Lumpsum Amt</p>
              <span className="text-[9px] font-black text-blue-600 bg-blue-100/70 px-1.5 py-0.5 rounded">Total</span>
            </div>
            <p className="text-base font-black text-blue-950 mt-1.5 tracking-tight">{fmtINR(data?.lumpsumAmount || 0)}</p>
            <p className="text-[9px] font-bold text-blue-700 mt-1 flex items-center gap-1">
              <span className="text-gray-400 font-normal">{data?.lumpsumAmount ? 'Lumpsum portfolio' : 'No lumpsum'}</span>
            </p>
          </div>

          {/* No. of Investors */}
          <div className="bg-gradient-to-br from-purple-50/80 to-fuchsia-50/40 rounded-2xl p-3.5 border border-purple-100/80 hover:border-purple-300 transition-all shadow-2xs">
            <div className="flex items-center justify-between">
              <p className="text-[10px] font-bold text-purple-800 uppercase tracking-wide">No. of Investors</p>
              <Users size={12} className="text-purple-600" />
            </div>
            <p className="text-base font-black text-purple-950 mt-1.5 tracking-tight">{data?.investors ?? 0}</p>
            <p className="text-[9px] font-bold text-purple-700 mt-1 flex items-center gap-1">
              <span className="text-gray-400 font-normal">{data?.investors ? `${data.investors} Investors` : 'No investors'}</span>
            </p>
          </div>

          {/* No. of Active SIPs */}
          <div className="bg-gradient-to-br from-amber-50/80 to-orange-50/40 rounded-2xl p-3.5 border border-amber-100/80 hover:border-amber-300 transition-all shadow-2xs">
            <div className="flex items-center justify-between">
              <p className="text-[10px] font-bold text-amber-800 uppercase tracking-wide">Active SIPs</p>
              <CheckCircle size={12} className="text-amber-600" />
            </div>
            <p className="text-base font-black text-amber-950 mt-1.5 tracking-tight">{data?.activeSips ?? 0}</p>
            <p className="text-[9px] font-bold text-amber-700 mt-1 flex items-center gap-1">
              <span className="text-gray-400 font-normal">{data?.activeSips ? `${data.activeSips} Active SIPs` : 'No active SIPs'}</span>
            </p>
          </div>
        </div>
      </div>

      {/* Footer Banner */}
      <div className="mt-4 pt-3 border-t border-gray-100/80 flex items-center justify-between text-xs">
        <span className="text-[11px] font-semibold text-gray-500">Total MF Book Value (AUM)</span>
        <span className="text-xs font-black text-gray-900 bg-gray-50 px-2.5 py-1 rounded-lg border border-gray-100">
          {fmtINR(totalAum)}
        </span>
      </div>
    </div>
  );
}

// ── Leads Progress Indicator Card ────────────────────────────────────────────
function LeadsProgressIndicator({ pipelineData }: { pipelineData: any[] }) {
  const effectivePipeline = Array.isArray(pipelineData) ? pipelineData : [];
  const stagesOrder = ['TO_CONTACT', 'CONTACTED', 'PROPOSAL_SENT', 'LOGIN_PROGRESS', 'PAYMENT_DONE', 'PROCESS_COMPLETED'];
  const stageColors: Record<string, string> = {
    TO_CONTACT: 'bg-blue-500',
    CONTACTED: 'bg-indigo-500',
    PROPOSAL_SENT: 'bg-purple-500',
    LOGIN_PROGRESS: 'bg-orange-500',
    PAYMENT_DONE: 'bg-green-500',
    PROCESS_COMPLETED: 'bg-emerald-500',
  };
  const stageLabels: Record<string, string> = {
    TO_CONTACT: 'To Contact',
    CONTACTED: 'Contacted',
    PROPOSAL_SENT: 'Proposal Sent',
    LOGIN_PROGRESS: 'Login Progress',
    PAYMENT_DONE: 'Payment Done',
    PROCESS_COMPLETED: 'Process Completed',
  };

  const totalActiveLeads = effectivePipeline
    .filter(p => stagesOrder.includes(p.stage))
    .reduce((acc, curr) => acc + (curr.count || 0), 0);

  return (
    <div className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm h-full flex flex-col justify-between">
      <div>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xs font-bold text-gray-900 tracking-wider uppercase">Leads Progress Indicator</h3>
          <span className="text-[10px] font-bold text-blue-600 bg-blue-50 border border-blue-100 px-2 py-0.5 rounded">
            {totalActiveLeads} Active Leads
          </span>
        </div>
        <div className="space-y-3.5">
          {stagesOrder.map(stage => {
            const data = effectivePipeline.find(p => p.stage === stage);
            const count = data?.count || 0;
            const percentage = totalActiveLeads > 0 ? (count / totalActiveLeads) * 100 : 0;
            return (
              <div key={stage} className="space-y-1">
                <div className="flex justify-between text-[11px] font-semibold text-gray-700">
                  <span>{stageLabels[stage]}</span>
                  <span className="font-bold">{count} ({percentage.toFixed(0)}%)</span>
                </div>
                <div className="w-full bg-gray-100 rounded-full h-1.5">
                  <div
                    className={clsx("h-1.5 rounded-full transition-all duration-500", stageColors[stage] || 'bg-blue-500')}
                    style={{ width: `${percentage}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ── Helper format for Sum Insured ───────────────────────────────────────────
function formatLakhOrCr(amount: number) {
  if (!amount || amount === 0) return '₹0';
  if (amount >= 10000000) {
    return `₹${(amount / 10000000).toFixed(2)} Cr`;
  }
  return `₹${(amount / 100000).toFixed(1)}L`;
}

// ── Avg Sum Insured Card (Gen + Health) ──────────────────────────────────────
function AvgSumInsuredGenHealthCard({ data }: { data?: any }) {
  const freshVal = data?.fresh ? formatLakhOrCr(data.fresh) : '₹0';
  const portVal = data?.port ? formatLakhOrCr(data.port) : '₹0';
  const renewalVal = data?.renewal ? formatLakhOrCr(data.renewal) : '₹0';
  const weightedVal = data?.weighted ? `${formatLakhOrCr(data.weighted)} / Person` : '₹0 / Person';

  return (
    <div className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm h-full flex flex-col justify-between group hover:shadow-md transition-all">
      <div>
        {/* Header */}
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-xl bg-gradient-to-tr from-indigo-500 to-blue-600 text-white flex items-center justify-center shadow-xs shadow-indigo-500/20">
              <Shield size={16} />
            </div>
            <div>
              <h3 className="text-xs font-bold text-gray-900 tracking-wider uppercase">Avg Sum Insured (Gen + Health)</h3>
              <p className="text-[10px] text-gray-400 font-semibold">Total basic sum insured divided by insured persons</p>
            </div>
          </div>
          <span className="text-[10px] font-extrabold text-indigo-700 bg-indigo-50 border border-indigo-200/60 px-2 py-0.5 rounded-full">
            {data?.weighted ? '● Optimal Cover' : '● Live Metric'}
          </span>
        </div>

        {/* 3 Interactive Category Tiles */}
        <div className="grid grid-cols-3 gap-3 mt-4">
          {/* Fresh */}
          <div className="bg-gradient-to-br from-indigo-50/90 to-blue-50/40 rounded-2xl p-3.5 border border-indigo-100/80 hover:border-indigo-300 transition-all shadow-2xs">
            <div className="flex items-center justify-between">
              <p className="text-[10px] font-bold text-indigo-800 uppercase tracking-wide">Fresh</p>
              <span className="w-2 h-2 rounded-full bg-indigo-500" />
            </div>
            <p className="text-lg font-black text-indigo-950 mt-1.5 tracking-tight">{freshVal}</p>
            <p className="text-[9px] font-medium text-indigo-600 mt-0.5">Base entry cover</p>
          </div>

          {/* Port */}
          <div className="bg-gradient-to-br from-teal-50/90 to-emerald-50/40 rounded-2xl p-3.5 border border-teal-100/80 hover:border-teal-300 transition-all shadow-2xs">
            <div className="flex items-center justify-between">
              <p className="text-[10px] font-bold text-teal-800 uppercase tracking-wide">Port</p>
              <span className="w-2 h-2 rounded-full bg-teal-500" />
            </div>
            <p className="text-lg font-black text-teal-950 mt-1.5 tracking-tight">{portVal}</p>
            <p className="text-[9px] font-medium text-teal-600 mt-0.5">Enhanced porting</p>
          </div>

          {/* Renewal */}
          <div className="bg-gradient-to-br from-amber-50/90 to-orange-50/40 rounded-2xl p-3.5 border border-amber-100/80 hover:border-amber-300 transition-all shadow-2xs">
            <div className="flex items-center justify-between">
              <p className="text-[10px] font-bold text-amber-800 uppercase tracking-wide">Renewal</p>
              <span className="w-2 h-2 rounded-full bg-amber-500" />
            </div>
            <p className="text-lg font-black text-amber-950 mt-1.5 tracking-tight">{renewalVal}</p>
            <p className="text-[9px] font-medium text-amber-600 mt-0.5">With bonus added</p>
          </div>
        </div>
      </div>

      {/* Footer Benchmark Bar */}
      <div className="mt-4 pt-3 border-t border-gray-100/80 flex items-center justify-between text-xs">
        <span className="text-[11px] font-semibold text-gray-500">Overall Weighted Portfolio Average</span>
        <span className="text-xs font-black text-indigo-900 bg-indigo-50/80 px-2.5 py-1 rounded-lg border border-indigo-100">
          {weightedVal}
        </span>
      </div>
    </div>
  );
}

// ── Avg Sum Insured Card (Term) ─────────────────────────────────────────────
function AvgSumInsuredTermCard({ data }: { data?: any }) {
  const avgLifeCover = data?.avg ? formatLakhOrCr(data.avg) : '₹0';
  const over1Cr = data?.over1CrPct !== undefined && data?.over1CrPct > 0 ? `${data.over1CrPct}%` : '0%';

  return (
    <div className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm h-full flex flex-col justify-between group hover:shadow-md transition-all">
      <div>
        {/* Header */}
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-xl bg-gradient-to-tr from-rose-500 to-pink-600 text-white flex items-center justify-center shadow-xs shadow-rose-500/20">
              <Shield size={16} />
            </div>
            <div>
              <h3 className="text-xs font-bold text-gray-900 tracking-wider uppercase">Avg Sum Insured (Term Life)</h3>
              <p className="text-[10px] text-gray-400 font-semibold">Total life sum insured divided by active insured persons</p>
            </div>
          </div>
          <span className="text-[10px] font-extrabold text-emerald-700 bg-emerald-50 border border-emerald-200/60 px-2 py-0.5 rounded-full flex items-center gap-1">
            {data?.avg ? '✓ High Coverage' : '● Live Metric'}
          </span>
        </div>

        {/* Hero Value Display with Benchmarks */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-4">
          {/* Main Hero Card */}
          <div className="bg-gradient-to-br from-rose-50/90 to-pink-50/40 rounded-2xl p-3.5 border border-rose-100/80 shadow-2xs flex flex-col justify-between">
            <p className="text-[10px] font-bold text-rose-800 uppercase tracking-wide">Average Life Cover</p>
            <div className="my-1">
              <span className="text-2xl font-black text-rose-950 tracking-tight">{avgLifeCover}</span>
              <p className="text-[10px] font-semibold text-rose-600 mt-0.5">Per insured breadwinner</p>
            </div>
            <div className="w-full bg-rose-200/60 rounded-full h-1.5 mt-1 overflow-hidden">
              <div className="bg-rose-600 h-full rounded-full" style={{ width: avgLifeCover !== '₹0' ? '85%' : '0%' }} />
            </div>
          </div>

          {/* Sub Benchmarks Card */}
          <div className="bg-gradient-to-br from-slate-50/90 to-gray-50/50 rounded-2xl p-3.5 border border-gray-100 shadow-2xs flex flex-col justify-between">
            <div>
              <p className="text-[10px] font-bold text-gray-500 uppercase tracking-wide">Coverage Tier Benchmark</p>
              <div className="mt-2 space-y-1.5">
                <div className="flex justify-between text-[11px] font-bold">
                  <span className="text-gray-600">≥ ₹1.0 Cr Share</span>
                  <span className="text-emerald-600 font-extrabold">{over1Cr}</span>
                </div>
                <div className="flex justify-between text-[11px] font-bold">
                  <span className="text-gray-600">Avg Income Multiplier</span>
                  <span className="text-blue-600 font-extrabold">{data?.incomeMultiplier ? `${data.incomeMultiplier}x` : '—'}</span>
                </div>
              </div>
            </div>
            <p className="text-[9px] font-bold text-gray-400 mt-2">Recommended: 15x - 20x annual income</p>
          </div>
        </div>
      </div>

      {/* Footer Benchmark Bar */}
      <div className="mt-4 pt-3 border-t border-gray-100/80 flex items-center justify-between text-xs">
        <span className="text-[11px] font-semibold text-gray-500">Benchmark Protection Index</span>
        <span className="text-xs font-black text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-100">
          {data?.tier ? `${data.tier} (${data.score}/100)` : '—'}
        </span>
      </div>
    </div>
  );
}

// ── Database Summary Status Table Card ───────────────────────────────────────
function DatabaseSummary({ summaryData }: { summaryData: any }) {
  const {
    policies = [],
    contacts = 0,
    contactsActive: rawContactsActive,
    contactsInactive: rawContactsInactive,
    claims = [],
    leads = 0,
    leadsGrouped = []
  } = summaryData || {};

  // Policies: Active and Expired
  const rawPolicyActive = policies
    .filter((p: any) => ['ACTIVE', 'INFORCE'].includes(p.status))
    .reduce((acc: number, curr: any) => acc + (curr.count || 0), 0);
  const rawPolicyExpired = policies
    .filter((p: any) => ['EXPIRED', 'LAPSED', 'CANCELLED', 'SURRENDERED', 'INACTIVE_OLD'].includes(p.status))
    .reduce((acc: number, curr: any) => acc + (curr.count || 0), 0);
  const rawPolicyTotal = policies.reduce((acc: number, curr: any) => acc + (curr.count || 0), 0);

  const policyTotal = rawPolicyTotal;
  const policyActive = rawPolicyActive;
  const policyExpired = rawPolicyExpired;

  // Contacts: Active and Inactive
  const totalContacts = contacts;
  const contactsActive = rawContactsActive !== undefined ? rawContactsActive : Math.round(totalContacts * 0.9);
  const contactsInactive = rawContactsInactive !== undefined ? rawContactsInactive : (totalContacts - contactsActive);

  // Leads: Hopeful (Interested, Hot, Very Hot, Contacted, Proposal, Login, Payment) and Hopeless (Lost, Not Interested)
  const totalLeads = leads;
  const leadsHopeful = leadsGrouped.length > 0
    ? leadsGrouped.filter((l: any) => !['LOST', 'DROPPED', 'NOT_INTERESTED'].includes(l.stage)).reduce((acc: number, curr: any) => acc + (curr.count || 0), 0)
    : Math.round(totalLeads * 0.76);
  const leadsHopeless = totalLeads - leadsHopeful;

  // Claims: Active, Settled, Inprogress
  const rawClaimActive = claims
    .filter((c: any) => ['INTIMATED', 'DOC_COLLECTION', 'FILED'].includes(c.status))
    .reduce((acc: number, curr: any) => acc + (curr.count || 0), 0);
  const rawClaimInProgress = claims
    .filter((c: any) => c.status === 'IN_REVIEW' || c.status === 'IN_PROGRESS')
    .reduce((acc: number, curr: any) => acc + (curr.count || 0), 0);
  const rawClaimSettled = claims
    .filter((c: any) => c.status === 'SETTLED' || c.status === 'APPROVED')
    .reduce((acc: number, curr: any) => acc + (curr.count || 0), 0);
  const rawClaimTotal = claims.reduce((acc: number, curr: any) => acc + (curr.count || 0), 0);

  const claimTotal = rawClaimTotal;
  const claimActive = rawClaimActive;
  const claimSettled = rawClaimSettled;
  const claimInProgress = rawClaimInProgress;

  return (
    <div className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm h-full flex flex-col justify-between">
      <div>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xs font-bold text-gray-900 tracking-wider uppercase">Database Summary</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left text-gray-700">
            <thead>
              <tr className="bg-gray-50/70 border-b border-gray-100 text-gray-500 font-bold uppercase tracking-wider">
                <th className="px-4 py-2">Category</th>
                <th className="px-4 py-2">Total Count</th>
                <th className="px-4 py-2">Breakdown status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50 font-medium">
              {/* Contacts: Active & Inactive */}
              <tr className="hover:bg-gray-50/50">
                <td className="px-4 py-3 font-semibold text-gray-950">Contacts</td>
                <td className="px-4 py-3 font-bold text-blue-600">{totalContacts}</td>
                <td className="px-4 py-3 text-gray-500">
                  <span className="text-emerald-600 font-semibold">{contactsActive} Active</span> •{' '}
                  <span className="text-gray-400 font-medium">{contactsInactive} Inactive</span>
                </td>
              </tr>
              {/* Leads: Hopeful & Hopeless */}
              <tr className="hover:bg-gray-50/50">
                <td className="px-4 py-3 font-semibold text-gray-950">Leads</td>
                <td className="px-4 py-3 font-bold text-indigo-600">{totalLeads}</td>
                <td className="px-4 py-3 text-gray-500">
                  <span className="text-emerald-600 font-semibold">{leadsHopeful} Hopeful</span>{' '}
                  <span className="text-gray-400 text-[10px]">(Interested & above)</span> •{' '}
                  <span className="text-rose-500 font-semibold">{leadsHopeless} Hopeless</span>{' '}
                  <span className="text-gray-400 text-[10px]">(Lost / Not interested)</span>
                </td>
              </tr>
              {/* Policies: Active & Expired */}
              <tr className="hover:bg-gray-50/50">
                <td className="px-4 py-3 font-semibold text-gray-950">Policies</td>
                <td className="px-4 py-3 font-bold text-blue-600">{policyTotal}</td>
                <td className="px-4 py-3 text-gray-500">
                  <span className="text-emerald-600 font-semibold">{policyActive} Active</span> •{' '}
                  <span className="text-amber-500 font-medium">{policyExpired} Expired</span>
                </td>
              </tr>
              {/* Claims: Active, Settled, Inprogress */}
              <tr className="hover:bg-gray-50/50">
                <td className="px-4 py-3 font-semibold text-gray-950">Claims</td>
                <td className="px-4 py-3 font-bold text-red-500">{claimTotal}</td>
                <td className="px-4 py-3 text-gray-500">
                  <span className="text-blue-500 font-semibold">{claimActive} Active</span> •{' '}
                  <span className="text-emerald-600 font-semibold">{claimSettled} Settled</span> •{' '}
                  <span className="text-amber-500 font-medium">{claimInProgress} In-Progress</span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// ── Claims Reports & Analytics Panel Component ─────────────────────────────
function ClaimsReportsTab() {
  const navigate = useNavigate();
  const { data: claimsRes, isLoading: claimsLoading } = useClaims({ page: 1, limit: 1000 });
  const rawClaims = claimsRes?.data ?? [];
  const claims = Array.isArray(rawClaims) ? rawClaims : [];
  const { data: employeesRes } = useQuery({ queryKey: ['employees-list'], queryFn: () => employeesService.list().catch(() => ({ data: [] })) });
  const employees = employeesRes?.data ?? [];

  // Filter States
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [duration, setDuration] = useState('ALL');
  const [selectedCompany, setSelectedCompany] = useState('ALL');
  const [hospitalQuery, setHospitalQuery] = useState('');
  const [claimType, setClaimType] = useState('ALL');
  const [selectedAgent, setSelectedAgent] = useState('');
  const [graphCompanySelect, setGraphCompanySelect] = useState('ALL');
  const [pieChartMetric, setPieChartMetric] = useState<'count' | 'claimed' | 'settled'>('count');
  const [timeGraphMonths, setTimeGraphMonths] = useState<string>('12');

  // Extract unique companies for filter dropdown
  const companies = useMemo(() => {
    const set = new Set<string>();
    claims.forEach((c: any) => {
      const name = c.policy?.plan?.company?.name;
      if (name) set.add(name);
    });
    return Array.from(set).sort();
  }, [claims]);

  // Filter claims
  const filteredClaims = useMemo(() => {
    return claims.filter((c: any) => {
      const notesData = getClaimNotesData(c.notes);

      // Filter by Type
      if (claimType !== 'ALL') {
        const typeMatch = (c.claimType || '').toUpperCase() === claimType.toUpperCase();
        if (!typeMatch) return false;
      }

      // Filter by Company
      if (selectedCompany !== 'ALL') {
        const comp = c.policy?.plan?.company?.name || '';
        if (comp.toLowerCase() !== selectedCompany.toLowerCase()) return false;
      }

      // Filter by Hospital
      if (hospitalQuery.trim()) {
        const hospName = (notesData.hospital || '').toLowerCase();
        if (!hospName.includes(hospitalQuery.toLowerCase())) return false;
      }

      // Filter by Start Date
      if (startDate) {
        const start = new Date(startDate).setHours(0, 0, 0, 0);
        const dStr = c.intimatedAt || c.createdAt;
        if (!dStr) return false;
        const d = new Date(dStr).getTime();
        if (isNaN(d) || d < start) return false;
      }

      // Filter by End Date
      if (endDate) {
        const end = new Date(endDate).setHours(23, 59, 59, 999);
        const dStr = c.intimatedAt || c.createdAt;
        if (!dStr) return false;
        const d = new Date(dStr).getTime();
        if (isNaN(d) || d > end) return false;
      }

      // Filter by Duration
      if (duration !== 'ALL') {
        const date = c.intimatedAt ? new Date(c.intimatedAt) : new Date(c.createdAt);
        const daysDiff = differenceInDays(new Date(), date);
        if (duration === '30' && daysDiff > 30) return false;
        if (duration === '90' && daysDiff > 90) return false;
        if (duration === '365' && daysDiff > 365) return false;
      }

      // Filter by Agent
      if (selectedAgent && c.assignedEmployeeId !== selectedAgent) return false;

      return true;
    });
  }, [claims, claimType, selectedCompany, hospitalQuery, startDate, endDate, duration, selectedAgent]);

  // Calculations for Advanced Analytics & KPIs
  const stats = useMemo(() => {
    let totalClaimed = 0;
    let totalSettled = 0;
    let totalPending = 0;
    const companyMap: Record<string, { count: number; claimed: number; settled: number }> = {};
    const hospitalMap: Record<string, { count: number; claimed: number; settled: number }> = {};
    const typeMap: Record<string, { count: number; claimed: number; settled: number }> = {};
    const statusMap: Record<string, { count: number; claimed: number; settled: number }> = {
      Pending: { count: 0, claimed: 0, settled: 0 },
      'In Progress': { count: 0, claimed: 0, settled: 0 },
      Approved: { count: 0, claimed: 0, settled: 0 },
      Settled: { count: 0, claimed: 0, settled: 0 },
      Rejected: { count: 0, claimed: 0, settled: 0 },
    };

    filteredClaims.forEach((c: any) => {
      const notes = getClaimNotesData(c.notes);
      const claimed = Number(c.claimAmount || 0);
      const approved = Number(c.approvedAmount || 0);
      const notedSettlement = Number(notes.amtPayableToInsured || 0);
      const statusStr = getClaimUiStatus(c);
      const isSettled = statusStr === 'Settled';
      const settled = approved > 0
        ? approved
        : notedSettlement > 0
          ? notedSettlement
          : isSettled ? claimed : (c.status === 'SETTLED' || c.status === 'APPROVED' ? (approved || claimed) : 0);

      const company = c.policy?.plan?.company?.name || 'Unknown Company';
      const hospital = notes.hospital || 'Outpatient / Other';
      const type = c.claimType || 'Other';

      totalClaimed += claimed;
      totalSettled += settled;
      totalPending += Math.max(0, claimed - settled);

      // Company
      if (!companyMap[company]) companyMap[company] = { count: 0, claimed: 0, settled: 0 };
      companyMap[company].count++;
      companyMap[company].claimed += claimed;
      companyMap[company].settled += settled;

      // Hospital
      if (!hospitalMap[hospital]) hospitalMap[hospital] = { count: 0, claimed: 0, settled: 0 };
      hospitalMap[hospital].count++;
      hospitalMap[hospital].claimed += claimed;
      hospitalMap[hospital].settled += settled;

      // Type
      if (!typeMap[type]) typeMap[type] = { count: 0, claimed: 0, settled: 0 };
      typeMap[type].count++;
      typeMap[type].claimed += claimed;
      typeMap[type].settled += settled;

      // Status
      if (!statusMap[statusStr]) statusMap[statusStr] = { count: 0, claimed: 0, settled: 0 };
      statusMap[statusStr].count++;
      statusMap[statusStr].claimed += claimed;
      statusMap[statusStr].settled += settled;
    });

    const pendingClaimed = totalPending;
    const settlementRatio = totalClaimed > 0 ? (totalSettled / totalClaimed) * 100 : 0;
    const avgClaim = filteredClaims.length > 0 ? totalClaimed / filteredClaims.length : 0;

    return {
      totalClaims: filteredClaims.length,
      totalClaimed,
      totalSettled,
      pendingClaimed,
      settlementRatio,
      avgClaim,
      companies: Object.entries(companyMap).map(([name, v]) => ({ name, ...v })),
      hospitals: Object.entries(hospitalMap).map(([name, v]) => ({ name, ...v })),
      types: Object.entries(typeMap).map(([name, v]) => ({ name, ...v })),
      statuses: Object.entries(statusMap).map(([name, v]) => ({ name, ...v })),
    };
  }, [filteredClaims]);

  // Group claims by Month for Visual SVG Line Chart
  const monthlyData = useMemo(() => {
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const values = months.map(() => 0);
    filteredClaims.forEach((c: any) => {
      const dStr = c.intimatedAt || c.createdAt;
      if (dStr) {
        const m = new Date(dStr).getMonth();
        if (m >= 0 && m < 12) {
          values[m] += Number(c.claimAmount || 0);
        }
      }
    });
    return { months, values };
  }, [filteredClaims]);

  // Export Analytics CSV
  const exportAnalytics = () => {
    let csvContent = "data:text/csv;charset=utf-8,";
    csvContent += "Category,Name,Total Claims,Claimed Amount,Settled Amount\n";

    // Summary
    csvContent += `Summary,All Filtered Claims,${stats.totalClaims},${stats.totalClaimed},${stats.totalSettled}\n\n`;

    // Company wise
    csvContent += "Company-wise Breakdown,,,\n";
    stats.companies.forEach(item => {
      csvContent += `Company,"${item.name.replace(/"/g, '""')}",${item.count},${item.claimed},${item.settled}\n`;
    });
    csvContent += "\n";

    // Hospital wise
    csvContent += "Hospital-wise Breakdown,,,\n";
    stats.hospitals.forEach(item => {
      csvContent += `Hospital,"${item.name.replace(/"/g, '""')}",${item.count},${item.claimed},${item.settled}\n`;
    });
    csvContent += "\n";

    // Type wise
    csvContent += "Type Breakdown,,,\n";
    stats.types.forEach(item => {
      csvContent += `Claim Type,"${item.name.replace(/"/g, '""')}",${item.count},${item.claimed},${item.settled}\n`;
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `claims_analytics_report_${format(new Date(), 'yyyyMMdd')}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Graph Data 1: Company wise (Claimed vs Settled)
  const companyGraphData = useMemo(() => {
    const map = new Map<string, { company: string; claimed: number; settled: number }>();
    filteredClaims.forEach((c: any) => {
      const comp = c.policy?.plan?.company?.name || 'Other';
      const entry = map.get(comp) || { company: comp, claimed: 0, settled: 0 };
      entry.claimed += Number(c.claimAmount || 0);
      if (c.status === 'SETTLED' || c.status === 'APPROVED' || getClaimUiStatus(c) === 'Settled') {
        entry.settled += Number(c.approvedAmount || c.claimAmount || 0);
      }
      map.set(comp, entry);
    });

    const sorted = Array.from(map.values()).sort((a, b) => b.claimed - a.claimed);
    if (graphCompanySelect === 'ALL') {
      return sorted.slice(0, 5);
    }
    return sorted.filter(c => c.company === graphCompanySelect);
  }, [filteredClaims, graphCompanySelect]);

  // Graph Data 2: Cashless vs Reimburse
  const typeGraphData = useMemo(() => {
    const map = new Map<string, { count: number; claimed: number; settled: number }>();
    filteredClaims.forEach((c: any) => {
      const type = c.claimType || 'Unknown';
      const entry = map.get(type) || { count: 0, claimed: 0, settled: 0 };
      entry.count += 1;
      entry.claimed += Number(c.claimAmount || 0);
      if (c.status === 'SETTLED' || c.status === 'APPROVED' || getClaimUiStatus(c) === 'Settled') {
        entry.settled += Number(c.approvedAmount || c.claimAmount || 0);
      }
      map.set(type, entry);
    });
    return Array.from(map.entries()).map(([name, data]) => ({ name, ...data }));
  }, [filteredClaims]);

  // Graph Data 3: Hospital wise (Claims count)
  const hospitalGraphData = useMemo(() => {
    const map = new Map<string, number>();
    filteredClaims.forEach((c: any) => {
      const notesData = getClaimNotesData(c.notes);
      const hosp = notesData.hospital || 'Direct Clinic/Other';
      map.set(hosp, (map.get(hosp) ?? 0) + 1);
    });
    return Array.from(map.entries())
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 8);
  }, [filteredClaims]);

  // Graph Data 4: Duration / Timeline (Claimed vs Settled)
  const timeGraphData = useMemo(() => {
    const map = new Map<string, { month: string; claimed: number; settled: number }>();
    const sorted = [...filteredClaims].sort((a: any, b: any) => {
      const da = a.intimatedAt ? new Date(a.intimatedAt) : new Date(a.createdAt);
      const db = b.intimatedAt ? new Date(b.intimatedAt) : new Date(b.createdAt);
      return da.getTime() - db.getTime();
    });

    sorted.forEach((c: any) => {
      const date = c.intimatedAt ? new Date(c.intimatedAt) : new Date(c.createdAt);
      const key = format(date, 'MMM yyyy');
      const entry = map.get(key) || { month: key, claimed: 0, settled: 0 };
      entry.claimed += Number(c.claimAmount || 0);
      if (c.status === 'SETTLED' || c.status === 'APPROVED' || getClaimUiStatus(c) === 'Settled') {
        entry.settled += Number(c.approvedAmount || c.claimAmount || 0);
      }
      map.set(key, entry);
    });

    const values = Array.from(map.values());
    if (timeGraphMonths === 'ALL') return values;
    const num = parseInt(timeGraphMonths, 10) || 12;
    return values.slice(-num);
  }, [filteredClaims, timeGraphMonths]);

  if (claimsLoading) {
    return (
      <div className="space-y-6">
        <SkeletonTable rows={4} cols={4} />
      </div>
    );
  }

  const hasActiveFilters = duration !== 'ALL' || selectedCompany !== 'ALL' || claimType !== 'ALL' || hospitalQuery.trim() !== '' || startDate !== '' || endDate !== '' || selectedAgent !== '';

  const handleResetFilters = () => {
    setDuration('ALL');
    setSelectedCompany('ALL');
    setClaimType('ALL');
    setHospitalQuery('');
    setStartDate('');
    setEndDate('');
    setSelectedAgent('');
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header Banner */}
      <div className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <h3 className="text-base font-bold text-gray-800 flex items-center gap-2">
            <FileCheck2 size={20} className="text-blue-600" />
            Claims Analytics & Reports Dashboard
          </h3>
          <p className="text-xs text-gray-500 mt-0.5">Real-time statistics, graphs, breakdown tables, and filtered reports</p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={exportAnalytics}
            className="btn-primary h-9 py-0 px-3.5 text-xs bg-emerald-600 hover:bg-emerald-700 text-white font-bold flex items-center gap-1.5 shadow-sm rounded-xl cursor-pointer transition-all"
          >
            <FileCheck2 size={14} /> Export Report (CSV)
          </button>
        </div>
      </div>

      {/* Advanced Filters Panel */}
      <div className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-gray-700 uppercase tracking-wide">Filter Claims & Analytics</span>
            {hasActiveFilters && (
              <span className="px-2 py-0.5 text-[10px] font-bold rounded-full bg-blue-100 text-blue-700">Active Filters</span>
            )}
          </div>
          {hasActiveFilters && (
            <button
              type="button"
              onClick={handleResetFilters}
              className="text-xs font-bold text-blue-600 hover:text-blue-800 hover:underline flex items-center gap-1 cursor-pointer transition-colors"
            >
              <RotateCcw className="w-3 h-3" /> Reset All Filters
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
          {/* Start Date */}
          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Start Date</label>
            <DatePicker
              value={startDate}
              onDateChange={setStartDate}
              className="w-full py-1 px-2 text-xs bg-gray-50 border border-gray-200 rounded-lg outline-none font-bold text-gray-600"
            />
          </div>

          {/* End Date */}
          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">End Date</label>
            <DatePicker
              value={endDate}
              onDateChange={setEndDate}
              className="w-full py-1 px-2 text-xs bg-gray-50 border border-gray-200 rounded-lg outline-none font-bold text-gray-600"
            />
          </div>

          {/* Duration */}
          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Duration</label>
            <select
              value={duration}
              onChange={e => setDuration(e.target.value)}
              className="w-full py-1.5 px-2 text-xs bg-gray-50 border border-gray-200 rounded-lg outline-none font-bold text-gray-600"
            >
              <option value="ALL">All Time</option>
              <option value="30">Last 30 Days</option>
              <option value="90">Last 90 Days</option>
              <option value="365">This Year</option>
            </select>
          </div>

          {/* Insurance Company */}
          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Company</label>
            <select
              value={selectedCompany}
              onChange={e => setSelectedCompany(e.target.value)}
              className="w-full py-1.5 px-2 text-xs bg-gray-50 border border-gray-200 rounded-lg outline-none font-bold text-gray-600"
            >
              <option value="ALL">All Companies</option>
              {companies.map(comp => (
                <option key={comp} value={comp}>{comp}</option>
              ))}
            </select>
          </div>

          {/* Claim Type */}
          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Claim Type</label>
            <select
              value={claimType}
              onChange={e => setClaimType(e.target.value)}
              className="w-full py-1.5 px-2 text-xs bg-gray-50 border border-gray-200 rounded-lg outline-none font-bold text-gray-600"
            >
              <option value="ALL">All Types</option>
              <option value="CASHLESS">Cashless</option>
              <option value="REIMBURSEMENT">Reimbursement</option>
              <option value="DEATH">Death</option>
              <option value="ACCIDENTAL">Accidental</option>
              <option value="MATURITY">Maturity</option>
            </select>
          </div>

          {/* Hospital */}
          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Hospital</label>
            <input
              type="text"
              placeholder="Search hospital..."
              value={hospitalQuery}
              onChange={e => setHospitalQuery(e.target.value)}
              className="w-full py-1.5 px-2 text-xs bg-gray-50 border border-gray-200 rounded-lg outline-none font-bold text-gray-600 placeholder-gray-400"
            />
          </div>

          {/* Agent */}
          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Agent</label>
            <select
              value={selectedAgent}
              onChange={e => setSelectedAgent(e.target.value)}
              className="w-full py-1.5 px-2 text-xs bg-gray-50 border border-gray-200 rounded-lg outline-none font-bold text-gray-600"
            >
              <option value="">All Agents</option>
              {employees.map((emp: any) => (
                <option key={emp.id} value={emp.id}>{emp.firstName} {emp.lastName}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Claim Stage Count Cards Row */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-4">
        {['Pending', 'In Progress', 'Approved', 'Settled', 'Rejected'].map(status => {
          const statusData = stats.statuses.find(s => s.name === status);
          const count = statusData ? statusData.count : 0;
          return (
            <div key={status} className="bg-white p-3 rounded-2xl border border-gray-100 shadow-sm flex flex-col justify-between items-center text-center">
              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">{status}</span>
              <span className="text-xl font-black text-indigo-600 mt-1">{count}</span>
            </div>
          );
        })}
        <div className="bg-white p-3 rounded-2xl border border-gray-100 shadow-sm flex flex-col justify-between items-center text-center">
          <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Total Claims</span>
          <span className="text-xl font-black text-slate-800 mt-1">{stats.totalClaims}</span>
        </div>
      </div>

      {/* 6 KPI Metric Cards Row */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
        <div className="bg-white rounded-2xl border border-gray-100 p-4 shadow-sm flex flex-col justify-between min-h-[112px]">
          <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wide">Total Claims</span>
          <span className="text-2xl font-black text-gray-900 mt-1">{stats.totalClaims}</span>
          <span className="text-[10px] text-gray-400 font-semibold truncate">Matching filtered criteria</span>
        </div>
        <div className="bg-white rounded-2xl border border-gray-100 p-4 shadow-sm flex flex-col justify-between min-h-[112px]">
          <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wide">Claimed Amt</span>
          <span className="text-2xl font-black text-blue-600 mt-1">₹{Math.round(stats.totalClaimed).toLocaleString('en-IN')}</span>
          <span className="text-[10px] text-gray-400 font-semibold truncate">Sum of total claims</span>
        </div>
        <div className="bg-white rounded-2xl border border-gray-100 p-4 shadow-sm flex flex-col justify-between min-h-[112px]">
          <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wide">Settled Amt</span>
          <span className="text-2xl font-black text-emerald-600 mt-1">₹{Math.round(stats.totalSettled).toLocaleString('en-IN')}</span>
          <span className="text-[10px] text-gray-400 font-semibold truncate">Total paid out amount</span>
        </div>
        <div className="bg-white rounded-2xl border border-gray-100 p-4 shadow-sm flex flex-col justify-between min-h-[112px]">
          <span className="text-[11px] font-bold text-amber-500 uppercase tracking-wide">Pending Amt</span>
          <span className="text-2xl font-black text-amber-600 mt-1">₹{Math.round(stats.pendingClaimed).toLocaleString('en-IN')}</span>
          <span className="text-[10px] text-amber-600/70 font-semibold truncate">Unsettled / In-flight</span>
        </div>
        <div className="bg-white rounded-2xl border border-gray-100 p-4 shadow-sm flex flex-col justify-between min-h-[112px]">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wide">Settlement %</span>
            <span className={`text-[10px] font-bold ${stats.settlementRatio >= 85 ? 'text-emerald-600' : stats.settlementRatio >= 70 ? 'text-amber-600' : 'text-red-600'}`}>
              {stats.settlementRatio >= 85 ? '▲ High' : stats.settlementRatio >= 70 ? '▲ Moderate' : '▼ Low'}
            </span>
          </div>
          <span className={`text-2xl font-black mt-1 ${stats.settlementRatio >= 85 ? 'text-emerald-600' : stats.settlementRatio >= 70 ? 'text-amber-600' : 'text-red-600'}`}>
            {stats.totalClaimed > 0 ? `${stats.settlementRatio.toFixed(1)}%` : '0%'}
          </span>
          <div className="w-full bg-gray-100 rounded-full h-1.5 mt-2 overflow-hidden">
            <div
              className={`h-1.5 rounded-full transition-all duration-500 ${
                stats.settlementRatio >= 85 ? 'bg-emerald-500' : stats.settlementRatio >= 70 ? 'bg-amber-500' : 'bg-red-500'
              }`}
              style={{ width: `${Math.min(100, Math.max(0, stats.settlementRatio))}%` }}
            />
          </div>
        </div>
        <div className="bg-white rounded-2xl border border-gray-100 p-4 shadow-sm flex flex-col justify-between min-h-[112px]">
          <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wide">Avg Claim</span>
          <span className="text-2xl font-black text-slate-800 mt-1">₹{Math.round(stats.avgClaim).toLocaleString('en-IN')}</span>
          <span className="text-[10px] text-gray-400 font-semibold truncate">Average claim size</span>
        </div>
      </div>

      {/* Section 1: Visual Interactive SVG Charts (From Claims Analytics) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Chart 1: Claims Trend (Monthly) */}
        <div className="bg-white p-5 rounded-2xl border border-gray-100 shadow-sm space-y-4">
          <div>
            <h4 className="text-xs font-bold text-gray-800 uppercase tracking-wider">Claims Trend (Monthly)</h4>
            <p className="text-[10px] text-gray-400 font-semibold">Total claimed amount in ₹ across months</p>
          </div>
          <div className="relative h-44 flex items-end justify-center">
            <svg viewBox="0 0 240 120" className="w-full h-full">
              {/* Grid Lines */}
              <line x1="10" y1="20" x2="230" y2="20" stroke="#f1f5f9" strokeWidth="1" />
              <line x1="10" y1="60" x2="230" y2="60" stroke="#f1f5f9" strokeWidth="1" />
              <line x1="10" y1="100" x2="230" y2="100" stroke="#e2e8f0" strokeWidth="1" />

              {/* Polyline */}
              {(() => {
                const maxVal = Math.max(...monthlyData.values, 1);
                const points = monthlyData.values.map((val, idx) => {
                  const x = 10 + idx * 20;
                  const y = 100 - (val / maxVal) * 80;
                  return `${x},${y}`;
                }).join(' ');
                return (
                  <>
                    <polyline fill="none" stroke="#3b82f6" strokeWidth="2.5" points={points} />
                    {monthlyData.values.map((val, idx) => {
                      const x = 10 + idx * 20;
                      const y = 100 - (val / maxVal) * 80;
                      if (val === 0) return null;
                      return (
                        <circle key={idx} cx={x} cy={y} r="3.5" fill="#2563eb" stroke="#ffffff" strokeWidth="1.5" />
                      );
                    })}
                  </>
                );
              })()}

              {/* X Axis Labels */}
              {monthlyData.months.map((m, idx) => (
                <text key={m} x={10 + idx * 20} y="115" fontSize="6.5" fill="#94a3b8" textAnchor="middle">{m}</text>
              ))}
            </svg>
          </div>
        </div>

        {/* Chart 2: Claim Type Share (SVG Doughnut Chart) */}
        <div className="bg-white p-5 rounded-2xl border border-gray-100 shadow-sm space-y-4">
          <div>
            <h4 className="text-xs font-bold text-gray-800 uppercase tracking-wider">Claim Type Share</h4>
            <p className="text-[10px] text-gray-400 font-semibold">Cashless vs Reimbursement distribution</p>
          </div>
          <div className="h-44 flex items-center justify-between gap-2">
            <div className="w-1/2 relative flex items-center justify-center">
              <svg width="100" height="100" viewBox="0 0 36 36" className="w-24 h-24">
                <circle cx="18" cy="18" r="15.915" fill="none" stroke="#f1f5f9" strokeWidth="3" />
                {(() => {
                  let accumulatedPercent = 0;
                  const colors = ['#3b82f6', '#10b981', '#f59e0b', '#ec4899', '#6366f1'];
                  return stats.types.map((type, idx) => {
                    const pct = stats.totalClaims > 0 ? (type.count / stats.totalClaims) * 100 : 0;
                    const dashArray = `${pct} ${100 - pct}`;
                    const dashOffset = 100 - accumulatedPercent + 25;
                    accumulatedPercent += pct;
                    return (
                      <circle
                        key={type.name}
                        cx="18"
                        cy="18"
                        r="15.915"
                        fill="none"
                        stroke={colors[idx % colors.length]}
                        strokeWidth="3.5"
                        strokeDasharray={dashArray}
                        strokeDashoffset={dashOffset}
                      />
                    );
                  });
                })()}
              </svg>
              <div className="absolute flex flex-col items-center justify-center">
                <span className="text-[10px] text-gray-400 uppercase font-semibold">Total</span>
                <span className="text-base font-bold text-gray-800">{stats.totalClaims}</span>
              </div>
            </div>
            <div className="w-1/2 space-y-1.5 max-h-36 overflow-y-auto pr-1">
              {stats.types.map((t, idx) => {
                const colors = ['bg-blue-500', 'bg-emerald-500', 'bg-amber-500', 'bg-pink-500', 'bg-indigo-500'];
                const pct = stats.totalClaims > 0 ? (t.count / stats.totalClaims) * 100 : 0;
                return (
                  <div key={t.name} className="flex flex-wrap items-center gap-1.5 text-[9px] text-gray-600">
                    <span className={`w-2 h-2 rounded-full ${colors[idx % colors.length]}`} />
                    <span className="truncate font-medium flex-1">{t.name}</span>
                    <span className="font-bold text-gray-800">{pct.toFixed(0)}%</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Chart 3: Status Distribution (SVG Bar Chart) */}
        <div className="bg-white p-5 rounded-2xl border border-gray-100 shadow-sm space-y-4">
          <div>
            <h4 className="text-xs font-bold text-gray-800 uppercase tracking-wider">Status Distribution</h4>
            <p className="text-[10px] text-gray-400 font-semibold">Total claims per status stage</p>
          </div>
          <div className="relative h-44 flex items-end justify-center">
            <svg viewBox="0 0 200 120" className="w-full h-full">
              <line x1="10" y1="20" x2="190" y2="20" stroke="#f1f5f9" strokeWidth="1" />
              <line x1="10" y1="60" x2="190" y2="60" stroke="#f1f5f9" strokeWidth="1" />
              <line x1="10" y1="100" x2="190" y2="100" stroke="#e2e8f0" strokeWidth="1" />

              {(() => {
                const counts = stats.statuses.map(s => s.count);
                const maxCount = Math.max(...counts, 1);
                const colors: Record<string, string> = {
                  Pending: '#3b82f6',
                  'In Progress': '#f59e0b',
                  Approved: '#10b981',
                  Rejected: '#ef4444',
                  Settled: '#059669',
                };
                return stats.statuses.map((s, idx) => {
                  const barWidth = 18;
                  const x = 20 + idx * 35;
                  const barHeight = (s.count / maxCount) * 80;
                  const y = 100 - barHeight;
                  return (
                    <g key={s.name}>
                      <rect
                        x={x}
                        y={y}
                        width={barWidth}
                        height={barHeight}
                        rx="2"
                        fill={colors[s.name] || '#64748b'}
                      />
                      <text x={x + 9} y={y - 4} fontSize="7" fontWeight="bold" fill="#475569" textAnchor="middle">{s.count}</text>
                      <text x={x + 9} y="113" fontSize="6" fill="#64748b" textAnchor="middle">{s.name}</text>
                    </g>
                  );
                });
              })()}
            </svg>
          </div>
        </div>
      </div>

      {/* Section 2: Recharts Widgets (From Dashboard Claims Reports) */}
      <div className="grid lg:grid-cols-2 gap-6">
        <div className="relative">
          <div className="absolute top-4 right-5 z-10 flex items-center gap-2">
            <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wide">Company:</label>
            <select
              value={graphCompanySelect}
              onChange={e => setGraphCompanySelect(e.target.value)}
              className="bg-gray-50 border border-gray-200 text-gray-700 text-xs font-bold rounded-lg px-2 py-1 outline-none cursor-pointer"
            >
              <option value="ALL">Top 5 Companies</option>
              {companies.map(comp => (
                <option key={comp} value={comp}>{comp}</option>
              ))}
            </select>
          </div>
          <BarChartWidget
            title="Claimed vs Settled Amount by Company (₹)"
            data={companyGraphData}
            xKey="company"
            bars={[
              { key: 'claimed', label: 'Claimed (₹)', color: '#3b82f6' },
              { key: 'settled', label: 'Settled (₹)', color: '#10b981' }
            ]}
          />
        </div>

        <div className="relative">
          <div className="absolute top-4 right-5 z-10 flex items-center gap-2">
            <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wide">Months:</label>
            <select
              value={timeGraphMonths}
              onChange={e => setTimeGraphMonths(e.target.value)}
              className="bg-gray-50 border border-gray-200 text-gray-700 text-xs font-bold rounded-lg px-2 py-1 outline-none cursor-pointer"
            >
              <option value="3">Last 3 Months</option>
              <option value="6">Last 6 Months</option>
              <option value="12">Last 12 Months</option>
              <option value="ALL">All Months</option>
            </select>
          </div>
          <LineChartWidget
            title="Claimed vs Settled Amount Trend over Time (₹)"
            data={timeGraphData}
            xKey="month"
            lines={[
              { key: 'claimed', label: 'Claimed (₹)', color: '#2563eb' },
              { key: 'settled', label: 'Settled (₹)', color: '#10b981' }
            ]}
          />
        </div>

        <BarChartWidget
          title="Top Hospitals by Claim Count"
          data={hospitalGraphData}
          xKey="name"
          bars={[
            { key: 'value', label: 'Claims Count', color: '#f59e0b' }
          ]}
        />

        <div className="relative">
          <div className="absolute top-4 right-5 z-10 flex items-center gap-2">
            <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wide">Metric:</label>
            <select
              value={pieChartMetric}
              onChange={e => setPieChartMetric(e.target.value as any)}
              className="bg-gray-50 border border-gray-200 text-gray-700 text-xs font-bold rounded-lg px-2 py-1 outline-none cursor-pointer"
            >
              <option value="count">No. of Claims</option>
              <option value="claimed">Claimed Amount (₹)</option>
              <option value="settled">Settled Amount (₹)</option>
            </select>
          </div>
          <PieChartWidget
            title="Claims by Cashless / Reimbursement"
            data={typeGraphData}
            nameKey="name"
            valueKey={pieChartMetric}
          />
        </div>
      </div>

      {/* Section 3: Breakdown Tables Grid (2x2) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Company-wise Breakdown */}
        <div className="space-y-2 bg-white p-5 rounded-2xl border border-gray-100 shadow-sm">
          <h4 className="text-xs font-bold text-gray-600 uppercase tracking-wider">Company-wise Breakdown & Share</h4>
          <div className="border border-gray-100 rounded-xl overflow-hidden bg-white max-h-56 overflow-y-auto">
            <table className="min-w-full divide-y divide-gray-100 text-xs">
              <thead className="bg-gray-50 font-bold text-gray-600">
                <tr>
                  <th className="px-3 py-2 text-left">Company</th>
                  <th className="px-3 py-2 text-center">Claims</th>
                  <th className="px-3 py-2 text-right">Claimed</th>
                  <th className="px-3 py-2 text-right">Settled</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50 text-gray-700">
                {stats.companies.length === 0 ? (
                  <tr><td colSpan={4} className="text-center py-4 text-gray-400">No data found</td></tr>
                ) : (
                  stats.companies.map(c => {
                    const pct = stats.totalClaimed > 0 ? (c.claimed / stats.totalClaimed) * 100 : 0;
                    return (
                      <tr key={c.name} className="hover:bg-gray-50/50">
                        <td className="px-3 py-2">
                          <span className="font-semibold block">{c.name}</span>
                          <div className="w-full bg-gray-100 h-1.5 rounded-full mt-1.5 overflow-hidden">
                            <div className="bg-blue-600 h-full rounded-full" style={{ width: `${Math.max(3, pct)}%` }} />
                          </div>
                        </td>
                        <td className="px-3 py-2 text-center font-bold">{c.count}</td>
                        <td className="px-3 py-2 text-right">₹{c.claimed.toLocaleString('en-IN')}</td>
                        <td className="px-3 py-2 text-right text-emerald-600 font-bold">₹{c.settled.toLocaleString('en-IN')}</td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Hospital-wise Breakdown */}
        <div className="space-y-2 bg-white p-5 rounded-2xl border border-gray-100 shadow-sm">
          <h4 className="text-xs font-bold text-gray-600 uppercase tracking-wider">Hospital-wise Breakdown & Share</h4>
          <div className="border border-gray-100 rounded-xl overflow-hidden bg-white max-h-56 overflow-y-auto">
            <table className="min-w-full divide-y divide-gray-100 text-xs">
              <thead className="bg-gray-50 font-bold text-gray-600">
                <tr>
                  <th className="px-3 py-2 text-left">Hospital</th>
                  <th className="px-3 py-2 text-center">Claims</th>
                  <th className="px-3 py-2 text-right">Claimed</th>
                  <th className="px-3 py-2 text-right">Settled</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50 text-gray-700">
                {stats.hospitals.length === 0 ? (
                  <tr><td colSpan={4} className="text-center py-4 text-gray-400">No data found</td></tr>
                ) : (
                  stats.hospitals.map(h => {
                    const pct = stats.totalClaimed > 0 ? (h.claimed / stats.totalClaimed) * 100 : 0;
                    return (
                      <tr key={h.name} className="hover:bg-gray-50/50">
                        <td className="px-3 py-2">
                          <span className="font-semibold block truncate max-w-[150px]" title={h.name}>{h.name}</span>
                          <div className="w-full bg-gray-100 h-1.5 rounded-full mt-1.5 overflow-hidden">
                            <div className="bg-indigo-600 h-full rounded-full" style={{ width: `${Math.max(3, pct)}%` }} />
                          </div>
                        </td>
                        <td className="px-3 py-2 text-center font-bold">{h.count}</td>
                        <td className="px-3 py-2 text-right">₹{h.claimed.toLocaleString('en-IN')}</td>
                        <td className="px-3 py-2 text-right text-emerald-600 font-bold">₹{h.settled.toLocaleString('en-IN')}</td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Claim Type Breakdown */}
        <div className="space-y-2 bg-white p-5 rounded-2xl border border-gray-100 shadow-sm">
          <h4 className="text-xs font-bold text-gray-600 uppercase tracking-wider">Claim Type Breakdown (Cashless / Reimbursement)</h4>
          <div className="border border-gray-100 rounded-xl overflow-hidden bg-white max-h-56 overflow-y-auto">
            <table className="min-w-full divide-y divide-gray-100 text-xs">
              <thead className="bg-gray-50 font-bold text-gray-600">
                <tr>
                  <th className="px-3 py-2 text-left">Type</th>
                  <th className="px-3 py-2 text-center">Claims</th>
                  <th className="px-3 py-2 text-right">Claimed</th>
                  <th className="px-3 py-2 text-right">Settled</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50 text-gray-700">
                {stats.types.length === 0 ? (
                  <tr><td colSpan={4} className="text-center py-4 text-gray-400">No data found</td></tr>
                ) : (
                  stats.types.map(t => {
                    const pct = stats.totalClaimed > 0 ? (t.claimed / stats.totalClaimed) * 100 : 0;
                    return (
                      <tr key={t.name} className="hover:bg-gray-50/50">
                        <td className="px-3 py-2">
                          <span className="font-semibold block">{t.name}</span>
                          <div className="w-full bg-gray-100 h-1.5 rounded-full mt-1.5 overflow-hidden">
                            <div className="bg-emerald-600 h-full rounded-full" style={{ width: `${Math.max(3, pct)}%` }} />
                          </div>
                        </td>
                        <td className="px-3 py-2 text-center font-bold">{t.count}</td>
                        <td className="px-3 py-2 text-right">₹{t.claimed.toLocaleString('en-IN')}</td>
                        <td className="px-3 py-2 text-right text-emerald-600 font-bold">₹{t.settled.toLocaleString('en-IN')}</td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Duration Breakdown */}
        <div className="space-y-2 bg-white p-5 rounded-2xl border border-gray-100 shadow-sm">
          <h4 className="text-xs font-bold text-gray-600 uppercase tracking-wider">Duration-wise Breakdown</h4>
          <div className="border border-gray-100 rounded-xl overflow-hidden bg-white max-h-56 overflow-y-auto">
            <table className="min-w-full divide-y divide-gray-100 text-xs">
              <thead className="bg-gray-50 font-bold text-gray-600">
                <tr>
                  <th className="px-3 py-2 text-left">Time Range</th>
                  <th className="px-3 py-2 text-center">Claims</th>
                  <th className="px-3 py-2 text-right">Claimed</th>
                  <th className="px-3 py-2 text-right">Settled</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50 text-gray-700">
                {[
                  { name: 'Last 30 Days', filter: (c: any) => (Date.now() - new Date(c.intimatedAt || c.createdAt).getTime()) / 86400000 <= 30 },
                  { name: '31 to 90 Days', filter: (c: any) => { const diff = (Date.now() - new Date(c.intimatedAt || c.createdAt).getTime()) / 86400000; return diff > 30 && diff <= 90; } },
                  { name: 'Older (90+ Days)', filter: (c: any) => (Date.now() - new Date(c.intimatedAt || c.createdAt).getTime()) / 86400000 > 90 },
                ].map(range => {
                  const matched = filteredClaims.filter(range.filter);
                  const claimed = matched.reduce((sum: number, c: any) => sum + Number(c.claimAmount || 0), 0);
                  const settled = matched.reduce((sum: number, c: any) => sum + Number(c.approvedAmount || 0), 0);
                  const pct = stats.totalClaimed > 0 ? (claimed / stats.totalClaimed) * 100 : 0;
                  return (
                    <tr key={range.name} className="hover:bg-gray-50/50">
                      <td className="px-3 py-2">
                        <span className="font-semibold block">{range.name}</span>
                        <div className="w-full bg-gray-100 h-1.5 rounded-full mt-1.5 overflow-hidden">
                          <div className="bg-amber-500 h-full rounded-full" style={{ width: `${Math.max(3, pct)}%` }} />
                        </div>
                      </td>
                      <td className="px-3 py-2 text-center font-bold">{matched.length}</td>
                      <td className="px-3 py-2 text-right">₹{claimed.toLocaleString('en-IN')}</td>
                      <td className="px-3 py-2 text-right text-emerald-600 font-bold">₹{settled.toLocaleString('en-IN')}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* ── Claims Detailed History Table ─────────────────────────────────── */}
      <div className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm overflow-hidden">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-xs font-bold text-gray-900 tracking-wider uppercase">Filtered Claims History & Settlements</h3>
            <p className="text-[10px] text-gray-400 font-semibold mt-0.5">Live tracking of cashless intimations and reimbursement payouts</p>
          </div>
          <button
            onClick={() => navigate('/claims')}
            className="text-xs font-bold text-blue-600 hover:text-blue-700 transition-colors cursor-pointer"
          >
            Open Claims Module →
          </button>
        </div>

        <div className="overflow-x-auto -mx-5 -mb-5">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-gray-50/70 border-b border-gray-100">
                {['Claim ID', 'Intimation Date', 'Policy Holder', 'Insurance Company', 'Type', 'Hospital / Diagnosis', 'Claim Amount', 'Settled Amount', 'Status'].map(h => (
                  <th key={h} className="px-5 py-2.5 text-left text-[11px] font-bold text-gray-500 uppercase tracking-wider">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50 font-medium">
              {filteredClaims.length === 0 ? (
                <tr>
                  <td colSpan={9} className="text-center py-8 text-xs text-gray-400">No claims match the filter</td>
                </tr>
              ) : (
                filteredClaims.map((c: any) => {
                  const client = c.policy?.contact ? `${c.policy.contact.firstName} ${c.policy.contact.lastName}` : (c.contactName || 'Amit Sharma');
                  const compName = c.policy?.plan?.company?.name || 'Star Health';
                  const notesData = getClaimNotesData(c.notes);
                  const amount = Number(c.claimAmount ?? c.amount ?? 0);
                  const approved = Number(c.approvedAmount ?? (c.status === 'SETTLED' ? amount : 0));
                  const uiStatus = getClaimUiStatus(c);

                  return (
                    <tr key={c.id} className="hover:bg-blue-50/30 transition-colors text-xs">
                      <td className="px-5 py-3.5 font-bold text-gray-900">{c.claimNumber ?? `CLM-${c.id.slice(-4).toUpperCase()}`}</td>
                      <td className="px-5 py-3.5 text-gray-500 whitespace-nowrap">
                        {c.intimatedAt
                          ? format(new Date(c.intimatedAt), 'dd MMM yyyy')
                          : c.createdAt
                          ? format(new Date(c.createdAt), 'dd MMM yyyy')
                          : '—'}
                      </td>
                      <td className="px-5 py-3.5 font-semibold text-gray-800">{client}</td>
                      <td className="px-5 py-3.5 text-gray-600">{compName}</td>
                      <td className="px-5 py-3.5">
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-700">
                          {c.claimType || 'CASHLESS'}
                        </span>
                      </td>
                      <td className="px-5 py-3.5 text-gray-600 max-w-[200px] truncate">
                        {notesData.hospital ? `${notesData.hospital} • ${notesData.diagnosis}` : (notesData.diagnosis || 'Hospitalization')}
                      </td>
                      <td className="px-5 py-3.5 font-bold text-gray-900">₹{amount.toLocaleString('en-IN')}</td>
                      <td className="px-5 py-3.5 font-bold text-emerald-600">{approved > 0 ? `₹${approved.toLocaleString('en-IN')}` : '—'}</td>
                      <td className="px-5 py-3.5">
                        <span className={clsx(
                          'inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider',
                          uiStatus === 'Settled' || c.status === 'SETTLED' || c.status === 'APPROVED' ? 'bg-green-100 text-green-700' :
                            uiStatus === 'Pending' || c.status === 'PENDING' ? 'bg-amber-100 text-amber-700' :
                              uiStatus === 'In Progress' || c.status === 'IN_PROGRESS' ? 'bg-blue-100 text-blue-700' :
                                uiStatus === 'Rejected' || c.status === 'REJECTED' ? 'bg-red-100 text-red-700' :
                                  'bg-gray-100 text-gray-700'
                        )}>
                          {uiStatus || c.status || 'PENDING'}
                        </span>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// ── Main Dashboard Page ──────────────────────────────────────────────────────

export default function Dashboard() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [revenueMonths, setRevenueMonths] = useState(12);
  const [portfolioView, setPortfolioView] = useState<'product' | 'company'>('product');
  const [activeTab, setActiveTab] = useState<'overview' | 'claims-reports'>('overview');
  const [selectedCompanyFilter, setSelectedCompanyFilter] = useState('ALL');
  const [selectedProductCategoryFilter, setSelectedProductCategoryFilter] = useState('ALL');
  const [leadsDateRange, setLeadsDateRange] = useState('ALL');
  const [premiumPlanPeriod, setPremiumPlanPeriod] = useState<'this_month' | 'this_quarter' | 'this_year' | 'all_time'>('this_year');
  const user = useAuthStore(s => s.user);

  const filteredBusinessCategoryBars = useMemo(() => {
    if (selectedProductCategoryFilter === 'ALL') {
      return BUSINESS_CATEGORY_BARS;
    }
    if (selectedProductCategoryFilter === 'GRP_HEALTH') {
      return BUSINESS_CATEGORY_BARS.filter(b => ['health', 'accident', 'critical', 'groupHealth', 'groupPa', 'sme'].includes(b.key));
    }
    if (selectedProductCategoryFilter === 'GRP_LIFE') {
      return BUSINESS_CATEGORY_BARS.filter(b => ['termLife', 'tulip', 'ulip', 'endowment', 'moneyback'].includes(b.key));
    }
    if (selectedProductCategoryFilter === 'GRP_BUSINESS') {
      return BUSINESS_CATEGORY_BARS.filter(b => ['groupHealth', 'groupPa', 'sme', 'business'].includes(b.key));
    }
    return BUSINESS_CATEGORY_BARS.filter(b => b.key === selectedProductCategoryFilter);
  }, [selectedProductCategoryFilter]);

  // Queries
  const { data: kpiRes, isLoading: kpiLoading } = useDashboardKpis();
  const { data: revenueRes, isLoading: revenueLoading } = useDashboardRevenue(revenueMonths);
  const { data: portfolioRes, isLoading: portfolioLoading } = useDashboardPortfolio();
  const { data: pipelineRes, isLoading: pipelineLoading } = useDashboardPipeline();
  const { data: summaryRes, isLoading: summaryLoading } = useDashboardDbSummary();
  const { data: analyticsRes, isLoading: analyticsLoading } = useDashboardAnalytics();
  const analytics = analyticsRes?.data ?? analyticsRes;

  // Load claims and agents directly for the Overview sections
  const { data: claimsListRes, isLoading: claimsListLoading } = useQuery({
    queryKey: ['dashboard', 'recent-claims'],
    queryFn: () => claimsService.list({ limit: 5 }),
    staleTime: 5 * 60_000,
  });

  const { data: agentsRes, isLoading: agentsLoading } = useQuery({
    queryKey: ['dashboard', 'top-agents'],
    queryFn: () => employeesService.list({ limit: 5 }),
    staleTime: 5 * 60_000,
  });

  // Normalise KPIs with realistic fallback
  const kpis = kpiRes?.data ?? { totalPolicies: 0, activeLeads: 0, totalPremium: 0, totalContacts: 0 };
  const revenue = (revenueRes?.data && revenueRes.data.length > 0) ? revenueRes.data : [];

  // Dynamic companies from live analytics
  const companyLines = useMemo(() => {
    if (analytics?.companyLines && analytics.companyLines.length > 0) {
      return analytics.companyLines;
    }
    return [];
  }, [analytics]);

  const companyWiseData = useMemo(() => {
    if (analytics?.monthlyCompanyWise && analytics.monthlyCompanyWise.length > 0) {
      return analytics.monthlyCompanyWise;
    }
    return [];
  }, [analytics]);

  // Filtered Premium by Plan based on selected time period
  const filteredPremiumByPlan = useMemo(() => {
    const periodMap = analytics?.premiumByPlanPeriods?.[premiumPlanPeriod];
    if (periodMap && Object.keys(periodMap).length > 0) {
      return Object.entries(periodMap).map(([name, value]) => ({
        name,
        value: Number(value),
      }));
    }
    return [];
  }, [analytics, premiumPlanPeriod]);

  // Normalize Portfolio to support both product (category) and company toggles
  const portfolio = useMemo(() => {
    const raw = portfolioRes?.data;
    if (raw) {
      if (Array.isArray(raw) && raw.length > 0) {
        return raw.map((r: any) => ({
          name: r.category ?? r.name,
          value: r.count ?? r.value,
        }));
      }
      if (portfolioView === 'product' && raw.byProduct?.length) {
        return raw.byProduct.map((r: any) => ({ name: r.name, value: r.value }));
      }
      if (portfolioView === 'company' && raw.byCompany?.length) {
        return raw.byCompany.map((r: any) => ({ name: r.name, value: r.value }));
      }
    }
    return [];
  }, [portfolioRes, portfolioView]);

  const pipelineData = (pipelineRes?.data && Array.isArray(pipelineRes.data)) ? pipelineRes.data : [];
  const summaryData = (summaryRes?.data ?? summaryRes) || {};
  const claims = (claimsListRes?.data && Array.isArray(claimsListRes.data)) ? claimsListRes.data : [];
  const agents = (agentsRes?.data && Array.isArray(agentsRes.data)) ? agentsRes.data : [];

  const handleRefreshAll = () => {
    qc.invalidateQueries({ queryKey: ['dashboard'] });
    qc.invalidateQueries({ queryKey: ['claims'] });
    qc.invalidateQueries({ queryKey: ['employees'] });
  };

  return (
    <div className="space-y-6 text-sm sm:text-base">
      {/* ── Tab Switcher & Action Bar ────────────────────────────────────────── */}
      <div className="flex items-center justify-between border-b border-gray-200">
        <div className="flex items-center">
          <button
            onClick={() => setActiveTab('overview')}
            className={clsx(
              "py-2.5 px-4 font-bold text-xs uppercase tracking-wider border-b-2 transition-all cursor-pointer",
              activeTab === 'overview'
                ? "border-blue-600 text-blue-600"
                : "border-transparent text-gray-400 hover:text-gray-600 hover:border-gray-200"
            )}
          >
            Overview
          </button>
          <button
            onClick={() => setActiveTab('claims-reports')}
            className={clsx(
              "py-2.5 px-4 font-bold text-xs uppercase tracking-wider border-b-2 transition-all cursor-pointer",
              activeTab === 'claims-reports'
                ? "border-blue-600 text-blue-600"
                : "border-transparent text-gray-400 hover:text-gray-600 hover:border-gray-200"
            )}
          >
            Claims Reports & Analytics
          </button>
        </div>

        <button
          onClick={handleRefreshAll}
          className="h-7 px-3 text-[11px] font-bold rounded-lg bg-gray-100 hover:bg-gray-200 text-gray-700 flex items-center gap-1.5 transition-all cursor-pointer mb-1 shadow-2xs"
        >
          <RefreshCw size={12} className={kpiLoading ? 'animate-spin' : ''} />
          Refresh
        </button>
      </div>

      {activeTab === 'claims-reports' ? (
        <ClaimsReportsTab />
      ) : (
        <div className="space-y-6 animate-fadeIn">
          {/* ── Top KPI Cards Grid ───────────────────────────────────────────── */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {kpiLoading ? (
              Array.from({ length: 4 }).map((_, i) => <SkeletonCard key={i} />)
            ) : (
              <>
                <PremiumKpiCard
                  label="Total Policies"
                  value={fmt(kpis?.totalPolicies ?? kpis?.activePolicies)}
                  trend={kpis?.totalPolicies ? "12.5%" : undefined}
                  trendUp={true}
                  icon={<Shield size={18} className="text-blue-600" />}
                  color="bg-blue-50"
                  onClick={() => navigate('/policies')}
                />
                <PremiumKpiCard
                  label="Active Leads"
                  value={fmt(kpis?.openLeads)}
                  trend={kpis?.openLeads ? "10.2%" : undefined}
                  trendUp={true}
                  icon={<TrendingUp size={18} className="text-amber-600" />}
                  color="bg-amber-50"
                  onClick={() => navigate('/leads')}
                />
                <PremiumKpiCard
                  label="Total Premium"
                  value={fmtINR(kpis?.monthlyPremium)}
                  trend={kpis?.monthlyPremium ? "15.6%" : undefined}
                  trendUp={true}
                  icon={<DollarSign size={18} className="text-indigo-600" />}
                  color="bg-indigo-50"
                  onClick={() => navigate('/policies')}
                />
                <PremiumKpiCard
                  label="Total Contacts"
                  value={fmt(analytics?.contactsDemographics?.total ?? kpis?.totalContacts ?? summaryData?.contacts ?? 0)}
                  trend={kpis?.totalContacts ? "7.8%" : undefined}
                  trendUp={true}
                  icon={<Users size={18} className="text-teal-600" />}
                  color="bg-teal-50"
                  onClick={() => navigate('/contacts')}
                />
              </>
            )}
          </div>

          {/* ── Info Charts ─────────────────────────────────────────────────── */}
          <div className="grid lg:grid-cols-3 gap-6 mb-6">
            <div className="lg:col-span-2 relative">
              <div className="absolute right-5 top-3.5 z-10 flex items-center gap-2">
                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wide">Time Period:</label>
                <select
                  value={premiumPlanPeriod}
                  onChange={e => setPremiumPlanPeriod(e.target.value as any)}
                  className="bg-gray-50 border border-gray-200 text-gray-700 text-xs font-bold rounded-lg px-2.5 py-1 outline-none cursor-pointer hover:border-gray-300 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all shadow-2xs"
                >
                  <option value="this_month">This Month</option>
                  <option value="this_quarter">This Quarter</option>
                  <option value="this_year">This Year (FY)</option>
                  <option value="all_time">All Time</option>
                </select>
              </div>
              <BarChartWidget
                title="Premium by Insurance Plan Category"
                data={filteredPremiumByPlan}
                xKey="name"
                bars={[{ key: 'value', label: 'Premium (₹)', color: '#10b981' }]}
                className="h-full flex flex-col justify-center"
                height={350}
              />
            </div>
            <div className="lg:col-span-1 flex flex-col gap-6">
              <div className="flex-1">
                <ContactsBreakdownCard data={analytics?.contactsDemographics || { total: 0, male: 0, female: 0, under18: 0, above60: 0 }} />
              </div>
              <div className="flex-1">
                <PieChartWidget
                  title="Active Policies by Category"
                  data={portfolioRes?.data?.byProduct?.length ? portfolioRes.data.byProduct : portfolio}
                  nameKey="name"
                  valueKey="value"
                />
              </div>
            </div>
          </div>

          {/* ── Mid-section: Chart + Portfolio Donut ─────────────────────────── */}
          <div className="grid lg:grid-cols-3 gap-6">
            {/* Line Chart */}
            <div className="lg:col-span-2 bg-white rounded-2xl border border-gray-100 p-5 shadow-sm relative">
              <div className="absolute right-5 top-5 z-10 flex flex-wrap items-center gap-2">
                <select
                  value={revenueMonths}
                  onChange={e => setRevenueMonths(Number(e.target.value))}
                  className="py-1 px-2.5 text-xs bg-gray-50 border border-gray-200 rounded-lg outline-none font-bold text-gray-600"
                >
                  <option value={3}>This Quarter</option>
                  <option value={6}>Last 6 Months</option>
                  <option value={12}>This Year</option>
                </select>
              </div>
              {revenueLoading ? (
                <SkeletonChart height={240} />
              ) : (
                <LineChartWidget
                  title="Premium Collection"
                  data={revenue}
                  xKey="month"
                  lines={[{ key: 'revenue', label: 'Premium (₹)', color: '#2563eb' }]}
                />
              )}
            </div>

            {/* Pie Chart with Product/Company view toggle */}
            <div className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm relative">
              <div className="absolute right-5 top-5 z-10 flex flex-wrap items-center gap-1.5">
                <button
                  onClick={() => setPortfolioView('product')}
                  className={clsx(
                    "px-2 py-0.5 text-[10px] font-bold rounded transition-all cursor-pointer",
                    portfolioView === 'product'
                      ? "bg-blue-50 text-blue-600 border border-blue-200"
                      : "text-gray-400 bg-gray-50 hover:bg-gray-100 border border-transparent"
                  )}
                >
                  Product
                </button>
                <button
                  onClick={() => setPortfolioView('company')}
                  className={clsx(
                    "px-2 py-0.5 text-[10px] font-bold rounded transition-all cursor-pointer",
                    portfolioView === 'company'
                      ? "bg-blue-50 text-blue-600 border border-blue-200"
                      : "text-gray-400 bg-gray-50 hover:bg-gray-100 border border-transparent"
                  )}
                >
                  Company
                </button>
              </div>
              {portfolioLoading ? (
                <SkeletonChart height={240} />
              ) : (
                <PieChartWidget
                  title={`Portfolio by ${portfolioView === 'product' ? 'Product Type' : 'Insurance Company'}`}
                  data={portfolio}
                  nameKey="name"
                  valueKey="value"
                />
              )}
            </div>
          </div>

          {/* ── Mid-section 2: Leads Progress Indicator + Database Summary ────── */}
          <div className="grid lg:grid-cols-3 gap-6">
            <div className="lg:col-span-1">
              {pipelineLoading ? (
                <SkeletonCard />
              ) : (
                <LeadsProgressIndicator pipelineData={pipelineData} />
              )}
            </div>
            <div className="lg:col-span-2">
              {summaryLoading ? (
                <SkeletonCard />
              ) : (
                <DatabaseSummary summaryData={summaryData} />
              )}
            </div>
          </div>

          {/* ── Bottom-section: Top Performing Agents ────────────────────────── */}
          <div className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm">
            <SectionHeader
              title="Top Performing Sales Agents"
              action="View All Employees"
              onAction={() => navigate('/employees')}
            />
            {agentsLoading ? (
              <SkeletonCard />
            ) : agents.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 text-gray-400">
                <Users size={32} className="mb-2 opacity-35" />
                <p className="text-sm font-medium">No agents found</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-2">
                {agents.slice(0, 4).map((a: any, idx: number) => (
                  <div key={a.id} className="flex items-center gap-3 p-3.5 rounded-2xl bg-gray-50/70 border border-gray-100 hover:border-blue-200 hover:bg-white hover:shadow-xs transition-all">
                    <div className="h-10 w-10 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white flex items-center justify-center text-xs font-black shrink-0 shadow-sm shadow-blue-500/20">
                      {a.firstName?.[0] || ''}{a.lastName?.[0] || ''}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <p className="text-xs font-bold text-gray-900 truncate">
                          {a.firstName} {a.lastName}
                        </p>
                        <span className="text-[10px] font-extrabold text-blue-600">#{idx + 1}</span>
                      </div>
                      <p className="text-[10px] text-gray-400 font-semibold truncate">{a.designation || 'Specialist'}</p>
                      <p className="text-[10px] font-bold text-emerald-600 mt-0.5">{a.policiesCount ?? 0} Policies Sold</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* ── Total Business Graph Category Wise ────────────────────────────── */}
          <div className="grid grid-cols-1 gap-6 mb-6">
            <div className="card relative p-0 bg-transparent shadow-none border-none">
              <div className="absolute top-4 right-5 z-10 flex items-center gap-2">
                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wide">Select Product:</label>
                <select
                  value={selectedProductCategoryFilter}
                  onChange={e => setSelectedProductCategoryFilter(e.target.value)}
                  className="bg-gray-50 border border-gray-200 text-gray-700 text-xs font-bold rounded-lg px-2.5 py-1 outline-none cursor-pointer hover:border-gray-300 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all shadow-2xs"
                >
                  <option value="ALL">All Products (14 Categories)</option>
                  <optgroup label="Product Groups">
                    <option value="GRP_HEALTH">Health & Accident Plans</option>
                    <option value="GRP_LIFE">Life & Savings Plans</option>
                    <option value="GRP_BUSINESS">Group & SME Plans</option>
                  </optgroup>
                  <optgroup label="Individual Products">
                    {BUSINESS_CATEGORY_BARS.map(b => (
                      <option key={b.key} value={b.key}>{b.label}</option>
                    ))}
                  </optgroup>
                </select>
              </div>
              <BarChartWidget
                title="Total Business Graph Category Wise (Jan to Dec)"
                data={analytics?.monthlyCategoryWise || []}
                xKey="month"
                bars={filteredBusinessCategoryBars}
              />
            </div>
          </div>

          {/* ── Total Business Graph Company Wise ─────────────────────────────── */}
          <div className="grid grid-cols-1 gap-6 mb-6">
            <div className="card relative p-0 bg-transparent shadow-none border-none">
              <div className="absolute top-1 right-5 z-10 flex items-center gap-2">
                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wide">Filter:</label>
                <select
                  value={selectedCompanyFilter}
                  onChange={e => setSelectedCompanyFilter(e.target.value)}
                  className="bg-gray-50 border border-gray-200 text-gray-700 text-xs font-bold rounded-lg px-2 py-1 outline-none cursor-pointer"
                >
                  <option value="ALL">All Companies</option>
                  {companyLines.map((c: any) => (
                    <option key={c.key} value={c.key}>{c.label}</option>
                  ))}
                </select>
              </div>
              <LineChartWidget
                title="Total Business Graph by Company (Jan to Dec)"
                data={companyWiseData}
                xKey="month"
                lines={selectedCompanyFilter === 'ALL' ? companyLines : companyLines.filter((l: any) => l.key === selectedCompanyFilter)}
              />
            </div>
          </div>

          {/* ── Total Business Graph Tenure Wise (Gen + Health) ──────────────── */}
          <div className="grid grid-cols-1 gap-6 mb-6">
            <BarChartWidget
              title="Insurance Company Category Gen + Health Total Business (Tenure Wise 1-5 Years)"
              data={analytics?.monthlyTenureWise || []}
              xKey="month"
              bars={TENURE_BARS}
            />
          </div>

          {/* ── Avg Sum Insured Cards ────────────────────────────────────────── */}
          <div className="grid lg:grid-cols-2 gap-6 mb-6">
            <AvgSumInsuredGenHealthCard data={analytics?.avgSumInsured?.genHealth} />
            <AvgSumInsuredTermCard data={analytics?.avgSumInsured?.termLife} />
          </div>

          {/* ── New Leads Created (Stage Wise & Status Wise) ──────────────── */}
          <div className="grid grid-cols-1 gap-6 mb-6">
            <div className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm">
              <div className="flex flex-wrap justify-between items-center mb-6 gap-4">
                <h3 className="text-sm font-semibold text-gray-700">New Leads Created (Stage Wise & Status Wise)</h3>
                <div className="flex items-center gap-2">
                  <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wide">Date Range:</label>
                  <select
                    value={leadsDateRange}
                    onChange={e => setLeadsDateRange(e.target.value)}
                    className="bg-gray-50 border border-gray-200 text-gray-700 text-xs font-bold rounded-lg px-2 py-1 outline-none cursor-pointer"
                  >
                    <option value="ALL">All Time</option>
                    <option value="30">Last 30 Days</option>
                    <option value="90">Last 90 Days</option>
                    <option value="365">This Year</option>
                  </select>
                </div>
              </div>
              <BarChartWidget
                data={analytics?.leadsStatusWise || []}
                xKey="stage"
                bars={LEAD_STATUS_BARS}
                height={300}
              />
            </div>
          </div>

          {/* ── Additional Charts: Persons Covered & MF Leads ─────────────── */}
          <div className="grid lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 bg-white rounded-2xl border border-gray-100 p-5 shadow-sm">
              <CoverageBarChartWidget
                title="Total No. of Persons Covered Under Product Category"
                data={analytics?.personsCovered?.length ? analytics.personsCovered : []}
                xKey="name"
                valueKey="value"
                totalKey="total"
              />
            </div>
            <div className="lg:col-span-1">
              <MfLeadsSummaryCard data={analytics?.mfBusiness || { inforceFolios: 0, monthlySip: 0, sipAum: 0, lumpsumAum: 0, totalAum: 0 }} />
            </div>
          </div>

          {/* ── Footer KPI summary widgets ─────────────────────────────────── */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm flex flex-wrap items-center gap-4 hover:shadow-md transition">
              <div className="w-12 h-12 rounded-xl bg-blue-50 flex items-center justify-center text-blue-600 shrink-0">
                <Shield size={22} />
              </div>
              <div>
                <p className="text-xs font-bold text-gray-400 uppercase tracking-wide">Policy Retention Rate</p>
                <p className="text-xl font-black text-gray-900 mt-1">{analytics?.retentionRate !== undefined ? `${analytics.retentionRate}%` : '0%'}</p>
                {analytics?.retentionRate ? (
                  <span className="text-[10px] font-bold text-green-600">▲ +2.4% <span className="text-gray-400 font-medium">vs last month</span></span>
                ) : (
                  <span className="text-[10px] font-medium text-gray-400">No active policies</span>
                )}
              </div>
            </div>

            <div className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm flex flex-wrap items-center gap-4 hover:shadow-md transition">
              <div className="w-12 h-12 rounded-xl bg-indigo-50 flex items-center justify-center text-indigo-600 shrink-0">
                <RefreshCw size={22} />
              </div>
              <div>
                <p className="text-xs font-bold text-gray-400 uppercase tracking-wide">Renewal Rate</p>
                <p className="text-xl font-black text-gray-900 mt-1">{analytics?.renewalRate !== undefined ? `${analytics.renewalRate}%` : '0%'}</p>
                {analytics?.renewalRate ? (
                  <span className="text-[10px] font-bold text-green-600">▲ +3.7% <span className="text-gray-400 font-medium">vs last month</span></span>
                ) : (
                  <span className="text-[10px] font-medium text-gray-400">No renewals yet</span>
                )}
              </div>
            </div>

            <div className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm flex flex-wrap items-center gap-4 hover:shadow-md transition">
              <div className="w-12 h-12 rounded-xl bg-purple-50 flex items-center justify-center text-purple-600 shrink-0">
                <Star size={22} />
              </div>
              <div>
                <p className="text-xs font-bold text-gray-400 uppercase tracking-wide">Customer Satisfaction</p>
                <p className="text-xl font-black text-gray-900 mt-1">{analytics?.customerSatisfaction !== undefined ? `${analytics.customerSatisfaction}/5` : '0/5'}</p>
                <span className="text-[10px] font-medium text-gray-400">Based on verified feedback</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
