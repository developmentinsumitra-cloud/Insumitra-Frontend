import api from './api';
import { useAuthStore } from '@store/auth.store';
import { useClientStore } from '@store/client.store';
import { useLookupStore } from '@store/lookup.store';

export interface LoginPayload     { email: string; password: string }
export interface RegisterPayload  { tenantName: string; tenantSlug: string; email: string; password: string; firstName: string; lastName: string; phone?: string }
export interface RegisterEmployeePayload { email: string; password: string; firstName: string; lastName: string; phone: string; designation?: string; department?: string; tenantId?: string }
export interface ResetPasswordDirectPayload { email: string; phone?: string; newPassword: string }
export interface ChangePassPayload { currentPassword: string; newPassword: string }

export const authService = {
  async login(payload: LoginPayload) {
    const { data } = await api.post('/auth/login', payload);
    const { accessToken, refreshToken, user } = data.data;
    useAuthStore.getState().setTokens(accessToken, refreshToken);
    useAuthStore.getState().setUser(user);
    if (user?.role === 'CONTACT') {
      useClientStore.getState().setAuth(accessToken, refreshToken, user);
    }
    // Load lookups right after login
    useLookupStore.getState().loadAll();
    return data.data;
  },

  async register(payload: RegisterPayload) {
    const { data } = await api.post('/auth/register', payload);
    return data.data;
  },

  async registerEmployee(payload: RegisterEmployeePayload) {
    const { data } = await api.post('/auth/register-employee', payload);
    return data;
  },

  async resetPasswordDirect(payload: ResetPasswordDirectPayload) {
    const { data } = await api.post('/auth/reset-password-direct', payload);
    return data;
  },

  async changePassword(payload: ChangePassPayload) {
    const { data } = await api.post('/auth/change-password', payload);
    return data;
  },

  async getMe() {
    try {
      const { data } = await api.get('/auth/me');
      if (data?.data) {
        useAuthStore.getState().setUser(data.data);
      }
      return data?.data;
    } catch {
      return null;
    }
  },

  async logout() {
    try { await api.post('/auth/logout'); } catch {}
    useAuthStore.getState().logout();
    useClientStore.getState().logout();
    useLookupStore.getState().clearCache();
  },
};

